import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createCrmExportShareLink, CRM_EXPORT_LINK_SECONDS } from '../src/utils/crmExportShareLink.js';

test('CRM export creates a private 24-hour signed link under the exporting user', async () => {
    const calls = [];
    const client = { storage: { from: bucket => {
        assert.equal(bucket, 'crm-exports');
        return {
            upload: async (path, file, options) => { calls.push(['upload', path, file.name, options]); return { error: null }; },
            createSignedUrl: async (path, seconds, options) => { calls.push(['sign', path, seconds, options]); return { data: { signedUrl: 'https://example.test/signed' }, error: null }; },
            remove: async () => { throw new Error('unexpected cleanup'); },
        };
    } } };
    const file = { name: 'watersun_crm_export_2026-10-02.csv', size: 42 };
    const link = await createCrmExportShareLink(file, '11111111-1111-4111-8111-111111111111', client);
    assert.equal(link, 'https://example.test/signed');
    assert.match(calls[0][1], /^11111111-1111-4111-8111-111111111111\/[0-9a-f-]{36}\.csv$/);
    assert.equal(calls[1][1], calls[0][1]);
    assert.equal(calls[1][2], CRM_EXPORT_LINK_SECONDS);
    assert.equal(calls[1][3].download, file.name);
});

test('a failed signing attempt removes its private upload', async () => {
    let removed = '';
    const client = { storage: { from: () => ({
        upload: async () => ({ error: null }),
        createSignedUrl: async () => ({ data: null, error: { message: 'sign failed' } }),
        remove: async paths => { removed = paths[0]; return { error: null }; },
    }) } };
    await assert.rejects(createCrmExportShareLink({ name: 'export.csv', size: 2 }, 'user-id', client), /sign failed/);
    assert.match(removed, /^user-id\/[0-9a-f-]{36}\.csv$/);
});
