# CRM fix list (data-loss audit of 1–2 Oct 2026)

Status: DONE (live) · READY (in this folder; you deploy / run it) · OPEN · NOT DOING (with reason)

## Already repaired in the live data
- DONE: Restored the 4 lost values (Gulabnabi and Rajeshkumar inverter; Goswami panels; Vaghela modules). Backup table: `restore_backup_2026_10_01`.
- DONE: Restored the Discom Agreement tick for 141 customers with the agreement uploaded.

## Code changes: READY, not deployed
Checked before writing back: lint (0 errors), 35 unit tests, production build, and 13 checks of the real customer window in a simulated browser. Those 10 checks were also run against the OLD code, which failed the 4 that reproduce what users saw.

| # | Hole | What changed | Files |
|---|---|---|---|
| 1 | Window worked from a stale copy (lost values; "0 panels" for saved data) | One full record from the database; the list row never replaces it; out-of-date reloads ignored; unsaved typing always kept | `CustomerDetailModal.jsx`, `utils/saveCheck.js` |
| 2 | No check after saving | Every save (main Save, tab saves, Save & Move) re-reads the fields and names any that did not stick; they stay on screen as unsaved; the window does not close; a "SAVE CHECK FAILED" entry is logged | `CustomerDetailModal.jsx`, `utils/saveCheck.js` |
| 3 | Panel list editable while built from a partial copy | Panel list read-only until the full record has loaded ("Loading saved serials…"); it shows the working value, so a refresh cannot show different serials from the ones that will be saved | `MaterialIntegrationTab.jsx` |
| 4 | Save & Move checked the screen, not the database | Details are saved and confirmed first; the stage moves only after that. If a detail did not stick, the stage does NOT move. A failed move puts the form back on the real stage | `CustomerDetailModal.jsx` |
| 5 | Card stage dropdown checked only leaving Leads | Reads the real values before moving past Material Integration / Material Delivery: non-admins are stopped; admins see what is missing, confirm, and the skip is logged | `Dashboard.jsx`, `utils/stageRequirements.js` |
| 6 | Admin stage override on the Save button skipped checks | Same confirm and logging as the card | `CustomerDetailModal.jsx` |
| 7 | Same-field edits by two people (Goldi/Tata) | A clash is spotted when the colleague's save arrives; Save opens the existing conflict dialog instead of silently overwriting. The colleague banner is back on, without the false alarms (it no longer guesses from a 5-second window) | `CustomerDetailModal.jsx` |
| 8 | Log was not proof; several writers did not log | Field-by-field log (old → new) written only after the database confirms, for what was actually stored; tab saves, document ticks, delivery batches, agent portal and vendor geo removal | done 1 Oct + this change |
| 9 | Session restore after refresh used a stale snapshot | Covered by #1: the window always re-reads the record | (no separate change) |
| 10 | `discom_agreement` missing from `ADMIN_COLUMNS` | Added | `constants.js` (1 Oct) |
| 11 | Window left open overnight / laptop asleep missed colleagues' changes (live feed down), so a clash could not be spotted | The open customer window re-reads the record when you come back after 30s+, when the internet comes back, when the laptop wakes, and when the live feed reconnects. Typing is kept; same-field clashes open the conflict dialog | `CustomerDetailModal.jsx` |
| 12 | Dashboard replaced the open customer with the list row on list refreshes (needless re-reads; dropped columns) | Only when the row's `updated_at` is newer, and the list values are merged in instead of replacing the object. Lists, counts and search untouched | `Dashboard.jsx` |

## Database: READY, `scripts/2026-10-02_data_safety.sql` (not run)
Run one section at a time in the SQL Editor; each has a check and an undo. Tested on a local Postgres with a mock of this schema (14 scenarios).
1. DONE (run 2 Oct). **Audit history** (`admin_history`): every change to a customer, whoever or whatever made it; admin-only.
2. ON HOLD (to discuss before running). **Stage safety net:** a non-admin cannot move a customer out of Material Integration / Material Delivery while required details are empty in the database; admin skips go through and are recorded. Vendor portal, agent portal and Lost Project are unaffected.
3. DONE (run 2 Oct). **Completed date** stamped once (it moved on every edit).
4. **Duplicate `updated_at` triggers** dropped (functions kept).
5. **`v_incomplete_customers`** view: customers past a stage with that stage's details empty.

Still to run separately: `scripts/add_chat_availability_and_batch_order.sql` (the Team Chat and Availability tables do not exist yet).

## Backups: READY, `.github/workflows/daily-backup.yml`, `scripts/backup/export_tables.py`, `BACKUP_RUNBOOK.md`
- Pages through every table (the old backup was capped at 1,000 rows: 1,000 of 5,043 customers and 1,000 of 22,625 log entries). Tested read-only against the live database: every table complete and matching the server count.
- Fails loudly on any error or short table; nothing partial is committed.
- Adds 7 tables that were never backed up, plus login accounts and (once created) the audit history.
- One folder per run, `YYYY/MM/DD/HH-MM/` (India time); a second run on the same day gets its own folder.
- CSV only. Big tables are split into parts under 500 KB so GitHub still shows them as tables; `summary.csv` lists rows saved vs the server.
- Optional: full database dump (`SUPABASE_DB_URL`), uploaded-file copy to off-site storage, failure alert. See `BACKUP_RUNBOOK.md`.

## Deploys: READY, `workflow-updates/deploy.yml` (goes to `.github/workflows/`)
- Publishes only if lint (errors), unit tests and the build pass.
- `npm ci --legacy-peer-deps` (plain `npm ci` fails on this project: vite 8 vs @vitejs/plugin-react 4).
- Node 22 pinned; rollback steps in the file.

## Settings only you can change (OPEN)
- Protect `main` on GitHub (require a pull request), so the checks run before merging.
- Fine-grained `BACKUP_PAT` scoped to the backup repo, with an expiry reminder.
- Supabase Pro plan: managed backups and 7-day logs; the keep-alive job can then go.
- A second Supabase project for testing (localhost uses the live database).

## Suggested order to go live
0. Move the two workflow files into place (`.github/workflows/` is protected from remote edits, so they were saved next to it):
   `mv workflow-updates/daily-backup.yml workflow-updates/deploy.yml .github/workflows/ && rmdir workflow-updates`
1. Deploy the code (it works with or without the SQL).
2. Run SQL section 1 (audit history), then 2, 3, 4, 5.
3. Push the workflow changes; run "Daily Supabase Backup" once by hand from the Actions tab and check that run's `summary.csv` (last line: BACKUP COMPLETE).
4. Add the optional backup secrets.

## Pending decisions and data entry (not bugs)
- Dave Girdharlal Champalal: confirm Module Brand (GOLDI or TATA).
- Nadoda Jesangbhai Dalabhai: confirm Discom Inspection (No or Yes).
- 22 customers moved ahead with details not entered (Morvadia included): the team fills these in.
