# CRM database setup for chat, vendor calendar, service and red flags

The app's `.env` points to Supabase project `cjskyhxameobcqlfiuav`. The Supabase account connected to Codex currently exposes only `veopitwbxvgctaruhkia` (Ray2Volt Toolbox). **Run these files in the SQL Editor of `cjskyhxameobcqlfiuav` only.** The publishable app key is sufficient to check table presence but cannot create tables or storage policies.

Read-only checks against the configured CRM project on 2 October 2026 returned `PGRST205` (not available through the Data API) for `crm_chat_messages`, `crm_availability`, `service_issues`, `service_visits`, `service_issue_files`, and `customer_payment_review_flags`. The app key cannot tell whether a table is physically absent or not exposed by the Data API. `admin`, `profiles`, and `quotations` are available; `get_my_user_type()` responds. The export share-link action has been removed; no export-link bucket is needed.

First run this **read-only** check in that project's SQL Editor:

```sql
select to_regclass('public.crm_chat_messages') as chat,
       to_regclass('public.crm_availability') as vendor_calendar,
       to_regclass('public.service_issues') as service_issues,
       to_regclass('public.service_visits') as service_visits,
       to_regclass('public.service_issue_files') as service_files,
       to_regclass('public.customer_payment_review_flags') as payment_review;
select id, public from storage.buckets where id = 'service-issues';
```

## Run in this order

1. `scripts/add_chat_availability_and_batch_order.sql` — creates or updates private team chat and vendor-only calendar tables and policies. It is safe to rerun for the earlier table versions. The separate `scripts/vendor_calendar_only.sql` and `scripts/private_chat_for_everyone.sql` are historical patches; this base file includes their current rules.
2. `scripts/technician_service_portal.sql` — creates the Field Service Management issue, visit and file tables, functions, and private bucket. Run it only if `service_issues`, `service_visits`, and `service_issue_files` are all `NULL` in the preflight.
**Deferred:** `scripts/customer_payment_review_flags.sql` is the draft for a red flag at every customer stage. Do not run it yet; the app control is disabled. See `october batch.md` for the SQL and future rollout checks.

Vendor payment Excel download needs no new SQL from this set. Quotation Maker is paused; see `october batch.md`. Apply each file as a separate SQL Editor run so any error identifies the affected feature. If a service table already exists or the preflight shows mixed results, inspect its structure and policies before applying the service script. Stop at an error; do not retry the same file blindly or run it against another project.

If the vendor calendar reports that office setup is incomplete, run the first script in the CRM project's SQL Editor, then use **Try again** in the calendar. The script creates `crm_availability` when absent and grants only the access required by its vendor and office policies. A `PGRST205` response by itself does not prove the table is absent; the read-only `to_regclass` check above distinguishes a missing table from a Data API exposure problem.

## Verify after each run

```sql
select to_regclass('public.crm_chat_messages') as chat,
       to_regclass('public.crm_availability') as vendor_calendar,
       to_regclass('public.service_issues') as service_issues,
       to_regclass('public.service_visits') as service_visits,
       to_regclass('public.service_issue_files') as service_files,
       to_regclass('public.customer_payment_review_flags') as payment_review;

select id, public, file_size_limit from storage.buckets
where id = 'service-issues' order by id;

select tablename, policyname, cmd from pg_policies
where (schemaname = 'public' and tablename in
       ('crm_chat_messages', 'crm_availability', 'service_issues',
        'service_visits', 'service_issue_files', 'customer_payment_review_flags'))
   or (schemaname = 'storage' and tablename = 'objects'
       and policyname like 'service_issue_%')
order by schemaname, tablename, policyname;
```

Then sign in with a vendor, staff member, dealer, and technician account to check the actual row permissions. Confirm the top-right dashboard Export downloads a CSV and its completion popup offers only Done. The red-flag test is deferred until that feature is re-enabled.
