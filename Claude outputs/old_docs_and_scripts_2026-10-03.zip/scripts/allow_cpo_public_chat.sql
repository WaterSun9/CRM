-- Legacy filename. Apply private_chat_for_everyone.sql instead.
-- Kept safe in case this older script is run during a rollout.
begin;

drop policy if exists crm_chat_read on public.crm_chat_messages;
create policy crm_chat_read on public.crm_chat_messages for select to authenticated
using (
    public.get_my_user_type() in ('admin', 'sales', 'channel_partner_office', 'office2')
    or sender_id = (select auth.uid())
    or recipient_id = (select auth.uid())
);

drop policy if exists crm_chat_send on public.crm_chat_messages;
create policy crm_chat_send on public.crm_chat_messages for insert to authenticated
with check (
    sender_id = (select auth.uid())
    and audience = 'admin'
    and (
        (public.get_my_user_type() in ('admin', 'sales', 'channel_partner_office', 'office2') and recipient_id is not null)
        or (public.get_my_user_type() in ('agent', 'agent2', 'vendor', 'stamp', 'technician') and recipient_id is null)
    )
);

commit;
