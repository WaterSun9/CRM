-- WaterSun CRM release 4 Oct 2026 - PART 5 of 5: Protect profile name/email; profile rows admin-only.
-- Run parts 1 to 5 in order, each as its own run in the SQL Editor
-- (project cjskyhxameobcqlfiuav). Every part is safe to re-run.
--
-- If you see "lock timeout" or "deadlock detected": nothing in this part was
-- changed. Wait a minute (someone was saving at that moment) and run it again.
set lock_timeout = '8s';
begin;
-- ---------------------------------------------------------------------------
-- 4. Profiles: name and email are now protected like role/branch/status.
--    Vendor, agent, dealer and stamp access is matched by NAME, so a user who
--    renamed themselves could see another vendor's customers. Admin can still
--    change anything; a CPO can still edit users in their own branch; the
--    add_user function (server key) is unaffected.
--    Profile rows can only be created by Admin or the add_user function.
-- ---------------------------------------------------------------------------
create or replace function public.enforce_profile_privilege_changes()
returns trigger
language plpgsql
security definer
set search_path = public
as $function$
declare
    v_caller_type text;
    v_caller_cp   text;
    privileged_changed boolean;
begin
    privileged_changed :=
           (new.user_type       is distinct from old.user_type)
        or (new.role            is distinct from old.role)
        or (new.channel_partner is distinct from old.channel_partner)
        or (new.status          is distinct from old.status)
        or (new.name            is distinct from old.name)
        or (new.email           is distinct from old.email);

    if not privileged_changed then
        return new;
    end if;

    -- Server-side callers (add_user edge function / SQL editor) have no user.
    -- The public key cannot reach this: profiles has no anon policies.
    if auth.uid() is null then
        return new;
    end if;

    v_caller_type := get_my_user_type();
    v_caller_cp   := lower(trim(coalesce(get_my_channel_partner(), '')));

    if v_caller_type = 'admin' then
        return new;
    end if;

    -- A Channel Partner Office may manage their OWN branch, and only to the two
    -- roles their UI offers. They may not move a user to another branch.
    if v_caller_type = 'channel_partner_office'
       and v_caller_cp <> ''
       and lower(trim(coalesce(old.channel_partner, ''))) = v_caller_cp
       and new.channel_partner is not distinct from old.channel_partner
       and (new.user_type is not distinct from old.user_type
            or new.user_type in ('office2', 'agent2'))
    then
        return new;
    end if;

    raise exception
        'Not permitted: name, email, role, branch and status can only be changed by an Admin (or by a Channel Partner Office within their own branch).'
        using errcode = '42501';
end;
$function$;

drop policy if exists profiles_insert_scoped on public.profiles;
create policy profiles_insert_scoped on public.profiles
for insert to authenticated
with check (get_my_user_type() = 'admin');

commit;

-- Checks (read-only) - run after the commit:
-- select id, public from storage.buckets where id = 'customer-documents';          -- public = false
-- select policyname from pg_policies where schemaname='storage' and tablename='objects'; -- no "Allow all ..."
-- select has_function_privilege('anon','public.move_stage(uuid,text,text,text)','execute'); -- false
-- select proname from pg_proc where proname = 'save_bom_atomic';                   -- 1 row
-- select proname, proconfig from pg_proc where proname = 'get_my_user_type';       -- {search_path=public}
-- select tgname from pg_trigger where tgname = 'trg_assign_folder_no';             -- 1 row
-- select column_name from information_schema.columns where table_name='bom_items' and column_name='loaded'; -- 1 row
-- Then in the app: log in as admin -> open a customer -> view a document;
-- save a BOM; edit a delivery batch; move a stage.

