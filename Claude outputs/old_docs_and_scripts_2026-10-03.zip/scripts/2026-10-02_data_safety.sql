-- ═══════════════════════════════════════════════════════════════════════════
-- Data-safety changes from the audit of 1–2 Oct 2026.   NOT YET RUN.
--
-- Run in the Supabase SQL Editor ONE SECTION AT A TIME (highlight the section,
-- "Run selected"). Every section is its own transaction, can be re-run safely,
-- and has a check query and an undo block underneath it.
--
--   1. Audit history     - records every change to a customer (who, when, old → new)
--   2. Stage safety net  - a non-admin cannot move a customer out of Material
--                          Integration / Material Delivery while the required
--                          details are empty IN THE DATABASE. Admin skips are
--                          allowed and recorded in the audit history.
--   3. Completed date    - stamp completed_at once, not on every later edit
--   4. Duplicate triggers- drop two redundant "updated_at" triggers
--   5. Incomplete list   - a view of customers past a stage with its details empty
--
-- Run section 1 first: it creates the audit table and the stage_rank() helper
-- that sections 2 and 5 use.
-- ═══════════════════════════════════════════════════════════════════════════


-- ───────────────────────────────────────────────────────────────────────────
-- 1. AUDIT HISTORY
--
-- Why: the activity log is written by the app, so anything that bypasses the
-- app (SQL edits, batch functions, a bug) leaves no trace - which is why the
-- audit could not prove who or what changed a row. This trigger runs inside
-- the database on EVERY insert/update/delete of a customer, whatever caused it.
--
-- Effect on the app: none. It runs AFTER the change is saved and only records
-- the fields that actually changed, so it cannot block or slow a save
-- noticeably. Only admins can read the table.
-- ───────────────────────────────────────────────────────────────────────────
begin;

create table if not exists public.admin_history (
    id           bigint generated always as identity primary key,
    customer_id  uuid        not null,
    changed_at   timestamptz not null default now(),
    changed_by   uuid,                 -- auth.uid(); null = SQL editor / service key
    action       text        not null, -- INSERT | UPDATE | DELETE | STAGE_SKIP
    changes      jsonb       not null  -- {"field": {"old": ..., "new": ...}, ...}
);
create index if not exists admin_history_customer_idx on public.admin_history (customer_id, changed_at desc);
create index if not exists admin_history_changed_at_idx on public.admin_history (changed_at desc);

alter table public.admin_history enable row level security;
drop policy if exists admin_history_select_admin on public.admin_history;
create policy admin_history_select_admin on public.admin_history
    for select to authenticated
    using (get_my_user_type() = 'admin');
-- No insert/update/delete policies: only the trigger (security definer) writes,
-- and nobody can edit or delete history from the app.
revoke all on public.admin_history from anon;
revoke insert, update, delete on public.admin_history from authenticated;

create or replace function public.log_admin_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
    v_changes jsonb := '{}'::jsonb;
    v_old jsonb;
    v_new jsonb;
    v_key text;
begin
    if tg_op = 'INSERT' then
        insert into admin_history (customer_id, changed_by, action, changes)
        values (new.id, auth.uid(), 'INSERT',
                jsonb_build_object('customer_name', jsonb_build_object('old', null, 'new', new.customer_name),
                                   'stage',         jsonb_build_object('old', null, 'new', new.stage)));
        return new;
    elsif tg_op = 'DELETE' then
        insert into admin_history (customer_id, changed_by, action, changes)
        values (old.id, auth.uid(), 'DELETE', jsonb_build_object('row', to_jsonb(old)));
        return old;
    end if;

    v_old := to_jsonb(old);
    v_new := to_jsonb(new);
    for v_key in select jsonb_object_keys(v_new) loop
        continue when v_key in ('updated_at');
        if (v_old -> v_key) is distinct from (v_new -> v_key) then
            v_changes := v_changes || jsonb_build_object(
                v_key, jsonb_build_object('old', v_old -> v_key, 'new', v_new -> v_key));
        end if;
    end loop;

    if v_changes <> '{}'::jsonb then
        insert into admin_history (customer_id, changed_by, action, changes)
        values (new.id, auth.uid(), 'UPDATE', v_changes);
    end if;
    return new;
end;
$$;

create or replace function public.stage_rank(p_stage text)
returns int
language sql
immutable
as $$
    select case upper(coalesce(p_stage, ''))
        when 'LEADS' then 1
        when 'REGISTRATION' then 2
        when 'LOAN' then 3
        when 'CASH' then 3
        when 'MATERIAL ORDER' then 4
        when 'MATERIAL INTEGRATION' then 5
        when 'MATERIAL DELIVERY' then 6
        when 'INSTALLATION STATUS' then 7
        when 'GEO TAG PHOTO' then 8
        when 'DISCOM SUBMISSION' then 9
        when 'METER INSTALLATION' then 10
        when 'DISCOM INSPECTION' then 11
        when 'SUBSIDY STATUS' then 12
        when 'FINAL REVIEW' then 13
        when 'COMPLETED' then 14
        else null   -- LOST PROJECT and anything unknown: never checked
    end;
$$;

drop trigger if exists trg_admin_history on public.admin;
create trigger trg_admin_history
    after insert or update or delete on public.admin
    for each row execute function public.log_admin_change();

commit;

-- Check 1 (edit any test field on a customer in the CRM first, then):
--   select changed_at, changed_by, action, changes from admin_history order by changed_at desc limit 10;
-- Undo 1:
--   drop trigger if exists trg_admin_history on public.admin;
--   drop function if exists public.log_admin_change();
--   (stage_rank() can stay; drop it only after undoing sections 2 and 5)
--   -- (keep the admin_history table; it is the record)


-- ───────────────────────────────────────────────────────────────────────────
-- 2. STAGE SAFETY NET
--
-- Why: the screen checks the form, not the database. In the Gulabnabi case the
-- screen showed the inverter, the database did not, and the customer moved on.
-- With this rule that move fails with "Missing in the saved record: Inverter
-- make, Inverter serial no.", so the
-- problem shows up immediately instead of days later.
--
-- Scope (deliberately narrow so nothing else breaks):
--   * only FORWARD moves OUT OF Material Integration or Material Delivery
--   * only for NON-admin users. Admin skips (e.g. Sandip moving a customer
--     several stages at once) go through, and are recorded in admin_history as
--     STAGE_SKIP with the list of empty fields
--   * SQL editor / service-key changes (no logged-in user) are not checked
--   * Lost Project moves and Resume are not checked
--   * vendor portal and agent portal never move customers out of these two
--     stages, so they are unaffected
-- The fields are the same ones the customer window already requires.
-- ───────────────────────────────────────────────────────────────────────────
begin;



create or replace function public.check_stage_requirements()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
    v_old_rank int := stage_rank(old.stage);
    v_new_rank int := stage_rank(new.stage);
    v_missing text[] := '{}';
    v_is_admin boolean;
begin
    -- Only forward moves between known stages
    if new.stage is not distinct from old.stage
       or v_old_rank is null or v_new_rank is null or v_new_rank <= v_old_rank then
        return new;
    end if;

    -- Leaving Material Integration (or skipping past it)
    if v_old_rank <= 5 and v_new_rank > 5 then
        if coalesce(btrim(new.inverter_make), '') = '' then v_missing := array_append(v_missing, 'Inverter make'); end if;
        if coalesce(btrim(new.inverter_serial_no), '') = '' then v_missing := array_append(v_missing, 'Inverter serial number'); end if;
        if coalesce(btrim(new.panel_serial_no #>> '{}'), '') in ('', '[]', 'null') then
            v_missing := array_append(v_missing, 'Panel serial numbers');
        end if;
    end if;

    -- Leaving Material Delivery (or skipping past it)
    if v_old_rank <= 6 and v_new_rank > 6 then
        if coalesce(btrim(new.vendor), '') = '' then v_missing := array_append(v_missing, 'Vendor'); end if;
        if coalesce(btrim(new.invoice_no), '') = '' then v_missing := array_append(v_missing, 'Invoice number'); end if;
        if new.material_delivery_date is null then v_missing := array_append(v_missing, 'Delivery date'); end if;
        if coalesce(btrim(new.driver_name), '') = '' then v_missing := array_append(v_missing, 'Driver name'); end if;
        if coalesce(btrim(new.driver_phone_number::text), '') = '' then v_missing := array_append(v_missing, 'Driver phone'); end if;
    end if;

    if array_length(v_missing, 1) is null then
        return new;
    end if;

    -- SQL editor / service key: trusted, but still recorded
    if auth.uid() is null then
        v_is_admin := true;
    else
        v_is_admin := (get_my_user_type() = 'admin');
    end if;

    if v_is_admin then
        insert into admin_history (customer_id, changed_by, action, changes)
        values (new.id, auth.uid(), 'STAGE_SKIP', jsonb_build_object(
            'stage', jsonb_build_object('old', old.stage, 'new', new.stage),
            'missing', to_jsonb(v_missing)));
        return new;
    end if;

    raise exception 'Cannot move to %. Missing in the saved record: %. Enter the missing details, save, then move the stage again.',
        initcap(new.stage), array_to_string(v_missing, ', ')
        using errcode = 'P0001';
end;
$$;

drop trigger if exists trg_check_stage_requirements on public.admin;
create trigger trg_check_stage_requirements
    before update of stage on public.admin
    for each row execute function public.check_stage_requirements();

commit;

-- Check 2 (read-only - which stage moves the rule WOULD have blocked in the last 30 days):
--   select a.customer_name, h.changes->'stage' as move, h.changes->'missing' as missing, h.changed_at
--   from admin_history h join admin a on a.id = h.customer_id
--   where h.action = 'STAGE_SKIP' order by h.changed_at desc;
-- Undo 2:
--   drop trigger if exists trg_check_stage_requirements on public.admin;
--   drop function if exists public.check_stage_requirements();


-- ───────────────────────────────────────────────────────────────────────────
-- 3. COMPLETED DATE
-- Why: set_completed_at() re-stamped completed_at with now() on EVERY edit of a
-- completed customer, so "completed on" kept moving (3 customers moved by up
-- to 2 weeks). Now it is stamped once, on the move into Completed.
-- Effect: reports by completion month become stable. Dates already moved stay.
-- ───────────────────────────────────────────────────────────────────────────
begin;

create or replace function public.set_completed_at()
returns trigger
language plpgsql
as $$
begin
    if new.stage = 'COMPLETED' then
        if old.stage is distinct from 'COMPLETED' or old.completed_at is null then
            new.completed_at := now();
        else
            new.completed_at := old.completed_at;   -- keep the original date
        end if;
    else
        new.completed_at := null;
    end if;
    return new;
end;
$$;

commit;

-- Undo 3 (previous behaviour):
--   create or replace function public.set_completed_at() returns trigger language plpgsql as $f$
--   begin if new.stage = 'COMPLETED' then new.completed_at = now(); else new.completed_at = null; end if; return new; end; $f$;


-- ───────────────────────────────────────────────────────────────────────────
-- 4. DUPLICATE "updated_at" TRIGGERS
-- Three triggers on admin all set updated_at = now(). Keep the one from
-- scripts/add_updated_at_trigger.sql and drop the other two TRIGGERS.
-- The FUNCTIONS are left in place - other tables may use them.
-- Effect: none (updated_at is still set on every update).
-- ───────────────────────────────────────────────────────────────────────────
begin;
drop trigger if exists admin_updated_at on public.admin;
drop trigger if exists update_admin_updated_at on public.admin;
commit;

-- Check 4:
--   select tgname from pg_trigger where tgrelid = 'public.admin'::regclass and not tgisinternal;
--   -- expect: trigger_set_admin_updated_at, trigger_set_completed_at (+ trg_admin_history, trg_check_stage_requirements)
-- Undo 4:
--   create trigger admin_updated_at before update on public.admin for each row execute function update_timestamp();
--   create trigger update_admin_updated_at before update on public.admin for each row execute function update_updated_at_column();


-- ───────────────────────────────────────────────────────────────────────────
-- 5. INCOMPLETE-CUSTOMERS LIST (read-only view; needs Postgres 15+ for security_invoker -
--    Supabase projects created since 2023 are 15 or newer)
-- Customers past Material Integration / Material Delivery whose details for
-- that stage are still empty. security_invoker = each user only sees the
-- customers they are already allowed to see.
-- ───────────────────────────────────────────────────────────────────────────
begin;

create or replace view public.v_incomplete_customers
with (security_invoker = true) as
select
    a.id, a.customer_name, a.folder_no, a.consumer_no, a.stage, a.channel_partner,
    array_remove(array[
        case when stage_rank(a.stage) > 5 and coalesce(btrim(a.inverter_make), '') = '' then 'Inverter make' end,
        case when stage_rank(a.stage) > 5 and coalesce(btrim(a.inverter_serial_no), '') = '' then 'Inverter serial number' end,
        case when stage_rank(a.stage) > 5 and coalesce(btrim(a.panel_serial_no #>> '{}'), '') in ('', '[]', 'null') then 'Panel serial numbers' end,
        case when stage_rank(a.stage) > 6 and coalesce(btrim(a.vendor), '') = '' then 'Vendor' end
    ], null) as missing
from public.admin a
where a.deleted_at is null
  and a.created_at >= '2026-09-02'          -- skip the 1 Sep bulk import, which never had these details
  and stage_rank(a.stage) > 5
  and (coalesce(btrim(a.inverter_make), '') = ''
       or coalesce(btrim(a.inverter_serial_no), '') = ''
       or coalesce(btrim(a.panel_serial_no #>> '{}'), '') in ('', '[]', 'null')
       or (stage_rank(a.stage) > 6 and coalesce(btrim(a.vendor), '') = ''));

commit;

-- Check 5:  select * from v_incomplete_customers order by stage, customer_name;   -- 22 rows on 1 Oct
-- Undo 5:   drop view if exists public.v_incomplete_customers;
