-- Fix for repeated HTTP 400 delivery batch saves on 2026-10-03.
-- Live Postgres log SQLSTATE 42804: dispatch_date is date but RPC passed text.
-- The same RPC also needs numeric rent/phone and uuid[] project IDs.
-- Run this whole file once in the CRM project's Supabase SQL Editor.
-- It replaces only this function. It does not edit any batch/customer rows.

create or replace function public.save_delivery_batch_atomic(
    p_batch jsonb,
    p_selected_project_ids text[],
    p_removed_project_ids text[] default '{}'::text[]
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
    v_batch_id uuid;
    v_batch_no text;
    v_dispatch_date date;
    v_driver_name text;
    v_driver_phone numeric;
    v_vehicle_number text;
    v_vendor text;
    v_status text;
    v_rent_amount numeric;
    v_car_rent_paid text;
    v_car_rent_paid_by text;
    v_car_rent_paid_at text;
    v_notes text;
    v_created_at timestamptz;
    v_selected_project_ids uuid[];
    v_removed_project_ids uuid[];
begin
    -- Extract batch fields from JSON
    v_batch_id := (p_batch->>'id')::uuid;
    v_batch_no := p_batch->>'batch_no';
    v_dispatch_date := nullif(p_batch->>'dispatch_date', '')::date;
    v_driver_name := p_batch->>'driver_name';
    v_driver_phone := nullif(regexp_replace(coalesce(p_batch->>'driver_phone', ''), '[^0-9]', '', 'g'), '')::numeric;
    v_vehicle_number := p_batch->>'vehicle_number';
    v_vendor := p_batch->>'vendor';
    v_status := coalesce(p_batch->>'status', 'IN_TRANSIT');
    v_rent_amount := nullif(regexp_replace(coalesce(p_batch->>'rent_amount', ''), '[^0-9.-]', '', 'g'), '')::numeric;
    v_car_rent_paid := p_batch->>'car_rent_paid';
    v_car_rent_paid_by := p_batch->>'car_rent_paid_by';
    v_car_rent_paid_at := p_batch->>'car_rent_paid_at';
    v_notes := p_batch->>'notes';
    v_created_at := coalesce((p_batch->>'created_at')::timestamptz, now());
    v_selected_project_ids := array(select id_text::uuid from unnest(coalesce(p_selected_project_ids, '{}'::text[])) as u(id_text));
    v_removed_project_ids := array(select id_text::uuid from unnest(coalesce(p_removed_project_ids, '{}'::text[])) as u(id_text));

    -- Upsert the delivery batch row
    insert into public.delivery_batches (
        id,
        batch_no,
        dispatch_date,
        driver_name,
        driver_phone,
        vehicle_number,
        rent_amount,
        car_rent_paid,
        car_rent_paid_by,
        car_rent_paid_at,
        vendor,
        notes,
        status,
        project_ids,
        created_at,
        updated_at
    )
    values (
        v_batch_id,
        v_batch_no,
        v_dispatch_date,
        v_driver_name,
        v_driver_phone,
        v_vehicle_number,
        v_rent_amount,
        v_car_rent_paid,
        v_car_rent_paid_by,
        v_car_rent_paid_at,
        v_vendor,
        v_notes,
        v_status,
        v_selected_project_ids,
        v_created_at,
        now()
    )
    on conflict (id) do update set
        batch_no = excluded.batch_no,
        dispatch_date = excluded.dispatch_date,
        driver_name = excluded.driver_name,
        driver_phone = excluded.driver_phone,
        vehicle_number = excluded.vehicle_number,
        rent_amount = excluded.rent_amount,
        car_rent_paid = excluded.car_rent_paid,
        car_rent_paid_by = excluded.car_rent_paid_by,
        car_rent_paid_at = excluded.car_rent_paid_at,
        vendor = excluded.vendor,
        notes = excluded.notes,
        status = excluded.status,
        project_ids = excluded.project_ids,
        updated_at = now();

    -- Bulk update all newly/currently selected projects in public.admin
    if cardinality(v_selected_project_ids) > 0 then
        update public.admin
        set
            delivery_batch_id = v_batch_no,
            material_delivery_date = v_dispatch_date,
            driver_name = v_driver_name,
            driver_phone_number = v_driver_phone,
            vehicle_number = v_vehicle_number,
            vendor = coalesce(v_vendor, vendor),
            delivery_status = case 
                when delivery_status is null or delivery_status = 'PENDING' then 'IN_TRANSIT'
                else delivery_status
            end,
            updated_at = now()
        where id = any(v_selected_project_ids)
          and deleted_at is null;
    end if;

    -- Bulk clear any projects that were removed/unchecked from this batch
    if cardinality(v_removed_project_ids) > 0 then
        update public.admin
        set
            delivery_batch_id = null,
            delivery_status = 'PENDING',
            driver_name = null,
            driver_phone_number = null,
            vehicle_number = null,
            material_delivery_date = null,
            updated_at = now()
        where id = any(v_removed_project_ids)
          and deleted_at is null;
    end if;

    return jsonb_build_object('success', true, 'batch_id', v_batch_id);
end;
$$;

grant execute on function public.save_delivery_batch_atomic(jsonb, text[], text[])
    to authenticated, service_role;

-- Both values should be true after the function is installed.
select
    position('v_dispatch_date date' in pg_get_functiondef(
        'public.save_delivery_batch_atomic(jsonb,text[],text[])'::regprocedure
    )) > 0 as dispatch_date_typed,
    position('v_selected_project_ids uuid[]' in pg_get_functiondef(
        'public.save_delivery_batch_atomic(jsonb,text[],text[])'::regprocedure
    )) > 0 as project_ids_typed;
