-- Retired: the dashboard export share-link action was removed in October 2026.
-- Do not run this script for the current CRM. It is retained for historical reference.
-- Exports stay private; only an admin can upload/sign their own CSV.
begin;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('crm-exports', 'crm-exports', false, 104857600, array['text/csv'])
on conflict (id) do update set public = false,
    file_size_limit = excluded.file_size_limit,
    allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists crm_exports_upload on storage.objects;
create policy crm_exports_upload on storage.objects for insert to authenticated
with check (
    bucket_id = 'crm-exports'
    and public.get_my_user_type() = 'admin'
    and split_part(name, '/', 1) = (select auth.uid())::text
    and name ~ '^[0-9a-f-]{36}/[0-9a-f-]{36}\.csv$'
);

drop policy if exists crm_exports_read on storage.objects;
create policy crm_exports_read on storage.objects for select to authenticated
using (
    bucket_id = 'crm-exports'
    and public.get_my_user_type() = 'admin'
    and split_part(name, '/', 1) = (select auth.uid())::text
);

drop policy if exists crm_exports_remove on storage.objects;
create policy crm_exports_remove on storage.objects for delete to authenticated
using (
    bucket_id = 'crm-exports'
    and public.get_my_user_type() = 'admin'
    and split_part(name, '/', 1) = (select auth.uid())::text
);

commit;
