-- Apply after add_chat_availability_and_batch_order.sql if that script was
-- already run. If it was not run yet, use the updated base script instead.
begin;

alter table public.crm_chat_messages enable row level security;
grant select, insert on public.crm_chat_messages to authenticated;
revoke all on public.crm_chat_messages from anon;

drop policy if exists crm_chat_read on public.crm_chat_messages;
create policy crm_chat_read on public.crm_chat_messages for select to authenticated
using (
    public.get_my_user_type() in ('admin', 'sales', 'channel_partner_office', 'office2')
    or sender_id = (select auth.uid())
    or recipient_id = (select auth.uid())
);

drop policy if exists crm_chat_send on public.crm_chat_messages;
create policy crm_chat_send on public.crm_chat_messages for insert to authenticated
with check (
    sender_id = (select auth.uid())
    and audience = 'admin'
    and (
        (public.get_my_user_type() in ('admin', 'sales', 'channel_partner_office', 'office2') and recipient_id is not null)
        or (public.get_my_user_type() in ('agent', 'agent2', 'vendor', 'stamp', 'technician') and recipient_id is null)
    )
);

commit;
