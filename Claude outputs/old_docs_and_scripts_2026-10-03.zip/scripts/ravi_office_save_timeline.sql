-- READ ONLY. Run this single query in the SQL Editor of cjskyhxameobcqlfiuav.
-- APP LOG = what the app reported; DATABASE CHANGE = a committed admin write.
-- The audit trigger only covers changes after it was installed on 2 Oct 2026.
with ravi as (
    select id, name from public.profiles where name ilike '%ravi%office%'
), events as (
    select l.created_at as happened_at, 'APP LOG'::text as source,
           r.name as actor, l.customer_id, a.customer_name,
           l.message as details
    from public.activity_log l
    join ravi r on r.id = l.user_id
    left join public.admin a on a.id = l.customer_id
    where l.created_at >= now() - interval '14 days'

    union all

    select h.changed_at, 'DATABASE CHANGE',
           coalesce(r.name, 'Another user / SQL editor'),
           h.customer_id, a.customer_name,
           h.action || ': ' || h.changes::text
    from public.admin_history h
    left join ravi r on r.id = h.changed_by
    left join public.admin a on a.id = h.customer_id
    where h.changed_at >= now() - interval '14 days'
      and (r.id is not null or h.customer_id in (
          select l.customer_id
          from public.activity_log l
          join ravi rv on rv.id = l.user_id
          where l.created_at >= now() - interval '14 days'
      ))
)
select happened_at at time zone 'Asia/Kolkata' as happened_at_ist,
       source, actor, customer_id, customer_name, details
from events
order by happened_at desc
limit 200;
