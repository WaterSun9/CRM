-- READ ONLY. Run on project cjskyhxameobcqlfiuav.
-- Shows the 36 Oct 3 customer statuses Ravi's batch edits changed from
-- DELIVERED to IN_TRANSIT, plus current batch status and any later status edit.
with ravi as (
    select id from public.profiles where name ilike '%ravi%office%'
), reversals as (
    select distinct on (h.customer_id)
           h.customer_id, h.changed_at, h.id as history_id
    from public.admin_history h
    join ravi r on r.id = h.changed_by
    where h.changed_at >= '2026-10-02 18:30:00+00'::timestamptz
      and h.changed_at <  '2026-10-03 18:30:00+00'::timestamptz
      and h.changes -> 'delivery_status' ->> 'old' = 'DELIVERED'
      and h.changes -> 'delivery_status' ->> 'new' = 'IN_TRANSIT'
    order by h.customer_id, h.changed_at desc, h.id desc
)
select r.changed_at at time zone 'Asia/Kolkata' as reverted_at_ist,
       a.id as customer_id, a.customer_name, a.delivery_status as current_customer_status,
       a.delivery_batch_id, b.status as current_batch_status,
       exists (
           select 1 from public.admin_history later
           where later.customer_id = r.customer_id
             and later.id > r.history_id
             and later.changes ? 'delivery_status'
       ) as delivery_status_changed_later
from reversals r
join public.admin a on a.id = r.customer_id
left join lateral (
    select status from public.delivery_batches b
    where b.batch_no = a.delivery_batch_id
    order by b.updated_at desc nulls last
    limit 1
) b on true
order by r.changed_at desc, a.customer_name;
