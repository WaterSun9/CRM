-- Customer red flags (Oct 2026). Safe to re-run.
-- Run in the CRM project (cjskyhxameobcqlfiuav) SQL Editor.
--
-- One red flag per customer, any stage, no reason needed, blocks nothing.
-- Who can see and raise/remove it: Admin, Sales, Channel Partner Office and its
-- staff (office2 / channel_partner_office_manager), Channel Partners (agent) and
-- Dealers (agent2) - and only on customers their normal access already shows
-- them (the EXISTS on public.admin goes through admin's own RLS).
-- The table keeps its original name so existing app queries keep working.
--
-- Rollback:  drop table if exists public.customer_payment_review_flags;
begin;

create table if not exists public.customer_payment_review_flags (
    admin_id   uuid primary key references public.admin(id) on delete cascade,
    active     boolean not null default true,
    updated_by uuid not null references auth.users(id),
    updated_at timestamptz not null default now()
);

alter table public.customer_payment_review_flags enable row level security;
revoke all on public.customer_payment_review_flags from anon, public;
grant select, insert, update on public.customer_payment_review_flags to authenticated;

drop policy if exists customer_payment_flags_read   on public.customer_payment_review_flags;
drop policy if exists customer_payment_flags_create on public.customer_payment_review_flags;
drop policy if exists customer_payment_flags_update on public.customer_payment_review_flags;

create policy customer_payment_flags_read on public.customer_payment_review_flags
for select to authenticated
using (
    (select public.get_my_user_type()) in
        ('admin', 'sales', 'channel_partner_office', 'office2', 'channel_partner_office_manager', 'agent', 'agent2')
    and exists (select 1 from public.admin customer
                where customer.id = admin_id and customer.deleted_at is null)
);

create policy customer_payment_flags_create on public.customer_payment_review_flags
for insert to authenticated
with check (
    (select public.get_my_user_type()) in
        ('admin', 'sales', 'channel_partner_office', 'office2', 'channel_partner_office_manager', 'agent', 'agent2')
    and updated_by = (select auth.uid())
    and exists (select 1 from public.admin customer
                where customer.id = admin_id and customer.deleted_at is null)
);

create policy customer_payment_flags_update on public.customer_payment_review_flags
for update to authenticated
using (
    (select public.get_my_user_type()) in
        ('admin', 'sales', 'channel_partner_office', 'office2', 'channel_partner_office_manager', 'agent', 'agent2')
    and exists (select 1 from public.admin customer
                where customer.id = admin_id and customer.deleted_at is null)
)
with check (
    (select public.get_my_user_type()) in
        ('admin', 'sales', 'channel_partner_office', 'office2', 'channel_partner_office_manager', 'agent', 'agent2')
    and updated_by = (select auth.uid())
    and exists (select 1 from public.admin customer
                where customer.id = admin_id and customer.deleted_at is null)
);

commit;

-- Check after running (expect 3 policies, rls = true):
-- select policyname, cmd from pg_policies where tablename = 'customer_payment_review_flags';
-- select relrowsecurity from pg_class where relname = 'customer_payment_review_flags';
