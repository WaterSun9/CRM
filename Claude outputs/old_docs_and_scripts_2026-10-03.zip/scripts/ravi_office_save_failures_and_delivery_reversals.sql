-- READ ONLY. Run this single query in the CRM project's SQL Editor.
-- It returns Ravi's confirmed DELIVERED -> IN_TRANSIT reversals and every
-- recent app-reported save-check failure. Export the whole result as CSV.
with ravi as (
    select id from public.profiles where name ilike '%ravi%office%'
), findings as (
    select h.changed_at as happened_at,
           'DELIVERED REVERSED'::text as finding,
           h.customer_id, a.customer_name,
           'DELIVERED -> IN_TRANSIT'::text as attempted_or_changed,
           a.delivery_status::text as currently_stored,
           a.delivery_batch_id::text as batch_id,
           h.changes::text as evidence
    from public.admin_history h
    join ravi r on r.id = h.changed_by
    left join public.admin a on a.id = h.customer_id
    where h.changed_at >= now() - interval '14 days'
      and h.changes -> 'delivery_status' ->> 'old' = 'DELIVERED'
      and h.changes -> 'delivery_status' ->> 'new' = 'IN_TRANSIT'

    union all

    select l.created_at, 'SAVE CHECK FAILED', l.customer_id,
           a.customer_name, l.message, null::text,
           a.delivery_batch_id::text, l.new_value
    from public.activity_log l
    left join public.admin a on a.id = l.customer_id
    where l.created_at >= now() - interval '14 days'
      and l.message ilike '%SAVE CHECK FAILED%'
)
select happened_at at time zone 'Asia/Kolkata' as happened_at_ist,
       finding, customer_id, customer_name, attempted_or_changed,
       currently_stored, batch_id, evidence
from findings
order by happened_at desc;
