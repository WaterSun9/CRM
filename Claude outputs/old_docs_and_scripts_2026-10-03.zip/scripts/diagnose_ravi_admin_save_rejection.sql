-- READ ONLY. Run as one query in the SQL Editor of cjskyhxameobcqlfiuav.
-- The popup came from an `admin` UPDATE. This checks Ravi's role, whether the
-- three likely customers still exist, their branch scope, and live RLS rules.
with ravi as (
    select p.id, p.name, to_jsonb(p)->>'user_type' as user_type,
           to_jsonb(p)->>'channel_partner' as account_branch
    from public.profiles p
    where p.name ilike '%ravi%office%'
), targets(id) as (
    values
      ('79d3a3c5-2e3f-4573-94bd-e056965a80ce'::uuid),
      ('b9e8f0d7-c18d-4695-a1d6-6993be875085'::uuid),
      ('2cb8051d-ebf7-4a75-9f28-5326a958b74d'::uuid)
)
select r.name as account, r.user_type, r.account_branch,
       a.id as customer_id, a.customer_name,
       a.channel_partner as customer_branch, a.sub_channel_partner,
       a.stage, a.deleted_at,
       (select array_agg(v.column_name order by v.column_name)
        from (values ('roof_shed'), ('dc_cable'), ('ac_cable'),
                     ('invoice_value'), ('structure_front_leg_height'),
                     ('structure_rear_leg_height'), ('inverter_make'),
                     ('inverter_serial_no'), ('panel_serial_no'),
                     ('vendor'), ('invoice_no'), ('material_delivery_date'),
                     ('driver_name'), ('driver_phone_number'),
                     ('delivery_status'), ('stages_remarks'), ('stage')) v(column_name)
        where not exists (
            select 1 from information_schema.columns c
            where c.table_schema = 'public' and c.table_name = 'admin'
              and c.column_name = v.column_name
        )) as missing_delivery_columns,
       (select jsonb_agg(jsonb_build_object(
           'name', policyname, 'command', cmd, 'roles', roles,
           'using', qual, 'with_check', with_check
       ) order by policyname)
        from pg_policies
        where schemaname = 'public' and tablename = 'admin'
          and cmd in ('SELECT', 'UPDATE', 'ALL')) as admin_policies
from targets t
left join public.admin a on a.id = t.id
cross join ravi r
order by a.customer_name;
