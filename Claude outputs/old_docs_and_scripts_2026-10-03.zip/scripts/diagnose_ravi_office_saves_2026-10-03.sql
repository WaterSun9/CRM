-- Ravi Office save investigation. READ ONLY.
-- Run each numbered query in the SQL Editor of project cjskyhxameobcqlfiuav.
-- Time window: last 14 days; increase interval if the popup began earlier.

-- 1. Identify the account and its role. If more than one row appears, use the
--    exact profile name/user ID in the queries below.
select p.id, p.name, to_jsonb(p)->>'user_type' as user_type,
       to_jsonb(p)->>'role' as role,
       to_jsonb(p)->>'channel_partner' as channel_partner
from public.profiles p
where name ilike '%ravi%office%'
order by name;

-- 2. All recent Ravi Office activity and any save-check failures. The log is
--    evidence of what the app reported/attempted, not proof of a database write.
select l.created_at at time zone 'Asia/Kolkata' as happened_at_ist,
       p.name as actor, l.customer_id, a.customer_name,
       l.action, l.message, l.new_value,
       a.updated_at at time zone 'Asia/Kolkata' as customer_updated_at_ist
from public.activity_log l
left join public.profiles p on p.id = l.user_id
left join public.admin a on a.id = l.customer_id
where l.created_at >= now() - interval '14 days'
  and (p.name ilike '%ravi%office%' or l.message ilike '%SAVE CHECK FAILED%')
order by l.created_at desc
limit 300;

-- 3. Ravi's recent customer activity grouped by customer. This points to rows
--    to inspect even when a failed save left no activity-log entry.
select l.customer_id, a.customer_name, a.stage,
       count(*) as activity_entries,
       max(l.created_at) at time zone 'Asia/Kolkata' as last_activity_ist,
       a.updated_at at time zone 'Asia/Kolkata' as row_updated_at_ist,
       count(*) filter (where l.message ilike '%SAVE CHECK FAILED%') as save_check_failures
from public.activity_log l
join public.profiles p on p.id = l.user_id
left join public.admin a on a.id = l.customer_id
where p.name ilike '%ravi%office%'
  and l.created_at >= now() - interval '14 days'
group by l.customer_id, a.customer_name, a.stage, a.updated_at
order by last_activity_ist desc
limit 100;

-- 4. For every named save-check failure, show the value CURRENTLY stored in
--    the database for each field named by the app. This does not reveal the
--    attempted value, which that log message did not record.
with failures as (
  select l.created_at, l.customer_id, a.customer_name, l.message,
         split_part(l.message, 'not stored: ', 2) as field_list,
         to_jsonb(a) as stored_row
  from public.activity_log l
  join public.admin a on a.id = l.customer_id
  where l.created_at >= now() - interval '14 days'
    and l.message ilike '%SAVE CHECK FAILED - not stored:%'
), fields as (
  select f.*, lower(replace(trim(x.field_label), ' ', '_')) as field_name
  from failures f
  cross join lateral regexp_split_to_table(f.field_list, ',\s*') as x(field_label)
)
select created_at at time zone 'Asia/Kolkata' as failed_at_ist,
       customer_name, customer_id, field_name,
       stored_row -> field_name as currently_stored_value, message
from fields
order by created_at desc, customer_name, field_name
limit 200;

-- 5. Run only if public.admin_history exists (the 2 Oct audit migration).
--    This records successful database changes, including who changed which
--    field and its before/after values. No row here means no confirmed UPDATE
--    during this window; a rejected attempt leaves no history row.
select h.changed_at at time zone 'Asia/Kolkata' as changed_at_ist,
       p.name as actor, h.customer_id, a.customer_name,
       h.action, h.changes
from public.admin_history h
left join public.profiles p on p.id = h.changed_by
left join public.admin a on a.id = h.customer_id
where h.changed_at >= now() - interval '14 days'
  and (p.name ilike '%ravi%office%'
       or h.customer_id in (
         select l.customer_id from public.activity_log l
         join public.profiles rp on rp.id = l.user_id
         where rp.name ilike '%ravi%office%'
           and l.created_at >= now() - interval '14 days'
       ))
order by h.changed_at desc
limit 300;

-- 6. Read-only schema checks for a repeatable database rejection. A missing
--    column, restrictive UPDATE/SELECT policy, or a trigger exception can
--    reject a whole save. These definitions aid diagnosis; they do not prove
--    which error Ravi saw. Copy the complete popup text as well.
select column_name, data_type
from information_schema.columns
where table_schema = 'public' and table_name = 'admin'
order by ordinal_position;

select policyname, cmd, roles, qual, with_check
from pg_policies
where schemaname = 'public' and tablename = 'admin'
order by policyname;

select tg.tgname as trigger_name, pg_get_triggerdef(tg.oid) as definition,
       p.proname as function_name
from pg_trigger tg
join pg_class c on c.oid = tg.tgrelid
join pg_namespace n on n.oid = c.relnamespace
join pg_proc p on p.oid = tg.tgfoid
where n.nspname = 'public' and c.relname = 'admin' and not tg.tgisinternal
order by tg.tgname;
