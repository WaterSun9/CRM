-- Apply before deploying the matching UI. Creates or updates only chat and
-- availability tables. Safe to rerun if their earlier versions already exist.
-- Does not alter, update, or index public.admin.
begin;

create table if not exists public.crm_chat_messages (
    id uuid primary key default gen_random_uuid(),
    sender_id uuid not null references auth.users(id),
    recipient_id uuid references auth.users(id),
    audience text not null check (audience in ('public', 'admin')),
    constraint crm_chat_public_no_recipient check (audience = 'admin' or recipient_id is null),
    topic text not null check (topic in ('general', 'installation', 'material_delivery')),
    body text not null check (length(trim(body)) between 1 and 2000),
    created_at timestamptz not null default now()
);
create index if not exists crm_chat_messages_audience_time_idx on public.crm_chat_messages (audience, created_at desc);
create index if not exists crm_chat_messages_sender_time_idx on public.crm_chat_messages (sender_id, created_at desc);
alter table public.crm_chat_messages enable row level security;
grant select, insert on public.crm_chat_messages to authenticated;
revoke all on public.crm_chat_messages from anon;

drop policy if exists crm_chat_read on public.crm_chat_messages;
create policy crm_chat_read on public.crm_chat_messages for select to authenticated
using (
    public.get_my_user_type() in ('admin', 'sales', 'channel_partner_office', 'office2')
    or sender_id = (select auth.uid())
    or recipient_id = (select auth.uid())
);
drop policy if exists crm_chat_send on public.crm_chat_messages;
create policy crm_chat_send on public.crm_chat_messages for insert to authenticated
with check (
    sender_id = (select auth.uid())
    and audience = 'admin'
    and (
        (public.get_my_user_type() in ('admin', 'sales', 'channel_partner_office', 'office2') and recipient_id is not null)
        or (public.get_my_user_type() in ('agent', 'agent2', 'vendor', 'stamp', 'technician') and recipient_id is null)
    )
);

create table if not exists public.crm_availability (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references auth.users(id),
    vendor_name text not null default '',
    entry_kind text not null check (entry_kind in ('vendor_unavailable', 'staff_leave')),
    start_date date not null,
    end_date date not null,
    note text not null default '' check (length(note) <= 500),
    status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
    created_at timestamptz not null default now(),
    reviewed_at timestamptz,
    reviewed_by uuid references auth.users(id),
    unique (user_id, entry_kind, start_date, end_date),
    check (end_date >= start_date),
    check (end_date <= start_date + 365)
);
alter table public.crm_availability add column if not exists vendor_name text not null default '';
update public.crm_availability entry set vendor_name = coalesce(profile.name, 'Vendor')
from public.profiles profile
where entry.user_id = profile.id and entry.entry_kind = 'vendor_unavailable' and entry.vendor_name = '';
create index if not exists crm_availability_dates_idx on public.crm_availability (start_date, end_date);
create index if not exists crm_availability_user_idx on public.crm_availability (user_id, start_date desc);
alter table public.crm_availability enable row level security;
grant select, insert, delete on public.crm_availability to authenticated;
revoke update on public.crm_availability from authenticated;
revoke all on public.crm_availability from anon;

create or replace function public.set_crm_availability_vendor_name()
returns trigger language plpgsql security invoker set search_path = public, pg_temp as $$
begin
    new.vendor_name := coalesce((select name from public.profiles where id = auth.uid()), 'Vendor');
    return new;
end;
$$;
drop trigger if exists crm_availability_vendor_name on public.crm_availability;
create trigger crm_availability_vendor_name before insert on public.crm_availability
for each row execute function public.set_crm_availability_vendor_name();

drop policy if exists crm_availability_read on public.crm_availability;
create policy crm_availability_read on public.crm_availability for select to authenticated
using (
    entry_kind = 'vendor_unavailable'
    and (public.get_my_user_type() in ('admin', 'sales', 'channel_partner_office', 'office2')
         or (public.get_my_user_type() = 'vendor' and user_id = (select auth.uid())))
);
drop policy if exists crm_availability_create on public.crm_availability;
create policy crm_availability_create on public.crm_availability for insert to authenticated
with check (
    user_id = (select auth.uid()) and reviewed_at is null and reviewed_by is null
    and public.get_my_user_type() = 'vendor' and entry_kind = 'vendor_unavailable' and status = 'approved'
);
drop policy if exists crm_availability_admin_review on public.crm_availability;
drop policy if exists crm_availability_remove on public.crm_availability;
create policy crm_availability_remove on public.crm_availability for delete to authenticated
using (public.get_my_user_type() = 'vendor' and user_id = (select auth.uid()) and entry_kind = 'vendor_unavailable');

-- delivery_batches.project_ids already stores the route order; no batch schema
-- change is needed. Reordering updates only that batch row.

commit;
