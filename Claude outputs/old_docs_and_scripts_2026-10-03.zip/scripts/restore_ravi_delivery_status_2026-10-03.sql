-- SEPARATE ISSUE from the 10:25-10:30 "didn't save" popup. Do not use this
-- script to investigate or fix that popup.
-- Restore the 36 Ravi Office delivery statuses reversed by batch edits on
-- 3 Oct 2026. Run this ONE statement in project cjskyhxameobcqlfiuav.
-- Verified preview: 36 customers are still IN_TRANSIT, their batches are
-- DELIVERED, and none has a later delivery_status edit.
-- Safety: if the qualifying set is no longer exactly 36, this updates ZERO
-- rows. The admin_history trigger records each restoration automatically.
-- Expected result: exactly 36 returned rows, all with DELIVERED status.
with ravi as (
    select id from public.profiles where name ilike '%ravi%office%'
), reversals as (
    select distinct on (h.customer_id)
           h.customer_id, h.changed_at, h.id as history_id
    from public.admin_history h
    join ravi r on r.id = h.changed_by
    where h.changed_at >= '2026-10-03 11:35:00+05:30'::timestamptz
      and h.changed_at <  '2026-10-03 11:58:00+05:30'::timestamptz
      and h.changes -> 'delivery_status' ->> 'old' = 'DELIVERED'
      and h.changes -> 'delivery_status' ->> 'new' = 'IN_TRANSIT'
    order by h.customer_id, h.changed_at desc, h.id desc
), eligible as (
    select a.id
    from public.admin a
    join reversals r on r.customer_id = a.id
    where a.delivery_status = 'IN_TRANSIT'
      and a.deleted_at is null
      and exists (
          select 1 from public.delivery_batches b
          where b.batch_no = a.delivery_batch_id and b.status = 'DELIVERED'
      )
      and not exists (
          select 1 from public.admin_history later
          where later.customer_id = r.customer_id
            and later.id > r.history_id
            and later.changes ? 'delivery_status'
      )
), guard as (
    select count(*) as eligible_count from eligible
)
update public.admin a
set delivery_status = 'DELIVERED'
where a.id in (
    select e.id from eligible e cross join guard g
    where g.eligible_count = 36
)
  and a.delivery_status = 'IN_TRANSIT'
returning a.id, a.customer_name, a.delivery_batch_id, a.delivery_status;
