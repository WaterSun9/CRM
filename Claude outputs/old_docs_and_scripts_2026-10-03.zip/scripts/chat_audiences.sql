-- Team chat audiences (Oct 2026). Safe to re-run.
-- Run in the CRM project (cjskyhxameobcqlfiuav) SQL Editor BEFORE deploying
-- the frontend that contains the new TeamChat (it reads target_role).
--
-- Staff (admin, sales, channel_partner_office, office2) can now START messages:
--   audience 'public' -> everyone signed in
--   audience 'role'   -> one group (target_role), e.g. all vendors, all CPOs
--   audience 'admin' + recipient_id -> one person (private)
-- Everyone else still writes to the staff inbox (audience 'admin', no recipient).
-- Each person reads: their own messages, messages sent to them, public messages,
-- and messages to their group. Staff read everything (unchanged).
-- The table had 0 rows when this was written.
--
-- Rollback: drop the two new policies, recreate the old ones from
--   scripts/add_chat_availability_and_batch_order.sql, and
--   alter table public.crm_chat_messages drop column target_role;
begin;

alter table public.crm_chat_messages add column if not exists target_role text;

alter table public.crm_chat_messages drop constraint if exists crm_chat_messages_audience_check;
alter table public.crm_chat_messages add constraint crm_chat_messages_audience_check
    check (audience in ('public', 'admin', 'role'));

alter table public.crm_chat_messages drop constraint if exists crm_chat_public_no_recipient;
alter table public.crm_chat_messages add constraint crm_chat_public_no_recipient
    check (audience = 'admin' or recipient_id is null);

alter table public.crm_chat_messages drop constraint if exists crm_chat_role_target;
alter table public.crm_chat_messages add constraint crm_chat_role_target
    check (
        (audience = 'role' and target_role in
            ('vendor', 'channel_partner_office', 'agent', 'agent2', 'stamp', 'technician', 'sales'))
        or (audience <> 'role' and target_role is null)
    );

drop policy if exists crm_chat_read on public.crm_chat_messages;
create policy crm_chat_read on public.crm_chat_messages
for select to authenticated
using (
    public.get_my_user_type() in ('admin', 'sales', 'channel_partner_office', 'office2')
    or sender_id = (select auth.uid())
    or recipient_id = (select auth.uid())
    or audience = 'public'
    or (audience = 'role' and (
            target_role = public.get_my_user_type()
            or (target_role = 'channel_partner_office'
                and public.get_my_user_type() in ('office2', 'channel_partner_office_manager'))
        ))
);

drop policy if exists crm_chat_send on public.crm_chat_messages;
create policy crm_chat_send on public.crm_chat_messages
for insert to authenticated
with check (
    sender_id = (select auth.uid())
    and (
        (public.get_my_user_type() in ('admin', 'sales', 'channel_partner_office', 'office2')
            and (
                (audience = 'admin' and recipient_id is not null)
                or audience in ('public', 'role')
            ))
        or (public.get_my_user_type() in ('agent', 'agent2', 'vendor', 'stamp', 'technician')
            and audience = 'admin' and recipient_id is null)
    )
);

revoke all on public.crm_chat_messages from anon;

commit;

-- Check after running:
-- select policyname, cmd from pg_policies where tablename = 'crm_chat_messages';
-- select column_name from information_schema.columns where table_name = 'crm_chat_messages';
