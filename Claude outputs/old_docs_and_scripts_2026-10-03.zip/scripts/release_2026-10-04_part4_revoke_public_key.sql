-- WaterSun CRM release 4 Oct 2026 - PART 4 of 5: The public key can no longer run privileged functions.
-- Run parts 1 to 5 in order, each as its own run in the SQL Editor
-- (project cjskyhxameobcqlfiuav). Every part is safe to re-run.
--
-- If you see "lock timeout" or "deadlock detected": nothing in this part was
-- changed. Wait a minute (someone was saving at that moment) and run it again.
set lock_timeout = '8s';
begin;
-- ---------------------------------------------------------------------------
-- 3. The public key may no longer run privileged functions.
--    Logged-in users keep exactly the access they have today.
-- ---------------------------------------------------------------------------
revoke execute on function public.get_dashboard_metrics(text)              from public, anon;
revoke execute on function public.get_dashboard_metrics_scoped(text, text) from public, anon;
revoke execute on function public.stamp_monthly_summary()                  from public, anon;
revoke execute on function public.sync_driver_info_to_admin()              from public, anon;
revoke execute on function public.log_admin_change()                       from public, anon;
revoke execute on function public.enforce_profile_privilege_changes()      from public, anon;
revoke execute on function public.rls_auto_enable()                        from public, anon;
grant  execute on function public.get_dashboard_metrics(text)              to authenticated, service_role;
grant  execute on function public.get_dashboard_metrics_scoped(text, text) to authenticated, service_role;
grant  execute on function public.stamp_monthly_summary()                  to authenticated, service_role;
grant  execute on function public.sync_driver_info_to_admin()              to authenticated, service_role;
grant  execute on function public.log_admin_change()                       to authenticated, service_role;
grant  execute on function public.enforce_profile_privilege_changes()      to authenticated, service_role;
grant  execute on function public.rls_auto_enable()                        to authenticated, service_role;

commit;
