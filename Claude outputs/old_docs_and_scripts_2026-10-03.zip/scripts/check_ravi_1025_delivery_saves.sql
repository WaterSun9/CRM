-- READ ONLY. Run this one query in project cjskyhxameobcqlfiuav.
-- Checks the three customer records Ravi touched around 10:25-10:30 IST,
-- their currently stored delivery/integration fields, and their BOM rows.
with targets(id) as (
    values
      ('79d3a3c5-2e3f-4573-94bd-e056965a80ce'::uuid), -- Thakor Mansukhbhai
      ('b9e8f0d7-c18d-4695-a1d6-6993be875085'::uuid), -- Makwana Pravinkumar
      ('2cb8051d-ebf7-4a75-9f28-5326a958b74d'::uuid)  -- Ghanchi Rahimbhai
)
select a.customer_name, a.id, a.stage,
       a.roof_shed, a.invoice_value, a.dc_cable, a.ac_cable,
       a.inverter_make, a.inverter_serial_no, a.panel_serial_no,
       a.vendor, a.invoice_no, a.material_delivery_date,
       a.driver_name, a.driver_phone_number, a.delivery_status,
       a.updated_at at time zone 'Asia/Kolkata' as customer_updated_at_ist,
       coalesce(b.bom_rows, 0) as bom_rows,
       (select count(*) from public.bom_items i
        join public.bom bx on bx.id = i.bom_id
        where bx.admin_id = a.id) as bom_items,
       b.bom_details,
       (select jsonb_agg(jsonb_build_object(
           'table', tablename, 'policy', policyname, 'command', cmd,
           'roles', roles, 'using', qual, 'check', with_check
       ) order by tablename, policyname)
        from pg_policies
        where schemaname = 'public' and tablename in ('bom', 'bom_items')) as bom_policies
from targets t
join public.admin a on a.id = t.id
left join lateral (
    select count(*) as bom_rows,
           jsonb_agg(jsonb_build_object(
               'bom_id', x.id, 'type', x.bom_type,
               'paper_prepared_by', x.paper_prepared_by,
               'paper_prepared_date', x.paper_prepared_date,
               'material_loaded_by', x.material_loaded_by,
               'material_loaded_date', x.material_loaded_date
           ) order by x.created_at) as bom_details
    from public.bom x
    where x.admin_id = a.id
) b on true
order by a.customer_name;
