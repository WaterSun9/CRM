-- Apply only if crm_availability already exists. Existing staff leave records
-- are preserved, but no longer displayed or editable through this calendar.
begin;

revoke update on public.crm_availability from authenticated;

alter table public.crm_availability add column if not exists vendor_name text not null default '';
update public.crm_availability entry set vendor_name = profile.name
from public.profiles profile
where entry.user_id = profile.id and entry.entry_kind = 'vendor_unavailable' and entry.vendor_name = '';
create or replace function public.set_crm_availability_vendor_name()
returns trigger language plpgsql security invoker set search_path = public, pg_temp as $$
begin
    new.vendor_name := coalesce((select name from public.profiles where id = auth.uid()), 'Vendor');
    return new;
end;
$$;
drop trigger if exists crm_availability_vendor_name on public.crm_availability;
create trigger crm_availability_vendor_name before insert on public.crm_availability
for each row execute function public.set_crm_availability_vendor_name();

drop policy if exists crm_availability_read on public.crm_availability;
create policy crm_availability_read on public.crm_availability for select to authenticated
using (
    entry_kind = 'vendor_unavailable'
    and (public.get_my_user_type() in ('admin', 'sales', 'channel_partner_office', 'office2')
         or (public.get_my_user_type() = 'vendor' and user_id = (select auth.uid())))
);

drop policy if exists crm_availability_create on public.crm_availability;
create policy crm_availability_create on public.crm_availability for insert to authenticated
with check (
    user_id = (select auth.uid()) and reviewed_at is null and reviewed_by is null
    and public.get_my_user_type() = 'vendor' and entry_kind = 'vendor_unavailable' and status = 'approved'
);

drop policy if exists crm_availability_admin_review on public.crm_availability;
drop policy if exists crm_availability_remove on public.crm_availability;
create policy crm_availability_remove on public.crm_availability for delete to authenticated
using (public.get_my_user_type() = 'vendor' and user_id = (select auth.uid()) and entry_kind = 'vendor_unavailable');

commit;
