-- ─── Restore values lost by the CRM save bugs (audit of 2026-10-01) ─────────
-- Source of every value: the CRM activity log (what the user entered on screen).
-- Run in the Supabase SQL Editor. Nothing here deletes data.
--
-- Safety:
--   * STEP 1 is read-only: check the preview before running anything else.
--   * STEP 2 runs in ONE transaction. It first copies the current values to a
--     backup table, then only fills fields that are STILL EMPTY (it never
--     overwrites a value someone has entered since the audit).
--   * Every restored customer gets an activity-log entry, so the history shows
--     who restored what and why.
--   * Ask the team to close these customers in the CRM while you run it.
--
-- Deliberately NOT included (need a human decision first):
--   * DAVE GIRDHARLAL CHAMPALAL  - Module Brand GOLDI vs TATA (two users clashed)
--   * NADODA JESANGBHAI DALABHAI - Discom Inspection "No" (log) vs "Yes" (now)
--   * Morvadia munafmohammed f    - inverter make/serial and vendor were never entered


-- ═══ STEP 1: PREVIEW (read-only) ═══════════════════════════════════════════
select customer_name, stage, inverter_make, inverter_serial_no, panel_serial_no, no_of_modules
from admin
where id in (
  '98d10641-efee-4f22-b92a-958fc9d0f191',  -- GULABNABI RAMJANBHAI GHANCHI
  'aadd60cc-356c-470f-bba3-aff623a0848a',  -- RAJESHKUMAR VASHARAMBHAI CHAUDHARI
  'b774a586-add6-49f8-b12c-098707053ab5',  -- GOSWAMI MITALBEN KIRANGAR
  '0f406187-b644-4873-a068-dc3a1e1dc767'   -- VAGHELA SHANTUSINH RAJUSINH
);
-- Expect: the four target fields empty.

select count(*) as discom_agreement_to_restore
from admin a
where a.deleted_at is null and a.discom_agreement = false
  and exists (select 1 from documents d where d.customer_id = a.id and d.doc_type = 'discom_agreement');
-- Expect: 141 (only customers with the agreement document uploaded).


-- ═══ STEP 2: RESTORE (one transaction) ═════════════════════════════════════
begin;

-- 2a. Backup of the current values of every row this script can touch.
create table if not exists public.restore_backup_2026_10_01 as
select now() as backed_up_at, id, customer_name, inverter_make, inverter_serial_no,
       panel_serial_no, no_of_modules, discom_agreement
from admin
where id in ('98d10641-efee-4f22-b92a-958fc9d0f191','aadd60cc-356c-470f-bba3-aff623a0848a',
             'b774a586-add6-49f8-b12c-098707053ab5','0f406187-b644-4873-a068-dc3a1e1dc767')
   or exists (select 1 from documents d where d.customer_id = admin.id and d.doc_type = 'discom_agreement');

-- 2b. Lost values - each only if still empty.
update admin set inverter_make = 'Goodwe'
 where id = '98d10641-efee-4f22-b92a-958fc9d0f191' and coalesce(inverter_make, '') = '';
update admin set inverter_serial_no = '53000N3A263L8503'
 where id = '98d10641-efee-4f22-b92a-958fc9d0f191' and coalesce(inverter_serial_no, '') = '';

update admin set inverter_make = 'UTL'
 where id = 'aadd60cc-356c-470f-bba3-aff623a0848a' and coalesce(inverter_make, '') = '';
update admin set inverter_serial_no = 'GXUS136268LG640'
 where id = 'aadd60cc-356c-470f-bba3-aff623a0848a' and coalesce(inverter_serial_no, '') = '';

-- panel_serial_no is a JSON column holding one text value (serials separated
-- by line breaks), so the value is written with to_jsonb and the empty check
-- is "is null" (comparing JSON to '' is what failed on the first run).
update admin set panel_serial_no = to_jsonb(E'WS09269076657168\nWS09269076657177\nWS09269076657098\nWS09269076657174\nWS09269076657140\nWS09269076583797'::text)
 where id = 'b774a586-add6-49f8-b12c-098707053ab5'
   and (panel_serial_no is null or panel_serial_no = 'null'::jsonb or panel_serial_no = '""'::jsonb);

update admin set no_of_modules = 6
 where id = '0f406187-b644-4873-a068-dc3a1e1dc767' and no_of_modules is null;

-- 2c. Discom Agreement ticks, from uploaded agreement documents.
--     (Only sticks once the app fix adding discom_agreement to ADMIN_COLUMNS is
--      deployed; the database itself accepts it either way.)
with restored as (
  update admin a set discom_agreement = true
  where a.deleted_at is null and a.discom_agreement = false
    and exists (select 1 from documents d where d.customer_id = a.id and d.doc_type = 'discom_agreement')
  returning a.id, a.customer_name
)
insert into activity_log (user_id, customer_id, action, message, new_value, created_at)
select '6136e87c-f77b-4483-a5df-98dedbb3c352', id, 'update',
       customer_name || ': DISCOM AGREEMENT: No → Yes',
       'Restored by admin from uploaded agreement document (audit 2026-10-01: checkbox could not be saved by the CRM)',
       now()
from restored;

-- 2d. Activity-log entries for the four restored customers.
insert into activity_log (user_id, customer_id, action, message, new_value, created_at) values
('6136e87c-f77b-4483-a5df-98dedbb3c352','98d10641-efee-4f22-b92a-958fc9d0f191','update',
 'GULABNABI RAMJANBHAI GHANCHI: INVERTER MAKE: Empty → Goodwe | INVERTER SERIAL NO: Empty → 53000N3A263L8503',
 'Restored by admin from activity log (entered by Ravi Office 27 Sep 2026 4:01 PM, lost by save bug)', now()),
('6136e87c-f77b-4483-a5df-98dedbb3c352','aadd60cc-356c-470f-bba3-aff623a0848a','update',
 'RAJESHKUMAR VASHARAMBHAI CHAUDHARI: INVERTER MAKE: Empty → UTL | INVERTER SERIAL NO: Empty → GXUS136268LG640',
 'Restored by admin from activity log (entered by Ravi Office 9 Sep 2026 9:06 PM, lost by save bug)', now()),
('6136e87c-f77b-4483-a5df-98dedbb3c352','b774a586-add6-49f8-b12c-098707053ab5','update',
 'GOSWAMI MITALBEN KIRANGAR: PANEL SERIAL NO: Empty → WS09269076657168, WS09269076657177, WS09269076657098, WS09269076657174, WS09269076657140, WS09269076583797',
 'Restored by admin from activity log (entered by Ravi Office 28 Sep 2026 6:45 PM, lost by save bug)', now()),
('6136e87c-f77b-4483-a5df-98dedbb3c352','0f406187-b644-4873-a068-dc3a1e1dc767','update',
 'VAGHELA SHANTUSINH RAJUSINH: NO OF MODULES: Empty → 6',
 'Restored by admin from activity log (entered by Ravi Office 9 Sep 2026 2:19 PM, lost by save bug)', now());

-- 2e. Check before committing: the four rows should now be filled.
select customer_name, inverter_make, inverter_serial_no, panel_serial_no, no_of_modules
from admin
where id in ('98d10641-efee-4f22-b92a-958fc9d0f191','aadd60cc-356c-470f-bba3-aff623a0848a',
             'b774a586-add6-49f8-b12c-098707053ab5','0f406187-b644-4873-a068-dc3a1e1dc767');

commit;   -- if anything above looks wrong, run   rollback;   instead
