-- Standalone service workflow. Does not change customer or vendor tables.
begin;

create table if not exists public.service_issues (
    id uuid primary key default gen_random_uuid(),
    channel_partner_name text,
    consumer_no text not null check (length(trim(consumer_no)) between 1 and 100),
    customer_name text not null check (length(trim(customer_name)) between 1 and 160),
    customer_phone text,
    service_address text,
    problem_type text not null check (length(trim(problem_type)) between 1 and 160),
    system_company_name text,
    system_kw numeric(9,2) check (system_kw is null or system_kw >= 0),
    comment text not null default '' check (length(comment) <= 2000),
    required_date date not null,
    status text not null default 'open' check (status in ('open', 'assigned', 'completed')),
    assigned_to uuid references auth.users(id),
    assigned_at timestamptz,
    give_up_reason text,
    created_by uuid not null references auth.users(id),
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    constraint service_issue_assignment_matches_status check (
        (status = 'open' and assigned_to is null) or (status in ('assigned', 'completed') and assigned_to is not null)
    )
);
create index if not exists service_issues_status_date_idx on public.service_issues(status, required_date);
create index if not exists service_issues_technician_idx on public.service_issues(assigned_to, required_date);
alter table public.service_issues enable row level security;
revoke all on public.service_issues from anon;
grant select, insert, update on public.service_issues to authenticated;

create policy service_issues_read on public.service_issues for select to authenticated
using (
    public.get_my_user_type() in ('admin', 'sales')
    or created_by = (select auth.uid())
    or (public.get_my_user_type() = 'technician' and assigned_to = (select auth.uid()))
);
create policy service_issues_create on public.service_issues for insert to authenticated
with check (
    public.get_my_user_type() in ('admin', 'sales', 'channel_partner_office', 'channel_partner_office_manager', 'office2', 'agent', 'agent2')
    and created_by = (select auth.uid())
    and status = 'open' and assigned_to is null
);
create policy service_issues_update on public.service_issues for update to authenticated
using (
    public.get_my_user_type() in ('admin', 'sales')
    or (public.get_my_user_type() = 'technician' and assigned_to = (select auth.uid()))
)
with check (
    public.get_my_user_type() in ('admin', 'sales')
    or (public.get_my_user_type() = 'technician' and (assigned_to = (select auth.uid()) or (status = 'open' and assigned_to is null)))
);

-- Only queue summary fields are visible before a technician claims a job.
create or replace function public.open_service_issue_queue()
returns table (id uuid, customer_name text, problem_type text, required_date date,
    status text, give_up_reason text)
language plpgsql security definer set search_path = public, pg_temp as $$
begin
    if public.get_my_user_type() <> 'technician' then
        raise exception 'Technician account required';
    end if;
    return query select issue.id, issue.customer_name, issue.problem_type,
        issue.required_date, issue.status, issue.give_up_reason
    from public.service_issues issue where issue.status = 'open'
    order by issue.required_date, issue.created_at;
end;
$$;
revoke all on function public.open_service_issue_queue() from public, anon;
grant execute on function public.open_service_issue_queue() to authenticated;

-- The status condition is checked again while locking the row, so only the
-- first technician can claim it. The full record then becomes visible via RLS.
create or replace function public.claim_service_issue(p_issue_id uuid)
returns boolean language plpgsql security definer set search_path = public, pg_temp as $$
declare claimed_id uuid;
begin
    if public.get_my_user_type() <> 'technician' then
        raise exception 'Technician account required';
    end if;
    update public.service_issues issue
    set status = 'assigned', assigned_to = auth.uid(), assigned_at = now(), give_up_reason = null
    where issue.id = p_issue_id and issue.status = 'open'
    returning issue.id into claimed_id;
    return claimed_id is not null;
end;
$$;
revoke all on function public.claim_service_issue(uuid) from public, anon;
grant execute on function public.claim_service_issue(uuid) to authenticated;

create or replace function public.give_up_service_issue(p_issue_id uuid, p_reason text)
returns boolean language plpgsql security definer set search_path = public, pg_temp as $$
declare changed_id uuid;
begin
    if public.get_my_user_type() <> 'technician' or length(trim(coalesce(p_reason, ''))) = 0 then
        raise exception 'Technician account and give-up reason required';
    end if;
    update public.service_issues issue
    set status = 'open', assigned_to = null, assigned_at = null, give_up_reason = trim(p_reason)
    where issue.id = p_issue_id and issue.status = 'assigned' and issue.assigned_to = auth.uid()
    returning issue.id into changed_id;
    return changed_id is not null;
end;
$$;
revoke all on function public.give_up_service_issue(uuid, text) from public, anon;
grant execute on function public.give_up_service_issue(uuid, text) to authenticated;

-- RLS and this guard also limit which fields a technician can change.
create or replace function public.guard_service_issue_update()
returns trigger language plpgsql security invoker set search_path = public, pg_temp as $$
begin
    if auth.uid() is not null and public.get_my_user_type() = 'technician' then
        if (to_jsonb(new) - array['status','assigned_to','assigned_at','give_up_reason','updated_at'])
           is distinct from (to_jsonb(old) - array['status','assigned_to','assigned_at','give_up_reason','updated_at']) then
            raise exception 'Technicians cannot edit issue details';
        end if;
        if old.status = 'open' and new.status = 'assigned' and new.assigned_to = auth.uid()
           and new.assigned_at is not null and new.give_up_reason is null then
            null;
        elsif old.status = 'assigned' and old.assigned_to = auth.uid() and new.status = 'open'
           and new.assigned_to is null and new.assigned_at is null
           and length(trim(coalesce(new.give_up_reason, ''))) > 0 then
            null;
        else
            raise exception 'Only claiming an open issue or giving up your assignment is allowed';
        end if;
    end if;
    new.updated_at := now();
    return new;
end;
$$;
drop trigger if exists service_issue_guard on public.service_issues;
create trigger service_issue_guard before update on public.service_issues
for each row execute function public.guard_service_issue_update();

create table if not exists public.service_visits (
    id uuid primary key default gen_random_uuid(),
    issue_id uuid not null references public.service_issues(id) on delete cascade,
    technician_id uuid not null references auth.users(id),
    visit_date date not null,
    kilometers numeric(9,2) not null check (kilometers >= 0),
    amount_inr numeric(12,2) not null check (amount_inr >= 0),
    note text not null default '' check (length(note) <= 1000),
    entered_by uuid not null references auth.users(id),
    created_at timestamptz not null default now()
);
create index if not exists service_visits_issue_date_idx on public.service_visits(issue_id, visit_date);
alter table public.service_visits enable row level security;
revoke all on public.service_visits from anon;
grant select, insert on public.service_visits to authenticated;
create policy service_visits_read on public.service_visits for select to authenticated
using (
    public.get_my_user_type() in ('admin', 'sales')
    or (public.get_my_user_type() = 'technician' and technician_id = (select auth.uid()))
);
create policy service_visits_create on public.service_visits for insert to authenticated
with check (
    public.get_my_user_type() in ('admin', 'sales') and entered_by = (select auth.uid())
    and exists (select 1 from public.service_issues issue
        where issue.id = issue_id and issue.assigned_to = technician_id)
);

create table if not exists public.service_issue_files (
    id uuid primary key default gen_random_uuid(),
    issue_id uuid not null references public.service_issues(id) on delete cascade,
    storage_path text not null unique,
    file_name text not null,
    mime_type text not null,
    uploaded_by uuid not null references auth.users(id),
    created_at timestamptz not null default now()
);
create index if not exists service_issue_files_issue_idx on public.service_issue_files(issue_id);
alter table public.service_issue_files enable row level security;
revoke all on public.service_issue_files from anon;
grant select, insert, delete on public.service_issue_files to authenticated;
create policy service_issue_files_read on public.service_issue_files for select to authenticated
using (exists (
    select 1 from public.service_issues issue where issue.id = issue_id
    and (public.get_my_user_type() in ('admin', 'sales') or issue.created_by = (select auth.uid())
         or issue.assigned_to = (select auth.uid()))
));
create policy service_issue_files_create on public.service_issue_files for insert to authenticated
with check (
    uploaded_by = (select auth.uid())
    and storage_path like issue_id::text || '/' || (select auth.uid())::text || '/%'
    and exists (select 1 from public.service_issues issue where issue.id = issue_id
        and (public.get_my_user_type() in ('admin', 'sales') or issue.created_by = (select auth.uid())))
);
create policy service_issue_files_remove on public.service_issue_files for delete to authenticated
using (uploaded_by = (select auth.uid()) or public.get_my_user_type() in ('admin', 'sales'));

create or replace function public.limit_service_issue_files()
returns trigger language plpgsql security invoker set search_path = public, pg_temp as $$
begin
    perform pg_advisory_xact_lock(hashtextextended(new.issue_id::text, 0));
    if (select count(*) from public.service_issue_files where issue_id = new.issue_id) >= 5 then
        raise exception 'A service issue can have at most 5 files';
    end if;
    return new;
end;
$$;
drop trigger if exists service_issue_file_limit on public.service_issue_files;
create trigger service_issue_file_limit before insert on public.service_issue_files
for each row execute function public.limit_service_issue_files();

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('service-issues', 'service-issues', false, 10485760, array['image/jpeg','image/png','image/webp','application/pdf'])
on conflict (id) do nothing;

create policy service_issue_storage_read on storage.objects for select to authenticated
using (
    bucket_id = 'service-issues' and exists (
        select 1 from public.service_issues issue
        where issue.id::text = split_part(name, '/', 1)
        and (public.get_my_user_type() in ('admin', 'sales') or issue.created_by = (select auth.uid())
             or issue.assigned_to = (select auth.uid()))
    )
);
create policy service_issue_storage_upload on storage.objects for insert to authenticated
with check (
    bucket_id = 'service-issues' and split_part(name, '/', 2) = (select auth.uid())::text
    and exists (select 1 from public.service_issues issue
        where issue.id::text = split_part(name, '/', 1)
        and (public.get_my_user_type() in ('admin', 'sales') or issue.created_by = (select auth.uid())))
);
create policy service_issue_storage_remove on storage.objects for delete to authenticated
using (
    bucket_id = 'service-issues'
    and (split_part(name, '/', 2) = (select auth.uid())::text
         or public.get_my_user_type() in ('admin', 'sales'))
);

commit;
