-- REPLACED - do not run this file.
-- The release SQL is now split into 5 smaller parts so it can't deadlock with
-- people using the CRM at the same time. Run these in order, one per run:
--   scripts/release_2026-10-04_part1_helpers_bom_filenumber.sql
--   scripts/release_2026-10-04_part2_delivery_bom_stage_functions.sql
--   scripts/release_2026-10-04_part3_document_storage.sql
--   scripts/release_2026-10-04_part4_revoke_public_key.sql
--   scripts/release_2026-10-04_part5_profile_guard.sql
-- then scripts/customer_payment_review_flags.sql and scripts/chat_audiences.sql.
select 'This file was replaced - run the part1..part5 files instead.' as notice;
