-- WaterSun CRM release 4 Oct 2026 - PART 1 of 5: Helper search_path fix, BOM "loaded" column, automatic file number.
-- Run parts 1 to 5 in order, each as its own run in the SQL Editor
-- (project cjskyhxameobcqlfiuav). Every part is safe to re-run.
--
-- If you see "lock timeout" or "deadlock detected": nothing in this part was
-- changed. Wait a minute (someone was saving at that moment) and run it again.
set lock_timeout = '8s';
begin;
-- ---------------------------------------------------------------------------
-- 0. Pin search_path on the helper functions every access rule calls.
--    get_my_user_type() & co. read "profiles" without a schema. Any function
--    that runs with a restricted search_path (the new delivery / BOM / stage
--    functions below) would otherwise fail with "relation profiles does not
--    exist" - which would break delivery, BOM and stage saves.
--    Also clears 11 Supabase security-advisor warnings.
-- ---------------------------------------------------------------------------
alter function public.get_my_user_type()        set search_path = public;
alter function public.get_my_name()             set search_path = public;
alter function public.get_my_channel_partner()  set search_path = public;
alter function public.update_updated_at_column() set search_path = public;
alter function public.sync_driver_info_to_admin() set search_path = public;
alter function public.set_admin_updated_at()    set search_path = public;
alter function public.update_timestamp()        set search_path = public;
alter function public.set_completed_at()        set search_path = public;
alter function public.delete_old_completed_activity() set search_path = public;
alter function public.update_bom_updated_at()   set search_path = public;
alter function public.stage_rank(text)          set search_path = public;

-- 0b. BOM "loaded" tick per line (Material Integration). Existing lines = not loaded.
alter table public.bom_items add column if not exists loaded boolean not null default false;

-- 0c. File number is filled in automatically for new customers: highest
--     existing file number + 1, whenever a new row arrives without one (or 0).
--     A transaction lock stops two leads saved at the same moment from getting
--     the same number. Typed-in file numbers are kept as entered.
create or replace function public.assign_folder_no()
returns trigger
language plpgsql
security definer
set search_path = public
as $function$
begin
    if new.folder_no is null or new.folder_no = 0 then
        perform pg_advisory_xact_lock(hashtext('public.admin.folder_no'));
        select coalesce(max(folder_no), 0) + 1 into new.folder_no from public.admin;
    end if;
    return new;
end;
$function$;
revoke execute on function public.assign_folder_no() from public, anon;
drop trigger if exists trg_assign_folder_no on public.admin;
create trigger trg_assign_folder_no before insert on public.admin
for each row execute function public.assign_folder_no();

commit;
