-- WaterSun CRM release 4 Oct 2026 - PART 3 of 5: Close the customer-documents bucket to the public.
-- Run parts 1 to 5 in order, each as its own run in the SQL Editor
-- (project cjskyhxameobcqlfiuav). Every part is safe to re-run.
--
-- If you see "lock timeout" or "deadlock detected": nothing in this part was
-- changed. Wait a minute (someone was saving at that moment) and run it again.
set lock_timeout = '8s';
begin;
-- ---------------------------------------------------------------------------
-- 2. Customer documents: close the bucket to the public.
--    Today anyone with the public key (it is inside the website code) can list,
--    download, overwrite and DELETE all ~7,300 customer documents without
--    logging in. The app only ever uses signed links as a logged-in user, so
--    staff see no difference.
-- ---------------------------------------------------------------------------
drop policy if exists "Allow all storage operations on customer-documents" on storage.objects;
drop policy if exists customer_documents_read   on storage.objects;
drop policy if exists customer_documents_upload on storage.objects;
drop policy if exists customer_documents_update on storage.objects;
drop policy if exists customer_documents_delete on storage.objects;
create policy customer_documents_read   on storage.objects for select to authenticated using (bucket_id = 'customer-documents');
create policy customer_documents_upload on storage.objects for insert to authenticated with check (bucket_id = 'customer-documents');
create policy customer_documents_update on storage.objects for update to authenticated using (bucket_id = 'customer-documents') with check (bucket_id = 'customer-documents');
create policy customer_documents_delete on storage.objects for delete to authenticated using (bucket_id = 'customer-documents');
update storage.buckets set public = false where id = 'customer-documents';

commit;
