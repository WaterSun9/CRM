# WaterSun CRM repository audit — 3 October 2026

## Scope and method

Reviewed the repository's 104 source JS/TS files (about 35,000 lines), both Edge Functions, database SQL scripts, 11 test files, package dependencies, and GitHub workflows. Traced the write paths for customer saves, stages, delivery, BOM, documents, vendor photos, service issues, users, directories, and quotations. Ran ESLint, TypeScript configuration check, 44 unit tests, production build, `git diff --check`, and `npm audit --omit=dev`.

This is a repository-wide static audit. It does not certify the deployed database schema, RLS policies, Edge Function versions, or browser behavior. The new migration has not been applied to the live project, and database transaction behavior still needs a live or staging smoke test.

## Changes prepared locally

| Area | Change | Evidence |
| --- | --- | --- |
| Customer and Agent saves | Failed verification reads no longer count as confirmed saves. Agent saves compare returned database values before logging success. | `src/components/CustomerDetailModal.jsx`, `src/components/AgentPortal.jsx` |
| Agent error messages | The Agent portal's `customAlert` state was never rendered; save and document failures now use the visible global popup. | `src/components/AgentPortal.jsx` |
| Unused state | Removed dead Agent portal view/upload state and unused Material Integration state and calculations; a stale document fetch can no longer overwrite another customer's documents. | `src/components/AgentPortal.jsx`, `src/components/modal-tabs/MaterialIntegrationTab.jsx` |
| Dashboard saves | A thrown update now rolls optimistic customer state back. | `src/components/Dashboard.jsx` |
| Delivery | Save, delete, batch status, and removal of a customer from a batch use atomic RPCs. Partial-write fallbacks were removed. Browser cache writes cannot turn a successful database save into a reported failure. Dispatch dates use the local calendar day. | `src/components/DeliveryBatchesView.jsx` |
| Database delivery security | Privileged RPCs check an authenticated Admin/Sales role, validate statuses and batch membership, reject missing/foreign customers, and roll back on row-count mismatches. Public/anonymous execution is revoked. | `supabase/migrations/20261003081340_harden_delivery_and_bom_saves.sql` |
| BOM | A new invoker-rights RPC replaces parent and item rows in one transaction, checks the saved item IDs for concurrent changes, and refuses duplicate BOM parents. | Migration above; `src/components/modal-tabs/MaterialIntegrationTab.jsx` |
| Stage RPC | Rejects null identities, checks Admin role and the actual previous stage, and revokes public/anonymous execution. | Migration above; `scripts/restrict_move_stage_rpc.sql` |
| Vendor notification and accounts | Server chooses the recipient from the customer's saved vendor and escapes customer text in email HTML. Account creation no longer logs the request body containing a password. | `supabase/functions/send-lead-to-vendor/index.ts`, `supabase/functions/add_user/index.ts` |
| Documents and vendor photos | Failed document inserts attempt to remove the uploaded object. A failed replacement no longer deletes the previous geo-tag photo. Delete responses are checked. | `src/utils.jsx`, `src/components/VendorPortal.jsx` |
| Small correctness fixes | Deduplicated service issues returned by two query paths and checked availability delete row count. | `src/components/ServiceIssuesView.jsx`, `src/components/AvailabilityCalendar.jsx` |

## Remaining findings, in priority order

### High — Directory and user renames span several independent writes

`src/components/UserManagementView.jsx` and `src/components/ChannelPartnerManagementView.jsx` rename profile, directory, admin, vendor, and BOM references with separate HTTP requests. They count rows and attempt rollback, but a second failure can still leave a person's login name or branch different from the text used in customer RLS filters. Move each cascade into a database transaction with an expected old value and exact affected-row checks. Existing comments and compensation code document this failure mode; the current implementation is safer than an unchecked update but is not atomic.

`src/components/Dashboard.jsx` also calls `move_stage` and then separately writes `stages_remarks` and, for Lost Project, `hold_procurement`. The second write can fail after the stage commits. Put those related fields in the same stage RPC transaction.

### High — Privileged metrics functions need role checks

`scripts/sync_sidebar_tag_counts.sql` and `scripts/fix_cpo_manager_metrics_and_rls.sql` define `SECURITY DEFINER` dashboard metric functions. They scope CPO callers to their branch, while other roles can supply a partner filter or no filter. If those definitions are live and callable by other authenticated roles, aggregate counts can bypass normal table RLS. Confirm the deployed function definitions and grants, then restrict callers to dashboard roles and derive their permitted scope on the server.

Other privileged SQL requires the same deployed-definition review: `scripts/stamp_monthly_summary_fix.sql` exposes global counts to `authenticated`, while `scripts/fix_profiles_privilege_escalation.sql` and `scripts/2026-10-02_data_safety.sql` treat a null `auth.uid()` as a trusted server caller. Whether anonymous users can reach their underlying writes depends on the live grants and RLS policies. The stage RPC's version of this pattern is closed by the new migration.

### Medium — The release pipeline deploys only the frontend

`.github/workflows/deploy.yml` runs lint, unit tests, and build before GitHub Pages deployment. It does not apply SQL migrations or deploy Edge Functions. The new frontend calls `save_bom_atomic`, so the migration must be applied and tested before publishing this frontend. Add a release check that confirms the required RPCs and Edge Function versions are live. There is no browser or database integration test for save failure, RLS denial, partial batch membership, or BOM rollback.

### Medium — Existing duplicate BOM parent rows need repair

`src/utils/bom.js` and `src/components/VendorPortal.jsx` now choose the oldest parent for reading. The new atomic save refuses customers with multiple parents to avoid writing to an arbitrary row. `scripts/fix_duplicate_bom_rows.sql` is an existing repair script, but duplicate rows must be reviewed before its destructive section is run. After repair, add a unique constraint on `bom.admin_id` to prevent recurrence.

### Medium — Backup completeness depends on optional secrets

`.github/workflows/daily-backup.yml` exports CRM tables, while full database and file backups run only when separate credentials are configured. Its storage job currently copies `customer-documents`; check every active storage bucket, including service issue files and private exports, and run a restore drill. The audit did not inspect whether production backup secrets are configured or whether a restore has succeeded.

### Low — Size, unused code, and dependency maintenance

The largest components are `AgentPortal.jsx` (about 2,820 lines), `CustomerDetailModal.jsx` (about 2,440), and `VendorPortal.jsx` (about 2,020). ESLint finds 55 warnings after the cleanup: 33 unused variables, 13 missing hook dependencies, and 9 mixed-export Fast Refresh warnings. Split each large component by data fetching, save commands, and display panels before removing further state or handlers. Resolve hook warnings by examining closures; suppressing them without review could hide stale-state bugs. `tsconfig.json` has `checkJs: false`, so the TypeScript check does not type-check most application logic.

`npm audit --omit=dev` found one low-severity transitive advisory: `dompurify@3.4.15` through `jspdf@4.2.1` ([GHSA-p98j-92pf-mc4p](https://github.com/advisories/GHSA-p98j-92pf-mc4p)). No moderate, high, or critical production dependency advisories were reported in this run.

## Validation and release order

- Local: 44/44 unit tests pass; ESLint has 0 errors and 55 warnings; `tsc --noEmit`, production build, and `git diff --check` pass.
- Database migration: not applied or executed against a database in this audit. Validate it against the live schema in staging or a transaction that is rolled back, including an unauthorized caller and a deliberately stale batch/BOM.
- Edge Functions: not deployed or exercised against the live service.
- Frontend: built locally, not published.

Apply and verify the migration first, deploy the two Edge Functions, then publish the frontend. A GitHub Pages deployment alone would leave the new BOM save RPC unavailable.
