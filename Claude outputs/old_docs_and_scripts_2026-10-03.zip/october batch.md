# October batch: red flag and quotation R&D

## October week 2: technician service and WhatsApp integration

Keep technician account creation, the service portal, issue controls, and technician chat targets hidden until this rollout. The owner will run `supabase/migrations/20261004120000_allow_technician_role.sql` when ready. Then use real technician and staff logins to check issue creation, files, claims, give-up, and visit entry before enabling the UI.

Plan WhatsApp integration in the same week: agree on message types, consent, provider, delivery records, and retry behaviour; test with a small group before broad use. No WhatsApp integration is active yet.

## Customer red flag

- One red flag applies to any customer record at any stage, including leads and completed records.
- Admin, office staff (`sales`), Channel Partner Office (`channel_partner_office`), and their staff (`office2` / `channel_partner_office_manager`) can turn it on or off from the customer record they are allowed to access.
- No reason is requested. The flag does not stop payment, service, stage changes, or any other workflow.
- The draft customer-record control and payment-log indicator are disabled in the app for now (`CUSTOMER_RED_FLAGS_ENABLED = false`).
- The internal SQL table is still named `customer_payment_review_flags` so existing references remain compatible. Its meaning in the interface is simply **red flag**.

### Deferred SQL draft — do not run yet

The earlier SQL has **not** been run. The red-flag feature is paused for a later session, so **do not run this draft SQL now**. The source copy is `scripts/customer_payment_review_flags.sql`. Before future rollout, use the read-only preflight in `ocbotober udpated.md` in the CRM Supabase project `cjskyhxameobcqlfiuav`. Only apply a create script if `to_regclass('public.customer_payment_review_flags')` returns `NULL`; if the table exists, prepare a migration instead. Then enable the UI and test leads and completed records under admin, staff, CPO, and CPO staff accounts. Payment and service must stay usable.

```sql
-- DEFERRED DRAFT: do not run until the red-flag feature is resumed.
-- Customer red flag for any active CRM record, including leads.
-- The table name is retained for compatibility with existing app queries.
-- Apply only after the read-only preflight confirms this table is absent.
begin;

create table public.customer_payment_review_flags (
    admin_id uuid primary key references public.admin(id) on delete cascade,
    active boolean not null default true,
    updated_by uuid not null references auth.users(id),
    updated_at timestamptz not null default now()
);
alter table public.customer_payment_review_flags enable row level security;
revoke all on public.customer_payment_review_flags from anon;
grant select, insert, update on public.customer_payment_review_flags to authenticated;

-- The admin table's existing RLS supplies the customer's branch/partner scope.
create policy customer_payment_flags_read on public.customer_payment_review_flags for select to authenticated
using (exists (
    select 1 from public.admin customer
    where customer.id = admin_id and customer.deleted_at is null
) and (select public.get_my_user_type()) in ('admin', 'sales', 'channel_partner_office', 'office2', 'channel_partner_office_manager'));
create policy customer_payment_flags_create on public.customer_payment_review_flags for insert to authenticated
with check (
    (select public.get_my_user_type()) in ('admin', 'sales', 'channel_partner_office', 'office2', 'channel_partner_office_manager')
    and updated_by = (select auth.uid())
    and exists (select 1 from public.admin customer where customer.id = admin_id and customer.deleted_at is null)
);
create policy customer_payment_flags_update on public.customer_payment_review_flags for update to authenticated
using (
    (select public.get_my_user_type()) in ('admin', 'sales', 'channel_partner_office', 'office2', 'channel_partner_office_manager')
    and exists (select 1 from public.admin customer where customer.id = admin_id and customer.deleted_at is null)
)
with check (
    (select public.get_my_user_type()) in ('admin', 'sales', 'channel_partner_office', 'office2', 'channel_partner_office_manager')
    and updated_by = (select auth.uid())
    and exists (select 1 from public.admin customer where customer.id = admin_id and customer.deleted_at is null)
);

commit;
```

## Quotation Maker: paused for next R&D session

The live Quotation Maker navigation and routes are disabled for admin, staff, channel partner and dealer portals. Its source code and test fixtures remain in the repository for the next design session. `#/quotations` no longer opens the module. Existing saved quotations are not deleted.

### R&D items before re-enabling

1. Match the **number font** to the client reference PDFs (`Quote-3255.pdf` and `Quotation_4_Test_Customer34.pdf`) across all three pages. Check the numeral shapes, font family, weight, size, and spacing in prices, capacities, dates, and the page 3 “Sr.” and warranty row numbers at the same viewing scale. The current numbers look noticeably different from the reference. Also fix the mismatched text sizes on pages 1 and 2 and uneven table lines on page 3.
2. Match “Authorized Channel Partner” and “Empanelment Vendor” text, spacing before the logos, logo sizes, and border weight to the reference. In particular, size the Tata logo consistently with Tata Power Solar Roof.
3. Move GEDA charges from the top table to the bottom table after Discount on page 2.
4. Use the standard Add Lead form when “Add to Leads” is selected from a quotation, with all details reviewable before saving.
5. Render and inspect all pages, then re-enable the module only after the client approves the visual result and the conversion flow is tested.
