# Quotation Maker deep audit — 2026-09-14

## Scope and evidence

Audited the live local quotation fixture at `quotation-preview.html` in the Codex in-app browser, using the seeded quotation `Quote-3255` at the agent role. Captured and inspected the quotation list, editor step 1, document preview at the default 53% scale, the preview at 73%, and the lower page/footer boundary. Also inspected the current render geometry and the preview/PDF source paths.

The two user-supplied screenshots add direct evidence: Screenshot 1 is the preview with Page 1's footer cut at the bottom edge; Screenshot 2 is the print/PDF with the email envelope visibly sitting above the email text.

The existing worktree was already dirty before this audit. The targeted quotation rendering fix described below was applied after the initial audit findings; unrelated existing changes were left untouched.

## Overall verdict

Do not remake the quotation maker yet. The symptoms are consistent with one unstable document-layout pipeline, not a fundamentally unusable form flow. The highest-risk defect is that preview and PDF do not share the same readiness and fitting contract. The footer clipping is a downstream effect of that mismatch plus hard clipping at the A4 boundary.

## Findings

### P0 — Preview and PDF use different layout readiness rules

`src/quotations/DocumentPages.jsx` runs `fitQuotationPages()` in `useLayoutEffect`, then reruns it after `document.fonts.ready`. It does not wait for `img.decode()` or image load completion.

`src/quotations/pdf.jsx` does wait for both `document.fonts.ready` and every image's `decode()` before calling `fitQuotationPages()`.

Result: the preview can measure a banner/logo at one height and the PDF can measure it at another height. That changes line wrapping, body height, fit scale, and footer position. This directly explains “preview doesn’t match print” and why the result can vary depending on load timing.

The user-supplied preview screenshot shows the practical result: the Page 1 footer reaches the viewport/page bottom with its lower content cut off. This is consistent with the first fit occurring before the image dimensions have settled.

### P0 — A4 pages hard-clip overflow instead of exposing a safe failure

All three page components use fixed `height`/`max-height: 297mm` and `overflow-hidden` (`Page1.tsx`, `Page2.tsx`, `Page3.tsx`). The stylesheet repeats the fixed height and clipping rule.

When the measured body plus footer is even slightly taller than the printable box, the lower pixels are silently removed. The footer is therefore not merely visually misplaced: it is allowed to render outside the page box and then hidden.

Fresh browser geometry showed this condition during the first render: Page 1's footer extended below the page boundary. After a later recalculation, Page 1 received a `scale(0.933828)` fit, confirming that the layout is timing-sensitive rather than consistently sized.

### P1 — The fit routine is too sensitive to late content changes

`fitQuotationPages()` calculates available height using `footer.offsetHeight`, but only at the instant it runs. It measures `body.scrollHeight` before permanently establishing a shared “all assets loaded” state. Text, fonts, image intrinsic dimensions, and browser rounding can therefore produce different results between runs.

The routine also uses a transform-based shrink (`transform: scale(...)`) and compensating width/height changes. This is acceptable for a controlled snapshot, but it is fragile when the preview is itself wrapped in another scale transform (`q-preview-surface`). The preview is consequently a scaled rendering of a scaled/fitted document, while the PDF is a fitted document rendered at native A4 width.

### P1 — Contact information is structurally easy to misread

The company email is rendered in `DocumentHeader` before the customer block. The customer phone and customer email are rendered later in `Page1`. The visual preview may be correct, but the accessibility tree concatenates the header email with `To,` (“watersunelectrical@gmail.com To,”), which is evidence that the grouping/order is not explicit enough.

The phone/email rows also use `inline-flex` plus inherited typography overrides. This is not the primary cause of clipping, but it makes the “phone/email above the text” complaint plausible at narrow widths and increases sensitivity to wrapping.

The print screenshot confirms a concrete styling defect: `.q-company-email` overrides the shared row's centered alignment with `align-items: flex-start` (`quotation.css`, around lines 112–120). The mail icon therefore aligns to the top of the text box rather than the text baseline/center. The phone row does not make that override, so the two contact rows render inconsistently. This should be a small targeted alignment fix after the shared readiness/fitting fix.

### P1 — Preview viewport can itself look clipped at manual zoom

`QuotationModule.jsx` caps the preview surface at a fixed 794px document width and applies a manual transform. At 73% in the live capture, the right edge of the page was outside the available viewport. That is expected for manual zoom, but there is no clear horizontal-zoom affordance or fit-to-width reset, so users can interpret viewport cropping as a broken quotation.

### P2 — Current automated browser regression did not complete

The existing browser test was run against the local test port. It could not launch its separate headless Chrome process in this environment (`Target page, context or browser has been closed`). The live in-app browser did load the fixture, captured the relevant states, and reported no page console errors in the inspected state. The PDF download action completed in the live preview and showed the app's “Download complete” confirmation, but the in-app browser did not expose the downloaded file path for pixel comparison.

## Step-by-step health

1. Quotation list — Healthy. Actions, search, filters, card actions, and responsive partner layout were reachable.
2. Customer editor — Healthy with minor polish issues. Fields were readable at the mobile fixture width and the sticky bottom actions were visible; no horizontal overflow was observed.
3. Document preview — At risk. The document loaded, but the first render showed a footer/page-boundary condition and preview scale can create apparent cropping.
4. PDF/print export — At risk. The export path uses a separate hidden DOM host and a different asset-readiness sequence, so visual parity is not guaranteed.

## Recommended repair order

1. Create one shared `waitForQuotationAssets(root)` routine and use it in both preview and PDF before the first fit. It must await fonts and all non-broken images, with an explicit fallback for failed optional assets.
2. Make fitting deterministic and idempotent: reset all inline fit styles, measure only after assets are ready, fit against the same 794×1123 CSS-pixel page box, and verify `body + footer <= available` after applying the scale.
3. Add a visible development-only diagnostic when content cannot fit: page number, measured body height, footer height, available height, and applied scale. Do not silently clip.
4. Replace `overflow-hidden` as the safety mechanism with a fit assertion and a controlled error state. Keep clipping only for the final raster/PDF capture after the fit assertion passes.
5. Add a true preview-vs-export regression: render the preview DOM and the export DOM from the same fixture after the same readiness promise, then compare page dimensions, fit scale, footer bounds, and raster snapshots at 794×1123.
6. After parity is stable, simplify the contact markup into explicit labeled groups so company contact and customer contact cannot be concatenated or visually confused.

## Conclusion

The quotation maker does not need a ground-up remake based on the current evidence. It needs a single deterministic rendering pipeline for preview and export, followed by removal of silent overflow clipping. The first fix should target asset readiness and shared fitting; changing footer artwork, adding more manual offsets, or further reducing font sizes would treat the symptoms and likely create another preview/print divergence.

## Fix applied after audit

- Added shared `waitForQuotationAssets()` readiness logic in `DocumentPages.jsx` and reused it from `pdf.jsx`.
- Preview fitting now waits for fonts, images, and one layout frame; broken optional images settle instead of blocking forever.
- Corrected the company email row from `align-items: flex-start` to centered alignment in `quotation.css`.
- Refactored every contact row so its icon and phone/email value live together inside one `.q-contact-content` div; the inner wrapper owns the flex alignment for consistent preview and print layout.
- Added explicit Company details and Customer details groups for clearer visual/accessibility separation.
- Added a `Fit width` preview control to recover from manual zoom cropping.
- Added a post-fit safety assertion so content that still exceeds the usable A4 area reports an error instead of being silently clipped.
- Verified with the live preview: Page 1 footer bounds remained inside the page, all pages reported zero overflow, and the email row computed as `align-items: center`.
- Verified PDF generation completed and showed the app's download confirmation.
- `npm run build` passed. `npm run lint` passed with pre-existing warnings and no errors. The separate headless browser regression could not launch Chrome in this environment.
