export const CRM_EXPORT_LINK_SECONDS = 24 * 60 * 60;
export const CRM_EXPORT_MAX_BYTES = 100 * 1024 * 1024;

export async function createCrmExportShareLink(file, userId, client) {
    if (!file || !userId || !client) throw new Error('The export file and account are required.');
    if (!file.name?.toLowerCase().endsWith('.csv')) throw new Error('Only CRM CSV exports can be shared.');
    if (file.size > CRM_EXPORT_MAX_BYTES) throw new Error('This export is too large for a share link. Download it instead.');

    const path = `${userId}/${crypto.randomUUID()}.csv`;
    const bucket = client.storage.from('crm-exports');
    const { error: uploadError } = await bucket.upload(path, file, { contentType: 'text/csv', upsert: false });
    if (uploadError) throw new Error(`Could not upload the export: ${uploadError.message}`);

    const { data, error: signError } = await bucket.createSignedUrl(path, CRM_EXPORT_LINK_SECONDS, {
        download: file.name,
    });
    if (signError || !data?.signedUrl) {
        await bucket.remove([path]);
        throw new Error(`Could not create the share link: ${signError?.message || 'unknown error'}`);
    }
    return data.signedUrl;
}
