# CRM additions: implementation and rollout

Run [the SQL script](scripts/add_chat_availability_and_batch_order.sql) in the Supabase SQL Editor before publishing if chat and availability have not been created yet. If they already exist, run [the private chat policy update](scripts/private_chat_for_everyone.sql) instead. The connected Supabase project differs from this app's configured project, so these changes have not been applied to the app database. Neither script changes the existing `admin` table or its data.

| Request | App change | SQL / data effect |
| --- | --- | --- |
| Crop photos | Admin/office can crop JPEG, PNG, or WebP attachments in Documents. A new cropped image is uploaded first, then the original document is removed. If replacement fails, the new image is rolled back. | Uses existing Storage bucket and `documents` table; no new schema. |
| Recent activity ordering | Customer lists use the existing `admin.updated_at` and `admin.created_at` fields. A new customer starts at creation time; after an edit, its update time moves it to the top. The card says **Created** until a later update exists, then **Updated**. | No `admin` schema or data change in this SQL. The live update trigger has not been verified. |
| Team chat | Bottom-right chat panel on phones and computers for every signed-in role. Users see only their messages and replies. Admin and office staff see all conversations and can reply to each person. Topics: General, Installation, Material delivery. | `crm_chat_messages` grants and RLS restrict user messages by sender/recipient ID and allow staff access to all chats. New public messages are disabled. |
| Vendor calendar | Vendors mark their own unavailable dates on mobile by tapping a day or range. Admin and office roles can view all vendor dates. Staff leave submission and review have been removed from this calendar. | `crm_availability` RLS permits vendor entries only; existing staff leave rows are retained but hidden. Vendor names are stored on calendar entries for staff visibility. |
| Truck loading sheet | Loads existing BOMs for projects in a batch and prints summed material requirements, per-customer quantities, and a prominent missing-BOM list. Unclear quantities stay separate for review. | Uses existing `bom`, `bom_items`, and `admin.bom_data`; no new schema. |
| Stop order | Up/down controls change the batch `project_ids` order; the gate pass and truck sheet use that same order. | Updates one existing `delivery_batches` row; no new schema. |

## After running SQL

1. Refresh the CRM so the new tables are available to PostgREST.
2. Verify a vendor sees only their own calendar entries, Sales can request leave, and Admin can approve it.
3. Verify CPO can read and send public messages, send a private Admin message, and receive an Admin reply.
4. Print a batch with at least two saved BOMs and confirm both the summed amounts and the stop order.

Local checks completed: production Vite build, lint for new components, and a BOM aggregation test. Live RLS and database writes require the SQL to be run on the Supabase project.
