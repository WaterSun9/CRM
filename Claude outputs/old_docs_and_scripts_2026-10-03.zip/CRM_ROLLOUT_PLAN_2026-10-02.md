# CRM rollout order

The app is configured for Supabase project `cjskyhxameobcqlfiuav`; the connected project is different. Apply the SQL below to the configured project before publishing the matching UI. Keep each stage separately reversible and verify its role permissions before moving to the next.

1. **Vendor calendar.** Show vendor unavailable dates to vendors and office roles. Vendors alone can add or remove their dates. Existing staff leave rows remain in storage but are hidden. Apply `scripts/add_chat_availability_and_batch_order.sql` if the base tables do not exist; otherwise apply `scripts/vendor_calendar_only.sql`. The first script also creates the chat table. If the chat table already exists, apply `scripts/private_chat_for_everyone.sql` for its private rules.
2. **Exports.** Add a read-only vendor payment page and downloadable Excel workbook. “This month” uses installation date; “all” includes every paid and pending installation payment. The admin dashboard's full customer CSV can also create a private 24-hour share link after `scripts/crm_export_share_links.sql` is applied.
3. **Field Service Management.** Add the technician account role, a separate issue queue and per-visit travel/amount records. Admin, Sales, Channel Partner Office, managers, channel partners and dealers can raise issues. Admin and Sales review all jobs; technicians see only summary fields in the open queue, claim the first available job atomically, then see the full assignment and can give it up with a reason. The supplied form is the source for issue fields. A private storage bucket holds up to five JPG, PNG, WebP or PDF files of 10 MB each. Apply `scripts/technician_service_portal.sql`. No changes to existing customer or vendor tables.
4. **Completed customer payment review.** Add a review flag with a reason inside the installation payment log. It does not change payment status and is unrelated to technician jobs. Apply `scripts/customer_payment_review_flags.sql`.
5. **Quotation to lead.** Enable the existing “Add to Leads” action. It opens the full Add Lead form with quotation fields prefilled, so the user verifies and completes the lead before saving. The existing conversion link makes retries idempotent. Visual redesign of quotations is a separate follow-up after a design reference is agreed.
6. **Warranty page last.** Plan a live/expired split based on invoice date plus five calendar years. Build the page after confirming the invoice-date source, which records qualify, and any additional warranty rules. No warranty code or database changes are included in this rollout.

## Checks before release

- Apply each SQL script to the configured project, inspect the resulting policies, and test one account per role. The connected project cannot verify or receive these scripts.
- Use `CRM_SQL_SETUP_2026-10-02.md` for the exact SQL Editor order and post-run queries. Do not use the connected Ray2Volt project for this CRM.
- On a phone, verify vendor calendar range selection, technician claim/give-up, the service issue form and attachments, and the Excel export.
- Test two technicians claiming the same open issue at once: only one update should return a row.
- Keep kilometre and amount as staff-entered values per visit. Google Maps Timeline lives on the technician's device and requires a separate consented import workflow; it is not automatically connected to this portal.
