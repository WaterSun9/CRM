# ocbotober udpated

October 2026 CRM setup and rollout notes. The top-right Export downloads a CSV to the current device; its completion popup now offers only **Done**. No export-link bucket or export-link SQL is needed.

## Use the correct Supabase project

The CRM `.env` points to `cjskyhxameobcqlfiuav`. The Supabase connection available in this Codex session exposes a different project (`veopitwbxvgctaruhkia`, Ray2Volt Toolbox), so these patches have **not** been applied to the CRM database. Open the SQL Editor for `cjskyhxameobcqlfiuav` and verify the project identifier in the browser address before running anything. The app's publishable key cannot create tables or storage policies.

## Read-only preflight

Run this first in that project's SQL Editor. `NULL` means the object is absent from the database. A browser `PGRST205` error alone can also mean the table is not exposed through the Data API, so use this check before deciding which patch to run.

```sql
select to_regprocedure('public.get_my_user_type()') as role_helper,
       to_regclass('public.crm_chat_messages') as chat,
       to_regclass('public.crm_availability') as vendor_calendar,
       to_regclass('public.service_issues') as service_issues,
       to_regclass('public.service_visits') as service_visits,
       to_regclass('public.service_issue_files') as service_files,
       to_regclass('public.customer_payment_review_flags') as payment_review;
select id, public, file_size_limit from storage.buckets
where id = 'service-issues';
```

If `role_helper` is `NULL`, stop: the existing role helper must be restored before these policies can be installed. Run each applicable active block below as a separate SQL Editor execution. Section 3 is deferred; do not run its SQL yet. Stop at an error and inspect it before retrying. **Do not run `scripts/crm_export_share_links.sql`**; the share-link action has been removed. Vendor payment Excel downloads need no SQL from this file. Quotation Maker is paused for October R&D; see `october batch.md`.

## 1. Chat and vendor calendar

Run this block first. It creates the private chat and vendor availability tables when missing and applies the current row policies. It is designed to be rerun if earlier versions exist.

Source: `scripts/add_chat_availability_and_batch_order.sql`.

```sql
-- Apply before deploying the matching UI. Creates or updates only chat and
-- availability tables. Safe to rerun if their earlier versions already exist.
-- Does not alter, update, or index public.admin.
begin;

create table if not exists public.crm_chat_messages (
    id uuid primary key default gen_random_uuid(),
    sender_id uuid not null references auth.users(id),
    recipient_id uuid references auth.users(id),
    audience text not null check (audience in ('public', 'admin')),
    constraint crm_chat_public_no_recipient check (audience = 'admin' or recipient_id is null),
    topic text not null check (topic in ('general', 'installation', 'material_delivery')),
    body text not null check (length(trim(body)) between 1 and 2000),
    created_at timestamptz not null default now()
);
create index if not exists crm_chat_messages_audience_time_idx on public.crm_chat_messages (audience, created_at desc);
create index if not exists crm_chat_messages_sender_time_idx on public.crm_chat_messages (sender_id, created_at desc);
alter table public.crm_chat_messages enable row level security;
grant select, insert on public.crm_chat_messages to authenticated;
revoke all on public.crm_chat_messages from anon;

drop policy if exists crm_chat_read on public.crm_chat_messages;
create policy crm_chat_read on public.crm_chat_messages for select to authenticated
using (
    public.get_my_user_type() in ('admin', 'sales', 'channel_partner_office', 'office2')
    or sender_id = (select auth.uid())
    or recipient_id = (select auth.uid())
);
drop policy if exists crm_chat_send on public.crm_chat_messages;
create policy crm_chat_send on public.crm_chat_messages for insert to authenticated
with check (
    sender_id = (select auth.uid())
    and audience = 'admin'
    and (
        (public.get_my_user_type() in ('admin', 'sales', 'channel_partner_office', 'office2') and recipient_id is not null)
        or (public.get_my_user_type() in ('agent', 'agent2', 'vendor', 'stamp', 'technician') and recipient_id is null)
    )
);

create table if not exists public.crm_availability (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references auth.users(id),
    vendor_name text not null default '',
    entry_kind text not null check (entry_kind in ('vendor_unavailable', 'staff_leave')),
    start_date date not null,
    end_date date not null,
    note text not null default '' check (length(note) <= 500),
    status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
    created_at timestamptz not null default now(),
    reviewed_at timestamptz,
    reviewed_by uuid references auth.users(id),
    unique (user_id, entry_kind, start_date, end_date),
    check (end_date >= start_date),
    check (end_date <= start_date + 365)
);
alter table public.crm_availability add column if not exists vendor_name text not null default '';
update public.crm_availability entry set vendor_name = coalesce(profile.name, 'Vendor')
from public.profiles profile
where entry.user_id = profile.id and entry.entry_kind = 'vendor_unavailable' and entry.vendor_name = '';
create index if not exists crm_availability_dates_idx on public.crm_availability (start_date, end_date);
create index if not exists crm_availability_user_idx on public.crm_availability (user_id, start_date desc);
alter table public.crm_availability enable row level security;
grant select, insert, delete on public.crm_availability to authenticated;
revoke update on public.crm_availability from authenticated;
revoke all on public.crm_availability from anon;

create or replace function public.set_crm_availability_vendor_name()
returns trigger language plpgsql security invoker set search_path = public, pg_temp as $$
begin
    new.vendor_name := coalesce((select name from public.profiles where id = auth.uid()), 'Vendor');
    return new;
end;
$$;
drop trigger if exists crm_availability_vendor_name on public.crm_availability;
create trigger crm_availability_vendor_name before insert on public.crm_availability
for each row execute function public.set_crm_availability_vendor_name();

drop policy if exists crm_availability_read on public.crm_availability;
create policy crm_availability_read on public.crm_availability for select to authenticated
using (
    entry_kind = 'vendor_unavailable'
    and (public.get_my_user_type() in ('admin', 'sales', 'channel_partner_office', 'office2')
         or (public.get_my_user_type() = 'vendor' and user_id = (select auth.uid())))
);
drop policy if exists crm_availability_create on public.crm_availability;
create policy crm_availability_create on public.crm_availability for insert to authenticated
with check (
    user_id = (select auth.uid()) and reviewed_at is null and reviewed_by is null
    and public.get_my_user_type() = 'vendor' and entry_kind = 'vendor_unavailable' and status = 'approved'
);
drop policy if exists crm_availability_admin_review on public.crm_availability;
drop policy if exists crm_availability_remove on public.crm_availability;
create policy crm_availability_remove on public.crm_availability for delete to authenticated
using (public.get_my_user_type() = 'vendor' and user_id = (select auth.uid()) and entry_kind = 'vendor_unavailable');

-- delivery_batches.project_ids already stores the route order; no batch schema
-- change is needed. Reordering updates only that batch row.

commit;
```

## 2. Technician service management

Run this block only when service_issues, service_visits, and service_issue_files are all absent in the preflight. If only some exist, inspect the live schema before applying a repair.

Source: `scripts/technician_service_portal.sql`.

```sql
-- Standalone service workflow. Does not change customer or vendor tables.
begin;

create table if not exists public.service_issues (
    id uuid primary key default gen_random_uuid(),
    channel_partner_name text,
    consumer_no text not null check (length(trim(consumer_no)) between 1 and 100),
    customer_name text not null check (length(trim(customer_name)) between 1 and 160),
    customer_phone text,
    service_address text,
    problem_type text not null check (length(trim(problem_type)) between 1 and 160),
    system_company_name text,
    system_kw numeric(9,2) check (system_kw is null or system_kw >= 0),
    comment text not null default '' check (length(comment) <= 2000),
    required_date date not null,
    status text not null default 'open' check (status in ('open', 'assigned', 'completed')),
    assigned_to uuid references auth.users(id),
    assigned_at timestamptz,
    give_up_reason text,
    created_by uuid not null references auth.users(id),
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    constraint service_issue_assignment_matches_status check (
        (status = 'open' and assigned_to is null) or (status in ('assigned', 'completed') and assigned_to is not null)
    )
);
create index if not exists service_issues_status_date_idx on public.service_issues(status, required_date);
create index if not exists service_issues_technician_idx on public.service_issues(assigned_to, required_date);
alter table public.service_issues enable row level security;
revoke all on public.service_issues from anon;
grant select, insert, update on public.service_issues to authenticated;

create policy service_issues_read on public.service_issues for select to authenticated
using (
    public.get_my_user_type() in ('admin', 'sales')
    or created_by = (select auth.uid())
    or (public.get_my_user_type() = 'technician' and assigned_to = (select auth.uid()))
);
create policy service_issues_create on public.service_issues for insert to authenticated
with check (
    public.get_my_user_type() in ('admin', 'sales', 'channel_partner_office', 'channel_partner_office_manager', 'office2', 'agent', 'agent2')
    and created_by = (select auth.uid())
    and status = 'open' and assigned_to is null
);
create policy service_issues_update on public.service_issues for update to authenticated
using (
    public.get_my_user_type() in ('admin', 'sales')
    or (public.get_my_user_type() = 'technician' and assigned_to = (select auth.uid()))
)
with check (
    public.get_my_user_type() in ('admin', 'sales')
    or (public.get_my_user_type() = 'technician' and (assigned_to = (select auth.uid()) or (status = 'open' and assigned_to is null)))
);

-- Only queue summary fields are visible before a technician claims a job.
create or replace function public.open_service_issue_queue()
returns table (id uuid, customer_name text, problem_type text, required_date date,
    status text, give_up_reason text)
language plpgsql security definer set search_path = public, pg_temp as $$
begin
    if public.get_my_user_type() <> 'technician' then
        raise exception 'Technician account required';
    end if;
    return query select issue.id, issue.customer_name, issue.problem_type,
        issue.required_date, issue.status, issue.give_up_reason
    from public.service_issues issue where issue.status = 'open'
    order by issue.required_date, issue.created_at;
end;
$$;
revoke all on function public.open_service_issue_queue() from public, anon;
grant execute on function public.open_service_issue_queue() to authenticated;

-- The status condition is checked again while locking the row, so only the
-- first technician can claim it. The full record then becomes visible via RLS.
create or replace function public.claim_service_issue(p_issue_id uuid)
returns boolean language plpgsql security definer set search_path = public, pg_temp as $$
declare claimed_id uuid;
begin
    if public.get_my_user_type() <> 'technician' then
        raise exception 'Technician account required';
    end if;
    update public.service_issues issue
    set status = 'assigned', assigned_to = auth.uid(), assigned_at = now(), give_up_reason = null
    where issue.id = p_issue_id and issue.status = 'open'
    returning issue.id into claimed_id;
    return claimed_id is not null;
end;
$$;
revoke all on function public.claim_service_issue(uuid) from public, anon;
grant execute on function public.claim_service_issue(uuid) to authenticated;

create or replace function public.give_up_service_issue(p_issue_id uuid, p_reason text)
returns boolean language plpgsql security definer set search_path = public, pg_temp as $$
declare changed_id uuid;
begin
    if public.get_my_user_type() <> 'technician' or length(trim(coalesce(p_reason, ''))) = 0 then
        raise exception 'Technician account and give-up reason required';
    end if;
    update public.service_issues issue
    set status = 'open', assigned_to = null, assigned_at = null, give_up_reason = trim(p_reason)
    where issue.id = p_issue_id and issue.status = 'assigned' and issue.assigned_to = auth.uid()
    returning issue.id into changed_id;
    return changed_id is not null;
end;
$$;
revoke all on function public.give_up_service_issue(uuid, text) from public, anon;
grant execute on function public.give_up_service_issue(uuid, text) to authenticated;

-- RLS and this guard also limit which fields a technician can change.
create or replace function public.guard_service_issue_update()
returns trigger language plpgsql security invoker set search_path = public, pg_temp as $$
begin
    if auth.uid() is not null and public.get_my_user_type() = 'technician' then
        if (to_jsonb(new) - array['status','assigned_to','assigned_at','give_up_reason','updated_at'])
           is distinct from (to_jsonb(old) - array['status','assigned_to','assigned_at','give_up_reason','updated_at']) then
            raise exception 'Technicians cannot edit issue details';
        end if;
        if old.status = 'open' and new.status = 'assigned' and new.assigned_to = auth.uid()
           and new.assigned_at is not null and new.give_up_reason is null then
            null;
        elsif old.status = 'assigned' and old.assigned_to = auth.uid() and new.status = 'open'
           and new.assigned_to is null and new.assigned_at is null
           and length(trim(coalesce(new.give_up_reason, ''))) > 0 then
            null;
        else
            raise exception 'Only claiming an open issue or giving up your assignment is allowed';
        end if;
    end if;
    new.updated_at := now();
    return new;
end;
$$;
drop trigger if exists service_issue_guard on public.service_issues;
create trigger service_issue_guard before update on public.service_issues
for each row execute function public.guard_service_issue_update();

create table if not exists public.service_visits (
    id uuid primary key default gen_random_uuid(),
    issue_id uuid not null references public.service_issues(id) on delete cascade,
    technician_id uuid not null references auth.users(id),
    visit_date date not null,
    kilometers numeric(9,2) not null check (kilometers >= 0),
    amount_inr numeric(12,2) not null check (amount_inr >= 0),
    note text not null default '' check (length(note) <= 1000),
    entered_by uuid not null references auth.users(id),
    created_at timestamptz not null default now()
);
create index if not exists service_visits_issue_date_idx on public.service_visits(issue_id, visit_date);
alter table public.service_visits enable row level security;
revoke all on public.service_visits from anon;
grant select, insert on public.service_visits to authenticated;
create policy service_visits_read on public.service_visits for select to authenticated
using (
    public.get_my_user_type() in ('admin', 'sales')
    or (public.get_my_user_type() = 'technician' and technician_id = (select auth.uid()))
);
create policy service_visits_create on public.service_visits for insert to authenticated
with check (
    public.get_my_user_type() in ('admin', 'sales') and entered_by = (select auth.uid())
    and exists (select 1 from public.service_issues issue
        where issue.id = issue_id and issue.assigned_to = technician_id)
);

create table if not exists public.service_issue_files (
    id uuid primary key default gen_random_uuid(),
    issue_id uuid not null references public.service_issues(id) on delete cascade,
    storage_path text not null unique,
    file_name text not null,
    mime_type text not null,
    uploaded_by uuid not null references auth.users(id),
    created_at timestamptz not null default now()
);
create index if not exists service_issue_files_issue_idx on public.service_issue_files(issue_id);
alter table public.service_issue_files enable row level security;
revoke all on public.service_issue_files from anon;
grant select, insert, delete on public.service_issue_files to authenticated;
create policy service_issue_files_read on public.service_issue_files for select to authenticated
using (exists (
    select 1 from public.service_issues issue where issue.id = issue_id
    and (public.get_my_user_type() in ('admin', 'sales') or issue.created_by = (select auth.uid())
         or issue.assigned_to = (select auth.uid()))
));
create policy service_issue_files_create on public.service_issue_files for insert to authenticated
with check (
    uploaded_by = (select auth.uid())
    and storage_path like issue_id::text || '/' || (select auth.uid())::text || '/%'
    and exists (select 1 from public.service_issues issue where issue.id = issue_id
        and (public.get_my_user_type() in ('admin', 'sales') or issue.created_by = (select auth.uid())))
);
create policy service_issue_files_remove on public.service_issue_files for delete to authenticated
using (uploaded_by = (select auth.uid()) or public.get_my_user_type() in ('admin', 'sales'));

create or replace function public.limit_service_issue_files()
returns trigger language plpgsql security invoker set search_path = public, pg_temp as $$
begin
    perform pg_advisory_xact_lock(hashtextextended(new.issue_id::text, 0));
    if (select count(*) from public.service_issue_files where issue_id = new.issue_id) >= 5 then
        raise exception 'A service issue can have at most 5 files';
    end if;
    return new;
end;
$$;
drop trigger if exists service_issue_file_limit on public.service_issue_files;
create trigger service_issue_file_limit before insert on public.service_issue_files
for each row execute function public.limit_service_issue_files();

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('service-issues', 'service-issues', false, 10485760, array['image/jpeg','image/png','image/webp','application/pdf'])
on conflict (id) do nothing;

create policy service_issue_storage_read on storage.objects for select to authenticated
using (
    bucket_id = 'service-issues' and exists (
        select 1 from public.service_issues issue
        where issue.id::text = split_part(name, '/', 1)
        and (public.get_my_user_type() in ('admin', 'sales') or issue.created_by = (select auth.uid())
             or issue.assigned_to = (select auth.uid()))
    )
);
create policy service_issue_storage_upload on storage.objects for insert to authenticated
with check (
    bucket_id = 'service-issues' and split_part(name, '/', 2) = (select auth.uid())::text
    and exists (select 1 from public.service_issues issue
        where issue.id::text = split_part(name, '/', 1)
        and (public.get_my_user_type() in ('admin', 'sales') or issue.created_by = (select auth.uid())))
);
create policy service_issue_storage_remove on storage.objects for delete to authenticated
using (
    bucket_id = 'service-issues'
    and (split_part(name, '/', 2) = (select auth.uid())::text
         or public.get_my_user_type() in ('admin', 'sales'))
);

commit;
```

## 3. Deferred customer red flags at every stage — do not run yet

This section is saved for a later session. The app UI is disabled with `CUSTOMER_RED_FLAGS_ENABLED = false`. Do not run this block during the current rollout. When the feature is resumed, run it only when `customer_payment_review_flags` is absent in the preflight. This is a simple red flag on any customer record, including leads. It needs no reason and does not block payments or service. Admin, staff, CPO and CPO staff may toggle it on records they can access. The internal table name is retained for compatibility.

Source: `scripts/customer_payment_review_flags.sql`.

```sql
-- DEFERRED DRAFT: do not run until the red-flag feature is resumed.
-- Customer red flag for any active CRM record, including leads.
-- The table name is retained for compatibility with existing app queries.
-- Apply only after the read-only preflight confirms this table is absent.
begin;

create table public.customer_payment_review_flags (
    admin_id uuid primary key references public.admin(id) on delete cascade,
    active boolean not null default true,
    updated_by uuid not null references auth.users(id),
    updated_at timestamptz not null default now()
);
alter table public.customer_payment_review_flags enable row level security;
revoke all on public.customer_payment_review_flags from anon;
grant select, insert, update on public.customer_payment_review_flags to authenticated;

-- The admin table's existing RLS supplies the customer's branch/partner scope.
create policy customer_payment_flags_read on public.customer_payment_review_flags for select to authenticated
using (exists (
    select 1 from public.admin customer
    where customer.id = admin_id and customer.deleted_at is null
) and (select public.get_my_user_type()) in ('admin', 'sales', 'channel_partner_office', 'office2', 'channel_partner_office_manager'));
create policy customer_payment_flags_create on public.customer_payment_review_flags for insert to authenticated
with check (
    (select public.get_my_user_type()) in ('admin', 'sales', 'channel_partner_office', 'office2', 'channel_partner_office_manager')
    and updated_by = (select auth.uid())
    and exists (select 1 from public.admin customer where customer.id = admin_id and customer.deleted_at is null)
);
create policy customer_payment_flags_update on public.customer_payment_review_flags for update to authenticated
using (
    (select public.get_my_user_type()) in ('admin', 'sales', 'channel_partner_office', 'office2', 'channel_partner_office_manager')
    and exists (select 1 from public.admin customer where customer.id = admin_id and customer.deleted_at is null)
)
with check (
    (select public.get_my_user_type()) in ('admin', 'sales', 'channel_partner_office', 'office2', 'channel_partner_office_manager')
    and updated_by = (select auth.uid())
    and exists (select 1 from public.admin customer where customer.id = admin_id and customer.deleted_at is null)
);

commit;
```

## Verify after applying

Run the object and policy checks below. A SQL Editor query proves the objects exist, but it does not prove vendor, staff, dealer, or technician access. Test each role in the CRM after the SQL checks.

```sql
select to_regclass('public.crm_chat_messages') as chat,
       to_regclass('public.crm_availability') as vendor_calendar,
       to_regclass('public.service_issues') as service_issues,
       to_regclass('public.service_visits') as service_visits,
       to_regclass('public.service_issue_files') as service_files,
       to_regclass('public.customer_payment_review_flags') as payment_review;

select schemaname, tablename, policyname, cmd from pg_policies
where (schemaname = 'public' and tablename in
       ('crm_chat_messages', 'crm_availability', 'service_issues',
        'service_visits', 'service_issue_files', 'customer_payment_review_flags'))
   or (schemaname = 'storage' and tablename = 'objects'
       and policyname like 'service_issue_%')
order by schemaname, tablename, policyname;

select id, public, file_size_limit from storage.buckets
where id = 'service-issues';
```

Then check these actions in the app:

1. Vendor marks one unavailable date; office staff can see it, and the vendor can remove it. If the calendar still says setup is incomplete, use **Try again** after confirming the table and Data API access.
2. A dealer sends a chat; that dealer sees only their own thread, while admin and office staff can see and reply to it.
3. On a completed customer card, use **Raise issue**. The popup should fill partner, consumer number, customer name, phone, address, system brand, and kW from that record; required date starts at today. Enter the problem type, comment, and optional files, then submit. This uses the service tables from section 2. Two technicians should not be able to claim the same issue; staff enter both kilometres and the visit amount.
4. Dashboard Export downloads a CSV and the completion popup shows only **Done**. No share link is created.

If the preflight finds existing or partial service tables, do not paste the service block blindly. Compare the live columns, policies, and functions with the source script and prepare a targeted migration. Do not run any of these patches against the Ray2Volt project.
