// ─── CustomerDetailModal.jsx ──────────────────────────────────────────────────
// Full customer detail: 4-tab layout (Overview, Finance & Bank, Checklist,
// Notes & History). Section-level editing, payments array editor, generic
// history entry editor, financial tag toggle, and system activity timeline.
//
// CLIENT CUSTOMISATION:
//   • Sections and fields: edit the <section> blocks in the Overview/Finance tabs
//   • Checklist template: edit DEFAULT_PROJECT_CHECKLIST in models.jsx
//   • Stage/tag options: edit constants.js
// ──────────────────────────────────────────────────────────────────────────────

import { useState, useEffect, useRef, useCallback } from 'react';
import {
    X, Edit3, Trash2, Save, Send, AlertTriangle, CheckSquare,
    User, Zap, IndianRupee, Building2, FolderOpen, MapPin,
    LayoutDashboard, History, Plus, ShieldCheck, Lock, Unlock, ClipboardList, Banknote, Tag, Mail, PauseCircle, Check,
    Eye, Search, Image as ImageIcon, MessageSquare, Calendar, Flag
} from 'lucide-react';
import { PRIMARY_STAGES, STAGE_IDS, SUBSIDY_TAGS, SUBSIDY_TAG_COLORS, LOAN_TAGS, LOAN_TAG_COLORS, ROOF_BOM_TEMPLATE, SHED_BOM_TEMPLATE, DOC_TYPE_LABELS, DOC_TYPE_FLAG_COLUMN } from '../constants';
import { logActivity, formatDateToDDMMYYYY, parseIndianNumber, fetchAgent2SubAgents, normalizeMeterInstallation, sanitizePhoneNumber, logFieldChanges, readAdminFields } from '../utils';
import { supabase } from '../supabase';
import HistoryEntryEditor from './HistoryEntryEditor';
import { AgreementPreview } from './agreement/AgreementPreview';
import { Page1 } from './agreement/Page1';
import { FileText, Printer } from 'lucide-react';
import { uploadDocument, getCustomerDocuments, getDownloadUrl, getViewUrl, deleteDocument, updateDocumentRemark, downloadFileWithSaveAs, downloadDocumentsAsPdf } from '../utils';

const getDocTypeLabel = (type) => {
    if (!type) return 'Client Attachment';
    if (DOC_TYPE_LABELS[type]) return DOC_TYPE_LABELS[type];
    return String(type).split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
};

import CustomerModalTabsRouter from './CustomerModalTabsRouter';
import CropPhotoModal from './CropPhotoModal';
import LeadsTab from './modal-tabs/LeadsTab';
import RegistrationTab from './modal-tabs/RegistrationTab';
import LoanTab from './modal-tabs/LoanTab';
import CashTab from './modal-tabs/CashTab';
import MaterialOrderTab from './modal-tabs/MaterialOrderTab';
import MaterialIntegrationTab from './modal-tabs/MaterialIntegrationTab';
import HoldProcurementTab from './modal-tabs/HoldProcurementTab';
import MaterialDeliveryTab from './modal-tabs/MaterialDeliveryTab';
import InstallationStatusTab from './modal-tabs/InstallationStatusTab';
import GeoTagPhotoTab from './modal-tabs/GeoTagPhotoTab';
import DiscomSubmissionTab from './modal-tabs/DiscomSubmissionTab';
import MeterInstallationTab from './modal-tabs/MeterInstallationTab';
import DiscomInspectionTab from './modal-tabs/DiscomInspectionTab';
import SubsidyStatusTab from './modal-tabs/SubsidyStatusTab';
import FinalReviewTab from './modal-tabs/FinalReviewTab';
import HistoryTab from './modal-tabs/HistoryTab';
import CustomerDocumentsTab from './modal-tabs/CustomerDocumentsTab';
import { FilePreviewModal, DocGalleryRemarkRow, getStageRemarkFromData } from './modal-tabs/shared';
import { useGlobalPopup } from './GlobalPopup';
import { RedFlagBadge, RedFlagToggle } from './RedFlag';
import ConflictResolutionModal from './ConflictResolutionModal';
import { normalizeInstallationStatus } from '../utils';
import { findUnsavedFields, fieldLabel, valuesMatch, mergeServerRecord } from '../utils/saveCheck';
import { missingDetailsForMove } from '../utils/stageRequirements';
import { formatCustomerTimestamp } from '../utils/customerActivity';

// ─── formatDateTime: helper to format date as "04 Aug, 11:01 PM" ──────────────
const formatDateTime = (date) => {
    if (!date) return '–';
    const dObj = typeof date === 'string' ? new Date(date) : date;
    if (isNaN(dObj.getTime())) return String(date);
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const d = dObj.getDate().toString().padStart(2, '0');
    const m = months[dObj.getMonth()];
    let hours = dObj.getHours();
    const minutes = dObj.getMinutes().toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12;
    const h = hours.toString().padStart(2, '0');
    return `${d} ${m}, ${h}:${minutes} ${ampm}`;
};


// ─── Subsidy status options ───────────────────────────────────────────────────

// Keys whose draft value differs from the saved value. Uses the same rules as
// the save check (valuesMatch), so a number the database returns as 171000
// is not mistaken for a change from the form's '1,71,000' - which would leave
// the form looking unsaved after a successful save - and jsonb key order does
// not count as a change.
// Screen-only flags on history rows (isNew marks a row added in this session).
// They are stripped before saving, so they must not count as a change - they
// kept the form "unsaved" after a successful save, and the next tab switch
// asked to save again with nothing changed.
const withoutUiFlags = (value) => (Array.isArray(value)
    ? value.map(item => (item && typeof item === 'object' && 'isNew' in item ? (({ isNew, ...rest }) => rest)(item) : item))
    : value);

// Yes/No toggles that show a blank value as "No". Blank and "No" are the
// same answer, so No -> Yes -> No is not a change.
const BLANK_MEANS_NO = new Set(['meter_installation', 'discom_inspection', 'geo_tag_status']);
const toggleValue = (key, value) => {
    if (!BLANK_MEANS_NO.has(key)) return value;
    const text = key === 'meter_installation' ? normalizeMeterInstallation(value) : String(value ?? '').trim();
    return text || 'No';
};

const getChangedFields = (draft = {}, saved = {}) => {
    const changed = new Set();
    const ignoreKeys = new Set(['id', 'created_at', 'updated_at', 'crn']);
    const keys = new Set([...Object.keys(saved || {}), ...Object.keys(draft || {})]);

    keys.forEach(key => {
        if (ignoreKeys.has(key)) return;
        if (!valuesMatch(toggleValue(key, withoutUiFlags(draft?.[key])), toggleValue(key, withoutUiFlags(saved?.[key])))) changed.add(key);
    });

    return changed;
};

// ─── CustomerDetailModal ──────────────────────────────────────────────────────
export default function CustomerDetailModal({ customer, onClose, onUpdate, onDelete, onRaiseServiceIssue, user, meta, channel_partners = [], defaultTab }) {
    const { showAlert, showConfirm, showChoice } = useGlobalPopup();
    const [activeTab, setActiveTab] = useState(() => {
        if (defaultTab) return defaultTab;
        
        // Force completed customers to open on the LEADS tab by default
        if ((customer?.stage || '').trim().toUpperCase() === STAGE_IDS.COMPLETED) return STAGE_IDS.LEADS;
        
        if (typeof window !== 'undefined') {
            const saved = window.sessionStorage.getItem('watersun_modal_active_tab');
            if (saved) return saved;
        }
        return customer?.stage || STAGE_IDS.LEADS;
    });
    const [editingSection, setEditingSection] = useState(null);
    const [isFormDirty, setIsFormDirty] = useState(false);
    const [editData, setEditData] = useState({ ...customer });
    const savedDataRef = useRef({ ...customer });
    const loadedUpdatedAtRef = useRef(customer?.updated_at || null);
    const [lastUpdatedAt, setLastUpdatedAt] = useState(customer?.updated_at || null);
    const [concurrentConflict, setConcurrentConflict] = useState(null);
    const [remoteUpdateAlert, setRemoteUpdateAlert] = useState(false);
    // Re-enabled (Oct 2026). It was hidden because it fired for people editing
    // alone - it guessed "own save" from a 5-second window. It is now raised only
    // when a fresh read shows fields changed that this window did NOT just write
    // (applyServerRecord), and only while the user has unsaved edits.
    // remoteUpdateAlert = false | { fields: [...], conflicts: [...] }
    const SHOW_REMOTE_UPDATE_ALERT = true;
    // Realtime fires for EVERY update to this row, our own included. Stamp the
    // time of our own writes so the echo is not reported to the user as
    // "a colleague updated this record".
    const lastSelfWriteRef = useRef(0);
    const [subAgents, setSubAgents] = useState([]);

    useEffect(() => {
        const managerBranch = user?.userType === 'office2' ? user?.channel_partner : '';
        const branch = (managerBranch || editData.channel_partner || customer.channel_partner || '').trim();
        if (!branch) { setSubAgents([]); return; }
        let cancelled = false;
        fetchAgent2SubAgents(branch).then(names => { if (!cancelled) setSubAgents(names); });
        return () => { cancelled = true; };
    }, [editData.channel_partner, customer.channel_partner, user?.userType, user?.channel_partner]);

    useEffect(() => {
        if (typeof window !== 'undefined' && activeTab) {
            window.sessionStorage.setItem('watersun_modal_active_tab', activeTab);
        }
    }, [activeTab]);

    // Prevent any scenario where the active tab becomes COMPLETED or CUSTOMER_CARD (since they were removed from the nav)
    // We allow LOST PROJECT because there is an explicit "Move to Lost Project" button that needs to open it.
    useEffect(() => {
        if (activeTab === STAGE_IDS.COMPLETED || activeTab === 'CUSTOMER_CARD') {
            setActiveTab(STAGE_IDS.LEADS);
        }
    }, [activeTab]);


    const handleEditDataChange = (updater) => {
        setEditData(previous => {
            const next = typeof updater === 'function' ? updater(previous) : updater;
            setIsFormDirty(getChangedFields(next, savedDataRef.current).size > 0);
            return next;
        });
    };

    // Set by Material Integration when its BOM details are edited (they live in
    // that tab, not in editData).
    const bomDirtyRef = useRef(false);

    // Before closing or switching tab with unsaved changes: Save & Continue,
    // Keep Editing, or the corner X to discard. The prompt names the changed
    // fields. If nothing really differs from what is stored (the old prompt
    // could fire with no change), it does not ask at all.
    // Resolves true when it is OK to continue.
    const resolveUnsaved = async (confirmLabel) => {
        if (!isFormDirty) return true;
        const fields = [...getChangedFields(editData, savedDataRef.current)].map(fieldLabel);
        if (bomDirtyRef.current) fields.push('Bill of Materials');
        if (fields.length === 0) {
            setIsFormDirty(false);
            return true;
        }
        const shown = fields.slice(0, 6).join(', ') + (fields.length > 6 ? ` and ${fields.length - 6} more` : '');
        const choice = await showChoice(
            `Changed: ${shown}.\n\nSave them, keep editing, or press ✕ to discard.`,
            { title: 'Unsaved changes', confirmLabel, cancelLabel: 'Keep Editing', closeAs: 'discard', closeLabel: 'Discard changes', type: 'success' }
        );
        if (choice === 'confirm') {
            if (!(await handleSave())) return false;
            bomDirtyRef.current = false;
            return true;
        }
        if (choice === 'discard') {
            setEditData({ ...savedDataRef.current });
            setIsFormDirty(false);
            setEditingSection(null);
            bomDirtyRef.current = false;
            return true;
        }
        return false;
    };

    // ── One source of truth for the record (data-loss audit, Oct 2026) ───────
    // savedDataRef is "what the database holds". Save sends only the fields that
    // differ from it, so it MUST be correct. It used to be overwritten from four
    // places, including the Dashboard's slim list row (~33 columns, no inverter
    // or panel serials). Once that happened, Save treated a typed value as
    // already saved and silently left it out - the cause of the lost inverter and
    // panel values - and saved values showed as blank on screen.
    //
    // Now the baseline only ever comes from a FULL read of the row
    // (applyServerRecord), and every outside signal (list refresh, realtime
    // event) just triggers a fresh full read. Fields the user has changed but not
    // saved are always kept. Replies that are older than a later read or save are
    // ignored, so a slow reload can never overwrite newer data.
    const isDemoCustomer = String(customer?.id || '').startsWith('demo-');
    const [fullRecordLoaded, setFullRecordLoaded] = useState(isDemoCustomer);
    const fetchSeqRef = useRef(0);
    const openedIdRef = useRef(null);
    const subscribedOnceRef = useRef(false);   // live feed: first connect vs reconnect
    const savingRef = useRef(false);           // mirrors `saving` for listeners set up once

    // Any save of ours makes every reload that is still in flight out of date.
    const invalidatePendingReloads = () => { fetchSeqRef.current += 1; };

    // Every write from this window goes through here, so we know which fields
    // WE just wrote. A change to those is our own save echoing back, not a
    // colleague's edit - no timing guesswork for the colleague warning.
    const recentWritesRef = useRef({});              // field -> time we last wrote it
    const hasFullBaselineRef = useRef(false);        // first full read compares against the slim copy - not a "remote change"
    const pendingConflictsRef = useRef(new Set());   // fields both I (unsaved) and a colleague changed
    const writeRecord = (id, payload) => {
        const now = Date.now();
        Object.keys(payload || {}).forEach(key => { recentWritesRef.current[key] = now; });
        lastSelfWriteRef.current = now;
        invalidatePendingReloads();
        return onUpdate(id, payload);
    };

    const applyServerRecord = (row) => {
        if (!row || row.id !== customer.id) return;
        const previousBaseline = savedDataRef.current;
        // Fields someone else changed in the database since our last read
        // (ignoring fields we wrote in the last 30s and database-set timestamps).
        const now = Date.now();
        const remoteKeys = hasFullBaselineRef.current
            ? Object.keys(row).filter(key =>
                !['updated_at', 'completed_at'].includes(key)
                && now - (recentWritesRef.current[key] || 0) > 30000
                && !valuesMatch(row[key], previousBaseline?.[key]))
            : [];
        hasFullBaselineRef.current = true;
        savedDataRef.current = { ...row };
        loadedUpdatedAtRef.current = row.updated_at || loadedUpdatedAtRef.current;
        setLastUpdatedAt(row.updated_at || null);
        setEditData(prev => {
            // Fields the user changed relative to the old baseline stay as typed.
            const { next, unsavedKeys } = mergeServerRecord(prev, previousBaseline, row);
            // Same field changed by me (unsaved) and by a colleague, to a different
            // value: remember it, so Save asks instead of silently overwriting.
            unsavedKeys
                .filter(key => remoteKeys.includes(key) && !valuesMatch(row[key], prev[key]))
                .forEach(key => pendingConflictsRef.current.add(key));
            [...pendingConflictsRef.current].forEach(key => {
                if (!unsavedKeys.includes(key)) pendingConflictsRef.current.delete(key);
            });
            if (remoteKeys.length > 0 && unsavedKeys.length > 0) {
                setRemoteUpdateAlert({ fields: remoteKeys, conflicts: [...pendingConflictsRef.current] });
            }
            setIsFormDirty(getChangedFields(next, savedDataRef.current).size > 0);
            return next;
        });
        setFullRecordLoaded(true);
    };

    const refreshFullRecord = async () => {
        if (!customer?.id || isDemoCustomer) return;
        const seq = ++fetchSeqRef.current;
        const { data, error } = await supabase.from('admin').select('*').eq('id', customer.id).maybeSingle();
        if (seq !== fetchSeqRef.current) return;   // a newer read or a save happened meanwhile
        if (error) {
            console.warn('Could not reload the customer record:', error.message);
            return;
        }
        if (data) applyServerRecord(data);
    };

    // Opened (or switched to) a customer: start from what we were given, then
    // load the full record. Same customer with a new prop object (list refresh,
    // stage move, optimistic update): re-read rather than trust the list copy.
    useEffect(() => {
        if (!customer?.id) return;
        if (openedIdRef.current !== customer.id) {
            const switched = openedIdRef.current !== null;
            openedIdRef.current = customer.id;
            if (switched) {
                hasFullBaselineRef.current = false;
                pendingConflictsRef.current.clear();
                recentWritesRef.current = {};
                setRemoteUpdateAlert(false);
                savedDataRef.current = { ...customer };
                loadedUpdatedAtRef.current = customer.updated_at || null;
                setLastUpdatedAt(customer.updated_at || null);
                setEditData({ ...customer });
                setIsFormDirty(false);
                setFullRecordLoaded(isDemoCustomer);
            }
        }
        refreshFullRecord();
        fetchLogs();
        // Deliberately keyed on the customer prop only: the helpers are re-created
        // every render and must not re-trigger the reload.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [customer]);

    // Realtime watch for updates to this specific customer
    useEffect(() => {
        if (!customer?.id || isDemoCustomer) return;

        const channel = supabase.channel(`customer_modal_concurrency_${customer.id}`)
            .on('postgres_changes', {
                event: 'UPDATE',
                schema: 'public',
                table: 'admin',
                filter: `id=eq.${customer.id}`
            }, () => {
                // payload.new can leave out large unchanged columns, so it is
                // never used as the record itself - re-read the full row. The
                // merge keeps anything the user is still editing, and raises
                // the colleague warning only for fields this window did not
                // just write itself (our own saves echo back here too).
                refreshFullRecord();
            })
            .subscribe((status) => {
                // The live feed drops while the laptop sleeps or the network is
                // down, and changes made meanwhile are never replayed. When it
                // reconnects, re-read the record to catch up on what was missed.
                if (status !== 'SUBSCRIBED') return;
                if (subscribedOnceRef.current) refreshFullRecord();
                subscribedOnceRef.current = true;
            });

        return () => {
            subscribedOnceRef.current = false;
            supabase.removeChannel(channel);
        };
        // One subscription per customer; it reads current state through refs.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [customer?.id]);

    // Catch up after being away. A window left open over lunch or overnight
    // misses colleagues' changes (the live feed above is down while the laptop
    // sleeps), so the next Save could not spot a clash. Re-read the record when:
    //  - the tab becomes visible again after 30s or more in the background,
    //  - the browser comes back online,
    //  - the laptop wakes from sleep (a 30s timer that fires minutes late).
    // The re-read uses the same merge as every other reload: unsaved typing is
    // kept and same-field clashes are flagged. Skipped while a save is running.
    useEffect(() => {
        if (!customer?.id || isDemoCustomer) return;
        const AWAY_MS = 30000;
        let hiddenAt = document.visibilityState === 'hidden' ? Date.now() : null;
        let lastTick = Date.now();
        const catchUp = () => { if (!savingRef.current) refreshFullRecord(); };

        const onVisibility = () => {
            if (document.visibilityState === 'hidden') { hiddenAt = Date.now(); return; }
            if (hiddenAt !== null && Date.now() - hiddenAt >= AWAY_MS) catchUp();
            hiddenAt = null;
        };
        const onOnline = () => catchUp();
        const timer = setInterval(() => {
            const now = Date.now();
            if (now - lastTick > 4 * AWAY_MS) catchUp();   // timer paused = machine slept
            lastTick = now;
        }, AWAY_MS);

        document.addEventListener('visibilitychange', onVisibility);
        window.addEventListener('online', onOnline);
        return () => {
            clearInterval(timer);
            document.removeEventListener('visibilitychange', onVisibility);
            window.removeEventListener('online', onOnline);
        };
        // Reads current state through refs; one set of listeners per customer.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [customer?.id]);

    // Protect against accidental browser refresh or tab close when form has unsaved edits
    useEffect(() => {
        const handleBeforeUnload = (e) => {
            if (isFormDirty) {
                e.preventDefault();
                e.returnValue = '';
                return '';
            }
        };
        window.addEventListener('beforeunload', handleBeforeUnload);
        return () => window.removeEventListener('beforeunload', handleBeforeUnload);
    }, [isFormDirty]);
    const [followUpText, setFollowUpText] = useState('');
    const [saving, setSaving] = useState(false);
    useEffect(() => { savingRef.current = saving; }, [saving]);
    const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
    const [validationIssues, setValidationIssues] = useState([]);
    const [showValidationModal, setShowValidationModal] = useState(false);
    const [showCompletedConfirm, setShowCompletedConfirm] = useState(false);
    const [activityLogs, setActivityLogs] = useState([]);
    const [documents, setDocuments] = useState([]);
    const [croppingDoc, setCroppingDoc] = useState(null);
    const [docSearchQuery, setDocSearchQuery] = useState('');
    const [uploading, setUploading] = useState(false);
    const [filePreview, setFilePreview] = useState({ doc: null, url: null });
    const isAdmin = user?.userType === 'admin';
    const isCompleted = customer.stage === STAGE_IDS.COMPLETED;
    const [adminUnlocked, setAdminUnlocked] = useState(false);
    // Frozen for ALL users when completed. Admin can temporarily unlock.
    const isFrozen = isCompleted && !(isAdmin && adminUnlocked);
    const isAgent = user?.userType === 'agent';
    const isSales = user?.userType === 'sales';
    const isChannelPartnerOffice = user?.userType === 'channel_partner_office';
    const isChannelPartnerManager = user?.userType === 'office2';
    const isChannelPartnerOfficeOrManager = isChannelPartnerOffice || isChannelPartnerManager;
    const isOffice = (user?.userType === 'sales' || user?.role?.toLowerCase().includes('office')) && !isChannelPartnerOfficeOrManager;
    const canDeleteDocs = isAdmin || isOffice;
    // Cropping replaces the photo (upload new, remove old). The database lets
    // CPO and office2 remove documents of their own customers, so they can crop too.
    const canCropDocs = canDeleteDocs || isChannelPartnerOfficeOrManager;

    const isDiscomOrMeterStage = editData.stage === STAGE_IDS.DISCOM_SUBMISSION || editData.stage === STAGE_IDS.METER_INSTALLATION;

    const canUserEdit = (() => {
        if (isAdmin || isChannelPartnerOffice || isChannelPartnerManager || isOffice || isSales) return true;
        if (user?.role?.toLowerCase().includes('office') || user?.role?.toLowerCase().includes('admin') || user?.role?.toLowerCase().includes('sales')) return true;
        if (isAgent) {
            // Agent can edit if it's their client AND in DISCOM SUBMISSION or METER INSTALLATION stage
            const isMyClient = (customer.channel_partner || '').trim().toLowerCase() === (user.name || '').trim().toLowerCase();
            return isMyClient && isDiscomOrMeterStage;
        }
        // In main Dashboard, all staff members (except external vendor/stamp portals) can edit
        if (user?.userType !== 'vendor' && user?.userType !== 'stamp') return true;
        return false;
    })();

    // Channel Partner Office and Channel Partner Manager cannot edit Material Integration and Material Delivery (View only)
    const isStageRestrictedForUser = isChannelPartnerOfficeOrManager && (activeTab === STAGE_IDS.MATERIAL_INTEGRATION || activeTab === STAGE_IDS.MATERIAL_DELIVERY);

    const isEditable = !isFrozen && canUserEdit && !isStageRestrictedForUser;
    // Sales and Office can always add remarks and edit fields
    const canAddRemark = isEditable || !isFrozen;
    // CPO Manager can update only the SFDC Photo checklist in Installation
    // Status. All other installation status/details remain view-only.
    const isInstallationDetailsEditable = isEditable && !isChannelPartnerManager;

    // (The full record is loaded by refreshFullRecord above - the separate
    // background fetch that used to live here re-ran whenever the form's edited
    // state flipped, and could land after a newer save.)

    const saveBomRef = useRef(null);
    const [showAgreementPopup, setShowAgreementPopup] = useState(false);
    const [agreementAutoAdd, setAgreementAutoAdd] = useState(false);
    const [agreementData, setAgreementData] = useState({
        executionDate: '',
        consumerName: '',
        consumerNo: '',
        village: '',
        taluka: '',
        district: '',
        vendorName: 'Watersun Electrical Solutions Pvt Ltd',
        vendorAddress: 'Plot No 40 GIDC Estate Radhanpur',
        paymentTerms: 'Mutually Agreed Terms of Payment',
        firstPartySignature: '',
        secondPartyStamp: '',
        secondPartySignature: '',
        highlightColor: '#fef08a',
        showHighlights: true,
    });

    useEffect(() => {
        if (showAgreementPopup) {
            const rawDate = editData.stages_remarks?.discom_agreement_date || new Date().toISOString().split('T')[0];
            const formattedDate = formatDateToDDMMYYYY(rawDate);

            // Find signature and stamp documents
            const sigDoc = documents.find(d => 
                d.doc_type === 'signature_pic' || 
                d.doc_type === 'signature' || 
                d.doc_type === 'firstPartySignature' || 
                d.doc_type === 'customer_signature'
            );
            const stampDoc = documents.find(d => 
                d.doc_type === 'stamp' || 
                d.doc_type === 'stamp_pic' || 
                d.doc_type === 'vendor_stamp' || 
                d.doc_type === 'secondPartyStamp'
            );
            const gpaStampDoc = documents.find(d => 
                d.doc_type === 'pm_surya_ghar_stamp' || 
                d.doc_type === 'surya_ghar_stamp' || 
                d.doc_type === 'ghar_stamp'
            );

            const initialSigUrl = sigDoc ? (urlCacheRef.current[sigDoc.storage_path] || '') : '';
            const initialStampUrl = stampDoc ? (urlCacheRef.current[stampDoc.storage_path] || '') : '';
            const initialGpaStampUrl = gpaStampDoc ? (urlCacheRef.current[gpaStampDoc.storage_path] || '') : '';

            setAgreementData({
                executionDate: formattedDate,
                consumerName: editData.customer_name || '',
                consumerNo: editData.consumer_no || '',
                village: editData.villages || '',
                taluka: editData.sub_divisions || '',
                district: editData.district || '',
                vendorName: 'Watersun Electrical Solutions Pvt Ltd',
                vendorAddress: 'Plot No 40 GIDC Estate Radhanpur',
                paymentTerms: 'Mutually Agreed Terms of Payment',
                firstPartySignature: initialSigUrl,
                secondPartyStamp: initialStampUrl || './stamp.png',
                secondPartySignature: '',
                signatureUrl: initialSigUrl,
                stampUrl: initialStampUrl || './stamp.png',
                gpaStampUrl: initialGpaStampUrl,
                highlightColor: '#fef08a',
                showHighlights: true,
            });

            // If not yet in cache, fetch and update state
            if (sigDoc && !initialSigUrl) {
                getViewUrl(sigDoc.storage_path).then(url => {
                    if (url) {
                        urlCacheRef.current[sigDoc.storage_path] = url;
                        setAgreementData(prev => ({
                            ...prev,
                            firstPartySignature: url,
                            signatureUrl: url,
                        }));
                    }
                });
            }

            if (stampDoc && !initialStampUrl) {
                getViewUrl(stampDoc.storage_path).then(url => {
                    if (url) {
                        urlCacheRef.current[stampDoc.storage_path] = url;
                        setAgreementData(prev => ({
                            ...prev,
                            secondPartyStamp: url,
                            stampUrl: url,
                        }));
                    }
                });
            }

            if (gpaStampDoc && !initialGpaStampUrl) {
                getViewUrl(gpaStampDoc.storage_path).then(url => {
                    if (url) {
                        urlCacheRef.current[gpaStampDoc.storage_path] = url;
                        setAgreementData(prev => ({
                            ...prev,
                            gpaStampUrl: url,
                        }));
                    }
                });
            }
        }
    }, [showAgreementPopup, editData, documents]);

    const handleGenerateAgreement = async (addToDocuments = false) => {
        const requiredFields = [
            ['Consumer Name', editData.customer_name, 'Leads'],
            ['Consumer No', editData.consumer_no, 'Leads'],
            ['Village', editData.villages, 'Leads'],
            ['Taluka / Sub Division', editData.sub_divisions, 'Leads'],
            ['District', editData.district, 'Leads'],
            ['Agreement Execution Date', editData.stages_remarks?.discom_agreement_date || new Date().toISOString().split('T')[0], 'DISCOM Submission'],
        ];
        const missing = requiredFields.filter(([, value]) => !String(value || '').trim());
        if (missing.length) {
            showAlert(`Please fill these values first:\n\n${missing.map(([field, , tab]) => `• ${field} - ${tab} tab`).join('\n')}`, {
                title: 'Agreement is incomplete',
                type: 'warning'
            });
            return;
        }

        // Find signature, stamp and GPAE stamp documents
        const sigDoc = documents.find(d => 
            d.doc_type === 'signature_pic' || 
            d.doc_type === 'signature' || 
            d.doc_type === 'firstPartySignature' || 
            d.doc_type === 'customer_signature'
        );
        const stampDoc = documents.find(d => 
            d.doc_type === 'stamp' || 
            d.doc_type === 'stamp_pic' || 
            d.doc_type === 'vendor_stamp' || 
            d.doc_type === 'secondPartyStamp'
        );
        const gpaStampDoc = documents.find(d => 
            d.doc_type === 'pm_surya_ghar_stamp' || 
            d.doc_type === 'surya_ghar_stamp' || 
            d.doc_type === 'ghar_stamp'
        );

        let sigUrl = sigDoc ? (urlCacheRef.current[sigDoc.storage_path] || await getViewUrl(sigDoc.storage_path)) : '';
        let stampUrl = stampDoc ? (urlCacheRef.current[stampDoc.storage_path] || await getViewUrl(stampDoc.storage_path)) : '';
        let gpaStampUrl = gpaStampDoc ? (urlCacheRef.current[gpaStampDoc.storage_path] || await getViewUrl(gpaStampDoc.storage_path)) : '';

        if (sigDoc && sigUrl) urlCacheRef.current[sigDoc.storage_path] = sigUrl;
        if (stampDoc && stampUrl) urlCacheRef.current[stampDoc.storage_path] = stampUrl;
        if (gpaStampDoc && gpaStampUrl) urlCacheRef.current[gpaStampDoc.storage_path] = gpaStampUrl;

        const rawDate = editData.stages_remarks?.discom_agreement_date || new Date().toISOString().split('T')[0];
        const formattedDate = formatDateToDDMMYYYY(rawDate);

        setAgreementData({
            executionDate: formattedDate,
            consumerName: editData.customer_name || '',
            consumerNo: editData.consumer_no || '',
            village: editData.villages || '',
            taluka: editData.sub_divisions || '',
            district: editData.district || '',
            vendorName: 'Watersun Electrical Solutions Pvt Ltd',
            vendorAddress: 'Plot No 40 GIDC Estate Radhanpur',
            paymentTerms: 'Mutually Agreed Terms of Payment',
            firstPartySignature: sigUrl || '',
            secondPartyStamp: stampUrl || './stamp.png',
            secondPartySignature: '',
            signatureUrl: sigUrl || '',
            stampUrl: stampUrl || './stamp.png',
            gpaStampUrl: gpaStampUrl || '',
            highlightColor: '#fef08a',
            showHighlights: true,
        });

        setAgreementAutoAdd(addToDocuments);
        setShowAgreementPopup(true);
    };
    const ACTION_COLORS = {
        create: 'bg-emerald-100 text-emerald-700', update: 'bg-blue-100 text-blue-700',
        delete: 'bg-rose-100 text-rose-700', stage_change: 'bg-amber-100 text-amber-700',
        note: 'bg-indigo-100 text-indigo-700',
    };

    // History is paged: LOG_PAGE_SIZE at a time, with "Load more" in the
    // History tab. A refresh (fetchLogs) re-reads as many entries as are
    // already shown, so saving an edit doesn't collapse an expanded list.
    const LOG_PAGE_SIZE = 25;
    const logCountRef = useRef(LOG_PAGE_SIZE);
    const [logsHasMore, setLogsHasMore] = useState(false);
    const [logsLoadingMore, setLogsLoadingMore] = useState(false);
    const logsQuery = useCallback(() => supabase.from('activity_log').select('*, profiles(name)')
        // Match on the customer's id. The old name match also pulled in other
        // customers ("Ram" matched "Ramesh") and broke on names with commas.
        .or(`customer_id.eq.${customer.id},new_value.eq.${customer.id}`)
        .order('created_at', { ascending: false }), [customer.id]);

    const fetchLogs = useCallback(async () => {
        const count = Math.max(logCountRef.current, LOG_PAGE_SIZE);
        const { data } = await logsQuery().range(0, count - 1);
        if (data) {
            setActivityLogs(data);
            setLogsHasMore(data.length === count);
        }
    }, [logsQuery]);

    const loadMoreLogs = useCallback(async () => {
        setLogsLoadingMore(true);
        try {
            const from = logCountRef.current;
            const { data } = await logsQuery().range(from, from + LOG_PAGE_SIZE - 1);
            if (data) {
                logCountRef.current = from + LOG_PAGE_SIZE;
                setActivityLogs(prev => {
                    const seen = new Set(prev.map(l => l.id));
                    return [...prev, ...data.filter(l => !seen.has(l.id))];
                });
                setLogsHasMore(data.length === LOG_PAGE_SIZE);
            }
        } finally {
            setLogsLoadingMore(false);
        }
    }, [logsQuery]);

    useEffect(() => { logCountRef.current = LOG_PAGE_SIZE; }, [customer.id]);

    const urlCacheRef = useRef({});

    useEffect(() => {
        if (customer?.id) {
            getCustomerDocuments(customer.id).then(docs => {
                setDocuments(docs);
            });
        }
    }, [customer?.id]);

    const handleFileUpload = async (e, docType = null, replacingDocId = null, strictReplacement = false) => {
        const file = e.target.files[0];
        if (!file) return;

        setUploading(true);
        try {
            // Upload FIRST, delete the old one only once the new file exists.
            // Previously the old document was deleted before the upload - and
            // not even awaited - so a failed upload left the customer with no
            // document at all and nothing to recover.
            const newDoc = await uploadDocument(file, customer.id, docType, user?.id);

            if (newDoc) {
                const supersededDocs = replacingDocId
                    ? documents.filter(d => d.id === replacingDocId)
                    : (docType ? documents.filter(d => d.doc_type === docType && d.id !== newDoc.id) : []);
                for (const oldDoc of supersededDocs) {
                    try {
                        const removed = await deleteDocument(oldDoc.id, oldDoc.storage_path);
                        if (removed?.ok === false) throw removed.error || new Error('Could not replace the original document.');
                    } catch (delErr) {
                        if (strictReplacement) {
                            await deleteDocument(newDoc.id, newDoc.storage_path);
                            throw delErr;
                        }
                        // The new file is safely stored; a stale old row is a
                        // tidiness problem, not a data-loss one.
                        console.warn('New document saved, but removing the previous one failed:', delErr);
                    }
                }
            }
            if (newDoc) {
                setDocuments(prev => [
                    newDoc,
                    ...prev.filter(d => replacingDocId ? d.id !== replacingDocId : (docType ? d.doc_type !== docType : true))
                ]);
                // Pre-cache the new doc URL
                getViewUrl(newDoc.storage_path).then(url => {
                    if (url) urlCacheRef.current[newDoc.storage_path] = url;
                });
                // Automatically mark checklist field as true and persist.
                // Resolve the doc_type to its real column first - writing the
                // raw doc_type made Postgres reject the whole update whenever
                // the type was an alias or had no column.
                const flagColumn = docType ? DOC_TYPE_FLAG_COLUMN[docType] : null;
                // Cropping replaces an existing document and must not rewrite
                // the customer's checklist flag in public.admin.
                if (flagColumn && !strictReplacement) {
                    setEditData(prev => ({ ...prev, [flagColumn]: true }));
                    lastSelfWriteRef.current = Date.now();
                    invalidatePendingReloads();
                    // onUpdate RESOLVES false on failure, it does not reject, so
                    // the .catch() that used to be here could never fire - the
                    // checkbox was ticked on screen and the warning was dead
                    // code. Await the result and untick on refusal.
                    const flagBefore = await readAdminFields(customer.id, [flagColumn]);
                    const flagOk = await writeRecord(customer.id, { [flagColumn]: true });
                    if (flagOk !== false) {
                        // The automatic checklist tick used to be saved with no log entry.
                        void logFieldChanges(
                            user?.id,
                            customer.id,
                            customer.customer_name,
                            flagBefore || savedDataRef.current,
                            { [flagColumn]: true },
                            `Document upload (${DOC_TYPE_LABELS[docType] || docType})`
                        );
                    }
                    if (flagOk === false) {
                        setEditData(prev => ({ ...prev, [flagColumn]: false }));
                        showAlert(
                            `The document uploaded, but its checklist tick could not be saved. Please tick "${DOC_TYPE_LABELS[docType] || docType}" manually.`,
                            { title: 'Checklist not updated', type: 'warning' }
                        );
                    }
                }
                logActivity(
                    user.id,
                    'update',
                    `${customer.customer_name}: Uploaded document (${file.name})`,
                    '',
                    customer.id
                ).catch(console.error);
                fetchLogs();
            }
            return Boolean(newDoc);
        } catch (err) {
            console.error('Document upload failed:', err);
            showAlert('Document upload failed: ' + (err.message || 'Please check your connection and try again.'), { type: 'error' });
            return false;
        } finally {
            setUploading(false);
            if (e.target) e.target.value = '';
        }
    };

    const handleDownloadDoc = async (doc) => {
        const url = await getDownloadUrl(doc.storage_path, doc.file_name);
        if (url) {
            await downloadFileWithSaveAs(url, doc.file_name);
        }
    };

    const [downloadingAllDocuments, setDownloadingAllDocuments] = useState(false);
    const canDownloadAllDocuments = !['vendor', 'stamp'].includes(user?.userType);
    const handleDownloadAllDocuments = async () => {
        if (!canDownloadAllDocuments) return;
        if (downloadingAllDocuments) return;
        setDownloadingAllDocuments(true);
        try {
            const result = await downloadDocumentsAsPdf(documents, customer.customer_name);
            if (result.failed.length > 0) {
                showAlert(`${result.downloaded} document(s) were downloaded. ${result.failed.length} could not be included.`, { type: 'warning' });
            }
        } catch (error) {
            showAlert(error?.message || 'The documents could not be downloaded.', { title: 'Download Failed', type: 'error' });
        } finally {
            setDownloadingAllDocuments(false);
        }
    };

    const handlePreviewDoc = async (doc) => {
        // Use cached URL if available (instant), otherwise fetch
        let url = urlCacheRef.current[doc.storage_path];
        if (!url) {
            url = await getViewUrl(doc.storage_path);
            if (url) urlCacheRef.current[doc.storage_path] = url;
        }
        if (url) setFilePreview({ doc, url });
    };

    const handleDeleteDoc = async (doc) => {
        // Was fire-and-forget: not awaited, no result checked. A refused delete
        // removed the row from the list and wrote a "Deleted document" audit
        // entry while the file was still there on the next refresh.
        const res = await deleteDocument(doc.id, doc.storage_path);
        if (!res?.ok) {
            showAlert(res?.error?.message || 'The document could not be deleted. It has not been removed.', { type: 'error' });
            return;
        }
        setDocuments(prev => prev.filter(d => d.id !== doc.id));
        await logActivity(
            user.id,
            'update',
            `${customer.customer_name}: Deleted document (${doc.file_name})`,
            '',
            customer.id
        );
        fetchLogs();
        return true;
    };

    // Returns true/false so the remark rows in shared.jsx can show the real
    // outcome instead of an unconditional "Saved!".
    const handleUpdateDocRemark = async (docId, newRemark) => {
        const res = await updateDocumentRemark(docId, newRemark);
        if (!res?.ok) {
            showAlert(res?.error?.message || 'The remark was not saved.', { type: 'error' });
            return false;
        }
        setDocuments(prev => prev.map(d => d.id === docId ? { ...d, remark: newRemark } : d));
        const docObj = documents.find(d => d.id === docId);
        const fileName = docObj?.file_name || 'Document';
        await logActivity(
            user.id,
            'update',
            `${customer.customer_name}: Document remark update (${fileName}) - "${newRemark}"`,
            '',
            customer.id
        );
        fetchLogs();
        return true;
    };

    const REG_CHECKLIST_FIELDS = [
        'adhaar_card_front',
        'adhaar_card_back',
        'pan_card',
        'light_bill',
        'index_2',
        'bank_details',
        'house_geo_tag_photo',
        'extra_docs',
    ];

    const isRegChecklistDirty = REG_CHECKLIST_FIELDS.some(field => {
        return !!editData[field] !== !!customer[field];
    });

    const handleSaveRegChecklist = async () => {
        const patch = {};
        const changes = [];
        REG_CHECKLIST_FIELDS.forEach(field => {
            const oldCheck = !!customer[field];
            const newCheck = !!editData[field];
            if (oldCheck !== newCheck) {
                patch[field] = newCheck;
                changes.push(`${field}: ${oldCheck ? 'Checked' : 'Unchecked'} → ${newCheck ? 'Checked' : 'Unchecked'}`);
            }
        });

        // handleSectionUpdate returns false on failure. Ignoring it wrote an
        // audit entry for a checklist change the database never accepted.
        if (await handleSectionUpdate(customer.id, patch) === false) return;
        if (changes.length > 0) {
            await logActivity(user.id, 'update', `${customer.customer_name}: Registration checklist update - ${changes.join(' | ')}`, '', customer.id);
        }
        fetchLogs();
    };

    const OPERATIONAL_CHECKLIST_FIELDS = [
        'warranty_card',
        'insurance_status',
    ];

    const isOperationalChecklistDirty = OPERATIONAL_CHECKLIST_FIELDS.some(field => {
        return !!editData[field] !== !!customer[field];
    });

    const handleSaveOperationalChecklist = async () => {
        const patch = {};
        const changes = [];
        OPERATIONAL_CHECKLIST_FIELDS.forEach(field => {
            const oldCheck = !!customer[field];
            const newCheck = !!editData[field];
            if (oldCheck !== newCheck) {
                patch[field] = newCheck;
                changes.push(`${field}: ${oldCheck ? 'Checked' : 'Unchecked'} → ${newCheck ? 'Checked' : 'Unchecked'}`);
            }
        });

        if (await handleSectionUpdate(customer.id, patch) === false) return;
        if (changes.length > 0) {
            await logActivity(user.id, 'update', `${customer.customer_name}: Operational checklist update - ${changes.join(' | ')}`, '', customer.id);
        }
        fetchLogs();
    };

    // (A third sync effect used to merge the Dashboard's list row into the form
    // here. The list row can be partial or older than the database, so the
    // record now only ever comes from refreshFullRecord; the activity list
    // refresh that lived here moved into that effect.)






    const handleSaveStageRemark = async (stageId) => {
        const targetStage = stageId || editData.stage;
        const currentRemark = getStageRemarkFromData(editData.stages_remarks, targetStage);
        // The stored record, not the list copy the window was opened with: after
        // a stage move in this window the list copy still has the old stage and
        // remarks, and rebuilding from it overwrote the remark the move saved.
        const storedRemarks = savedDataRef.current?.stages_remarks ?? customer.stages_remarks;
        const originalRemark = getStageRemarkFromData(storedRemarks, targetStage);

        if (currentRemark !== originalRemark) {
            let prevObj = {};
            if (typeof storedRemarks === 'object' && storedRemarks) {
                prevObj = storedRemarks;
            } else if (typeof storedRemarks === 'string') {
                try {
                    const parsed = JSON.parse(storedRemarks);
                    if (typeof parsed === 'object' && parsed) prevObj = parsed;
                } catch { /* not valid JSON, fall through to default */ }
            }
            const updatedRemarks = {
                ...prevObj,
                [targetStage]: currentRemark
            };

            // Append the remark update to internal_remarks
            let updatedInternalRemarks = editData.internal_remarks || '';
            const formattedTime = formatDateTime(new Date());
            const appendText = `${targetStage} (${formattedTime}): ${currentRemark.trim() || 'Remark cleared'}`;
            updatedInternalRemarks = updatedInternalRemarks
                ? `${updatedInternalRemarks}\n${appendText}`
                : appendText;

            setEditData(prev => ({
                ...prev,
                stages_remarks: updatedRemarks,
                internal_remarks: updatedInternalRemarks
            }));

            if (await handleSectionUpdate(customer.id, {
                stages_remarks: updatedRemarks,
                internal_remarks: updatedInternalRemarks
            }) === false) return;

            await logActivity(
                user.id,
                'update',
                `${customer.customer_name}: Stage remark update for ${targetStage} - "${currentRemark}"`,
                '',
                customer.id
            );
            fetchLogs();
        }
    };

    const handleChange = (field, val) => {
        if (field === 'consumer_no') {
            val = String(val).replace(/[^0-9]/g, '');
        }
        if (field === 'driver_phone_number' || field === 'phone_number') {
            val = sanitizePhoneNumber(val);
        }
        setEditData(prev => {
            const next = { ...prev, [field]: val };
            setIsFormDirty(getChangedFields(next, savedDataRef.current).size > 0);
            return next;
        });
    };

    // Child tabs have their own Save buttons. Once one succeeds, merge only
    // that saved patch into the baseline and keep the popup active solely for
    // any other fields that are still genuinely unsaved.
    // Tells the user - and the activity log - that a save left fields out.
    // The typed values stay on screen (still marked unsaved) so nothing is lost.
    const reportUnsavedFields = (fields) => {
        const labels = fields.map(fieldLabel).join(', ');
        showAlert(
            `These changes did NOT save: ${labels}.\n\nThey are still on your screen. Press Save again. If it keeps failing, copy the values somewhere safe and tell the admin.`,
            { title: 'Not saved', type: 'error' }
        );
        if (user?.id) {
            void logActivity(user.id, 'update', `${customer.customer_name}: SAVE CHECK FAILED - not stored: ${labels}`, '', customer.id);
        }
    };

    const handleSectionUpdate = async (id, patch) => {
        lastSelfWriteRef.current = Date.now();
        invalidatePendingReloads();
        // Read the stored values of these fields before writing, so the log's
        // "before" side is the database, not the (possibly stale) local copy.
        const beforeRow = await readAdminFields(id, Object.keys(patch || {}));
        const result = await writeRecord(id, patch);
        if (result === false) return false;

        // Save check: re-read exactly these fields and confirm they were stored.
        const afterRow = await readAdminFields(id, Object.keys(patch || {}));
        if (!afterRow) {
            showAlert('The update was sent, but its saved values could not be verified. Keep this window open and refresh the customer before trying again.', { type: 'error' });
            return false;
        }
        const unsaved = findUnsavedFields(patch, afterRow);
        const storedPatch = { ...patch };
        unsaved.forEach(key => { delete storedPatch[key]; });

        // Every tab save now leaves a value-level record (field: old → new),
        // covering only what the database actually stored.
        void logFieldChanges(
            user?.id,
            id,
            customer?.customer_name,
            beforeRow || savedDataRef.current,
            storedPatch,
            `${activeTab} tab`
        );
        // Baseline = what the database holds, so an unsaved field stays "unsaved".
        const storedValuesOfUnsaved = {};
        unsaved.forEach(key => { storedValuesOfUnsaved[key] = afterRow[key]; });
        savedDataRef.current = { ...savedDataRef.current, ...storedPatch, ...storedValuesOfUnsaved };
        setEditData(previous => {
            const next = { ...previous, ...patch };
            setIsFormDirty(getChangedFields(next, savedDataRef.current).size > 0);
            return next;
        });
        if (unsaved.length > 0) {
            reportUnsavedFields(unsaved);
            return false;
        }
        return result;
    };

    const hasNextStage = (() => {
        const currentIdx = PRIMARY_STAGES.findIndex(s => s.id === editData.stage);
        if (currentIdx === -1) return false;
        if (editData.stage === STAGE_IDS.COMPLETED || editData.stage === STAGE_IDS.LOST_PROJECT) return false;

        let nextIdx = currentIdx + 1;
        if (nextIdx >= PRIMARY_STAGES.length) return false;

        let nextStage = PRIMARY_STAGES[nextIdx];
        if (nextStage.id === STAGE_IDS.LOAN && editData.payment_type?.trim().toLowerCase() === 'cash') {
            nextIdx++;
        }
        if (nextStage.id === STAGE_IDS.CASH && editData.payment_type?.trim().toLowerCase() === 'loan') {
            nextIdx++;
        }
        if (nextIdx < PRIMARY_STAGES.length && (PRIMARY_STAGES[nextIdx].id === STAGE_IDS.LOST_PROJECT)) {
            nextIdx++;
        }

        return nextIdx < PRIMARY_STAGES.length && PRIMARY_STAGES[nextIdx].id !== STAGE_IDS.LOST_PROJECT;
    })();

    const nextStageId = (() => {
        const currentIdx = PRIMARY_STAGES.findIndex(s => s.id === editData.stage);
        if (currentIdx === -1) return null;
        if (editData.stage === STAGE_IDS.COMPLETED || editData.stage === STAGE_IDS.LOST_PROJECT) return null;

        let nextIdx = currentIdx + 1;
        if (nextIdx >= PRIMARY_STAGES.length) return null;

        let nextStage = PRIMARY_STAGES[nextIdx];
        if (nextStage.id === STAGE_IDS.LOAN && editData.payment_type?.trim().toLowerCase() === 'cash') {
            nextIdx++;
        }
        if (nextStage.id === STAGE_IDS.CASH && editData.payment_type?.trim().toLowerCase() === 'loan') {
            nextIdx++;
        }
        if (nextIdx < PRIMARY_STAGES.length && (PRIMARY_STAGES[nextIdx].id === STAGE_IDS.LOST_PROJECT)) {
            nextIdx++;
        }

        if (nextIdx < PRIMARY_STAGES.length && PRIMARY_STAGES[nextIdx].id !== STAGE_IDS.LOST_PROJECT) {
            return PRIMARY_STAGES[nextIdx].id;
        }
        return null;
    })();

    const nextStageLabel = nextStageId ? PRIMARY_STAGES.find(s => s.id === nextStageId)?.label : '';

    const hasFeasibilityDoc = documents.some(d => d.doc_type === 'feasibilty_document' || d.doc_type === 'feasibility_document') || !!editData.feasibilty_document;
    const hasSubsidyTokenDoc = documents.some(d => d.doc_type === 'subsidy_token_photo') || !!editData.subsidy_token_photo;
    const hasApplicationAcknowledgment = documents.some(d => d.doc_type === 'application_acknowledgment') || !!editData.application_acknowledgment;
    const hasVendorFeasibility = documents.some(d => d.doc_type === 'vendor_feasibility') || !!editData.vendor_feasibility;
    const hasSiteFeasibility = documents.some(d => d.doc_type === 'site_feasibility') || !!editData.site_feasibility;
    const getMissingStageRequirements = () => {
        const issues = [];
        const requireField = (condition, label) => { if (!condition) issues.push(label); };

        switch (editData.stage) {
            case STAGE_IDS.LEADS:
                requireField(editData.customer_name?.trim(), 'Customer Name');
                requireField(editData.phone_number?.toString().trim(), 'Phone Number');
                requireField(editData.consumer_no?.toString().trim(), 'Consumer Number');
                requireField(editData.villages?.trim(), 'Village / Address');
                requireField(editData.channel_partner?.trim(), 'Channel Partner Name');
                requireField(editData.module_brand?.trim(), 'Module Brand');
                requireField(editData.module_wp?.toString().trim(), 'Module WP');
                requireField(editData.no_of_modules?.toString().trim(), 'Number of Modules');
                requireField(editData.system_capacity_kwp, 'System Capacity');
                requireField(editData.sub_divisions?.trim(), 'Tehsil / Sub Division');
                requireField(editData.district?.trim(), 'District');
                requireField(editData.payment_type?.trim(), 'Payment Type');
                break;
            case STAGE_IDS.REGISTRATION:
                requireField(editData.registration_date, 'Registration Date');
                requireField(editData.registration_by?.trim(), 'Registration By');
                requireField(editData.registration_no?.toString().trim() || editData.feasibility_no?.toString().trim(), 'Feasibility No');
                requireField(hasFeasibilityDoc, 'Feasibility Document');
                requireField(hasSubsidyTokenDoc, 'Subsidy Token Photo');
                requireField(hasApplicationAcknowledgment, 'Application Acknowledgment');
                break;
            case STAGE_IDS.LOAN:
                requireField(editData.jansamarth_application_no?.toString().trim(), 'Jansamarth Application No');
                requireField(hasVendorFeasibility, 'Vendor Feasibility');
                requireField(hasSiteFeasibility, 'Site Feasibility');
                break;
            case STAGE_IDS.MATERIAL_ORDER:
                requireField(editData.roof_shed, 'Roof / Shed');
                requireField(editData.dc_cable && Number(parseIndianNumber(editData.dc_cable)) > 0, 'DC Cable Length');
                requireField(editData.ac_cable && Number(parseIndianNumber(editData.ac_cable)) > 0, 'AC Cable Length');
                requireField(String(editData.structure_front_leg_height || '').trim(), 'Structure Front Leg Height');
                requireField(String(editData.structure_rear_leg_height || '').trim(), 'Structure Rear Leg Height');
                requireField(editData.invoice_value && Number(parseIndianNumber(editData.invoice_value)) > 0, 'Invoice Value');
                break;
            case STAGE_IDS.MATERIAL_INTEGRATION:
                requireField(editData.inverter_make?.trim(), 'Inverter Make');
                requireField(editData.inverter_serial_no?.trim(), 'Inverter Serial Number');
                requireField(
                    Array.isArray(editData.panel_serial_no)
                        ? editData.panel_serial_no.some(Boolean)
                        : String(editData.panel_serial_no || '').trim(),
                    'At Least One Panel Serial Number'
                );
                break;
            case STAGE_IDS.MATERIAL_DELIVERY:
                requireField(editData.vendor?.trim(), 'Vendor Allotment');
                requireField(editData.invoice_no?.trim(), 'Invoice Number');
                requireField(editData.material_delivery_date, 'Delivery Date');
                requireField(editData.driver_name?.trim(), 'Driver Name');
                requireField(editData.driver_phone_number?.toString().trim(), 'Driver Phone Number');
                break;
            case STAGE_IDS.INSTALLATION_STATUS:
                // Exact match blocked records the vendor had set to the legacy
                // value 'Yes' - the admin could not advance them at all.
                requireField(normalizeInstallationStatus(editData.installation_status) === 'Yes', 'Installation Status must be Installed');
                break;
            case STAGE_IDS.GEO_TAG_PHOTO:
                requireField(editData.geo_tag_status === 'Proceed', 'Geo Tag Photo Status must be Proceed');
                requireField(editData.geo_tag_image, 'Geo Tag Photograph');
                break;
            case STAGE_IDS.METER_INSTALLATION:
                requireField(normalizeMeterInstallation(editData.meter_installation) === 'Yes', 'Meter Installation Status must be Yes');
                requireField(editData.installation_date, 'Meter Installation Date');
                break;
            case STAGE_IDS.DISCOM_INSPECTION:
                requireField(editData.discom_inspection === 'Yes', 'Discom Inspection Status must be Yes');
                break;
            default:
                break;
        }

        return issues;
    };

    const showMissingRequirements = (issues) => {
        setValidationIssues(issues);
        setShowValidationModal(true);
    };

    const handleAdvanceStage = async (overrideNextStageId) => {
        const destStageId = overrideNextStageId || nextStageId;
        if (!destStageId) return;

        const missingRequirements = getMissingStageRequirements();
        if (missingRequirements.length > 0) {
            showMissingRequirements(missingRequirements);
            return;
        }

        setSaving(true);
        if (saveBomRef.current) {
            try {
                const wasSaved = await saveBomRef.current();
                if (wasSaved === false) {
                    setSaving(false);
                    showAlert('Failed to save the Material Integration BOM, so the stage was not advanced. Please try again.', { type: 'error' });
                    return;
                }
            } catch (err) {
                console.error('Error saving BOM during stage advance:', err);
                setSaving(false);
                showAlert('Failed to save the Material Integration BOM, so the stage was not advanced: ' + (err.message || 'Unknown error') + (err.code ? ` (code ${err.code})` : ''), { type: 'error' });
                return;
            }
        }

        if (editData.stage === STAGE_IDS.MATERIAL_INTEGRATION) {
            const { data: bomData, error: bomError } = await supabase
                .from('bom')
                .select('paper_prepared_by, paper_prepared_date, material_loaded_by, material_loaded_date')
                .eq('admin_id', customer.id)
                .order('created_at', { ascending: true })
                .limit(1)
                .maybeSingle();
            if (bomError) {
                showAlert('The BOM milestones could not be checked: ' + bomError.message, { type: 'error' });
                setSaving(false);
                return;
            }

            if (!bomData || !bomData.paper_prepared_by || !bomData.paper_prepared_date || !bomData.material_loaded_by || !bomData.material_loaded_date) {
                const missingMilestones = [];
                if (!bomData?.paper_prepared_by) missingMilestones.push('Paper Prepared By');
                if (!bomData?.paper_prepared_date) missingMilestones.push('Paper Prepared Date');
                if (!bomData?.material_loaded_by) missingMilestones.push('Material Loaded By');
                if (!bomData?.material_loaded_date) missingMilestones.push('Material Loaded Date');
                showMissingRequirements(missingMilestones);
                setSaving(false);
                return;
            }
        }

        const oldStage = editData.stage;
        let prevObj = {};
        if (typeof editData.stages_remarks === 'object' && editData.stages_remarks) {
            prevObj = editData.stages_remarks;
        } else if (typeof editData.stages_remarks === 'string') {
            try {
                const parsed = JSON.parse(editData.stages_remarks);
                if (typeof parsed === 'object' && parsed) prevObj = parsed;
            } catch { /* not valid JSON, fall through to default */ }
        }
        const updatedRemarks = {
            ...prevObj,
            [oldStage]: ''
        };

        const updates = {
            ...editData,
            stage: destStageId,
            stages_remarks: updatedRemarks
        };

        if (updates.system_capacity_kwp !== undefined && updates.system_capacity_kwp !== null && updates.system_capacity_kwp !== '') {
            updates.system_capacity_kwp = String(parseIndianNumber(updates.system_capacity_kwp));
        }
        if (updates.module_wp !== undefined && updates.module_wp !== null && updates.module_wp !== '') {
            updates.module_wp = String(parseIndianNumber(updates.module_wp));
        }
        if (updates.no_of_modules !== undefined && updates.no_of_modules !== null && updates.no_of_modules !== '') {
            updates.no_of_modules = String(parseIndianNumber(updates.no_of_modules));
        }
        if (updates.invoice_value !== undefined && updates.invoice_value !== null && updates.invoice_value !== '') {
            updates.invoice_value = String(parseIndianNumber(updates.invoice_value));
        }
        if (updates.dc_cable !== undefined && updates.dc_cable !== null && updates.dc_cable !== '') {
            updates.dc_cable = String(parseIndianNumber(updates.dc_cable));
        }
        if (updates.ac_cable !== undefined && updates.ac_cable !== null && updates.ac_cable !== '') {
            updates.ac_cable = String(parseIndianNumber(updates.ac_cable));
        }

        if (destStageId === STAGE_IDS.LOST_PROJECT) {
            const prevHold = (typeof updates.hold_procurement === 'object' && updates.hold_procurement) ? updates.hold_procurement : {};
            updates.hold_procurement = {
                ...prevHold,
                previous_stage: (oldStage !== STAGE_IDS.LOST_PROJECT) ? oldStage : (prevHold.previous_stage || STAGE_IDS.LEADS),
                hold_date: new Date().toISOString().split('T')[0]
            };
        }

        if (destStageId === STAGE_IDS.METER_INSTALLATION) {
            // Seed the STRING the tab and the validator both read. This used to
            // write { status, no_date, yes_date }; no code ever read no_date or
            // yes_date, and the object broke every reader.
            updates.meter_installation = normalizeMeterInstallation(updates.meter_installation) || 'No';
        }

        if (destStageId === STAGE_IDS.DISCOM_INSPECTION) {
            if (!updates.discom_inspection) {
                updates.discom_inspection = 'No';
            }
        }

        if (updates.subsidy_history) {
            updates.subsidy_history = updates.subsidy_history.map(({ isNew, ...rest }) => rest);
        }
        if (updates.loan_history) {
            updates.loan_history = updates.loan_history.map(({ isNew, ...rest }) => rest);
        }

        delete updates.id;
        delete updates.created_at;
        delete updates.crn;
        delete updates.updated_at;

        // Send only what actually changed, plus the stage and its remarks.
        // This used to spread the whole record (~89 columns), so advancing a
        // stage wrote every stale field over whatever a colleague had just
        // saved.
        const changedKeys = getChangedFields(updates, savedDataRef.current);
        const narrowed = {};
        changedKeys.forEach(key => { narrowed[key] = updates[key]; });
        narrowed.stage = destStageId;
        narrowed.stages_remarks = updatedRemarks;

        const originalStage = editData.stage;
        const originalRemarks = editData.stages_remarks;
        setEditingSection(null);
        setEditData(updates);

        // onUpdate RESOLVES with false on failure - it does not reject - so the
        // old .catch() could never fire and the modal moved the customer into
        // the new stage even when the write had failed. Await the result and
        // only advance the UI once the database has accepted it.
        lastSelfWriteRef.current = Date.now();
        invalidatePendingReloads();
        const fieldKeys = Object.keys(narrowed).filter(key => key !== 'stage' && key !== 'stages_remarks');
        let storedFields = {};
        let beforeRow = null;
        try {
            beforeRow = await readAdminFields(customer.id, Object.keys(narrowed));

            // Step 1 - save the details first and confirm the database holds
            // them. The stage only moves once they are stored, so a customer can
            // never move ahead of its details (the Gulabnabi case: the screen
            // showed the inverter, the database did not, the stage moved anyway).
            if (fieldKeys.length > 0) {
                const fieldsPart = {};
                fieldKeys.forEach(key => { fieldsPart[key] = narrowed[key]; });
                const fieldsOk = await writeRecord(customer.id, fieldsPart);
                if (fieldsOk === false) throw Object.assign(new Error('The database did not accept the changes.'), { alreadyReported: true });
                const afterFields = await readAdminFields(customer.id, fieldKeys);
                if (!afterFields) throw new Error('The details were sent, but their saved values could not be verified. Refresh this customer before moving the stage.');
                const unsavedFields = findUnsavedFields(fieldsPart, afterFields);
                storedFields = { ...fieldsPart };
                unsavedFields.forEach(key => { delete storedFields[key]; });
                const storedValuesOfUnsaved = {};
                unsavedFields.forEach(key => { storedValuesOfUnsaved[key] = afterFields[key]; });
                savedDataRef.current = { ...savedDataRef.current, ...storedFields, ...storedValuesOfUnsaved };
                if (unsavedFields.length > 0) {
                    const labels = unsavedFields.map(fieldLabel).join(', ');
                    if (user?.id) {
                        void logActivity(user.id, 'update', `${customer.customer_name}: SAVE CHECK FAILED - not stored: ${labels}`, '', customer.id);
                    }
                    throw new Error(`These details did not save: ${labels}. They are still on your screen - press Save, then move the stage again.`);
                }
            }

            // Step 2 - move the stage, and confirm it moved.
            const stagePart = { stage: destStageId, stages_remarks: updatedRemarks };
            const ok = await writeRecord(customer.id, stagePart);
            if (ok === false) throw Object.assign(new Error('The database did not accept the stage change.'), { alreadyReported: true });
            const afterStage = await readAdminFields(customer.id, ['stage']);
            if (!afterStage) throw new Error('The stage change was sent, but its saved value could not be verified. Refresh this customer before trying again.');
            if (findUnsavedFields({ stage: destStageId }, afterStage).length > 0) {
                throw new Error('The database did not store the new stage.');
            }

            savedDataRef.current = { ...savedDataRef.current, ...stagePart };
            setEditData(previous => {
                setIsFormDirty(getChangedFields(previous, savedDataRef.current).size > 0);
                return previous;
            });
            setActiveTab(destStageId);

            void logActivity(
                user.id,
                'stage_change',
                `${customer.customer_name}: Stage changed`,
                `Stage: ${oldStage || 'Empty'} → ${destStageId || 'Empty'}`,
                customer.id
            );
            void fetchLogs();
        } catch (err) {
            console.error('Stage advance failed:', err);
            // The form was switched to the new stage before writing. Put it back,
            // or a later Save would send the stage change on its own.
            setEditData(previous => {
                const next = { ...previous, stage: originalStage, stages_remarks: originalRemarks };
                setIsFormDirty(getChangedFields(next, savedDataRef.current).size > 0);
                return next;
            });
            if (!err.alreadyReported) {
                showAlert(`The stage was NOT changed.\n\n${err.message || 'Unknown error'}`, { type: 'error' });
            }
        }
        // Log the details the database actually stored in step 1 (even when the
        // stage move itself then failed), with stored "before" values.
        if (Object.keys(storedFields).length > 0) {
            void logFieldChanges(
                user?.id,
                customer.id,
                customer.customer_name,
                beforeRow || savedDataRef.current,
                storedFields,
                `${oldStage} - Move to next stage`
            );
        }
        setSaving(false);
    };


    // ─── Move to Lost Project ────────────────────────────────────────────────
    // This button used to be `onClick={() => setActiveTab(STAGE_IDS.LOST_PROJECT)}`
    // - it switched the visible tab and never wrote anything. The user filled in
    // the panel, pressed Save, and got a green confirmation while `stage` was
    // untouched, so the record never moved. No customer has ever reached Lost
    // Project through the UI.
    //
    // It also has to record WHERE the project was lost from. Without
    // hold_procurement.previous_stage, HoldProcurementTab falls back to 'LEADS'
    // (see its getHoldState), so Resume would dump a project lost at Subsidy
    // Status all the way back to Leads.
    const handleMoveToLostProject = async () => {
        const originStage = savedDataRef.current?.stage || customer?.stage;
        if (!originStage) return;

        const originLabel = PRIMARY_STAGES.find(st => st.id === originStage)?.label || originStage;
        const confirmed = await showConfirm(
            `Move ${customer.customer_name || 'this customer'} to Lost Project?\n\n`
            + `Their current stage (${originLabel}) is recorded, so they can be resumed back to it later.`,
            { title: 'Move to Lost Project', confirmLabel: 'Move to Lost Project', cancelLabel: 'Cancel', type: 'warning' }
        );
        if (!confirmed) return;

        // Preserve anything already stored (a previous hold's notes) rather
        // than overwriting the column wholesale.
        let existing = {};
        const raw = editData.hold_procurement ?? customer.hold_procurement;
        if (raw) {
            try {
                existing = typeof raw === 'string' ? (JSON.parse(raw) || {}) : (raw || {});
            } catch { existing = {}; }
        }

        const payload = {
            ...existing,
            previous_stage: originStage,
            hold_date: new Date().toISOString().split('T')[0],
        };

        lastSelfWriteRef.current = Date.now();
        invalidatePendingReloads();
        const ok = await writeRecord(customer.id, {
            stage: STAGE_IDS.LOST_PROJECT,
            hold_procurement: payload,
        });
        // onUpdate resolves false on failure and has already shown the error.
        if (ok === false) return;

        setEditData(prev => ({ ...prev, stage: STAGE_IDS.LOST_PROJECT, hold_procurement: payload }));

        // Re-base the conflict baseline, exactly as handleSave and
        // handleAdvanceStage do. Without this the NEXT save in the same modal
        // session sees the row as changed-on-the-server - by this very write -
        // and raises an "Edit Conflict Detected" dialog against the user
        // themselves. Postgres re-orders jsonb keys on storage, so
        // hold_procurement compares unequal and lands in the conflict list.
        savedDataRef.current = {
            ...savedDataRef.current,
            stage: STAGE_IDS.LOST_PROJECT,
            hold_procurement: payload,
        };
        loadedUpdatedAtRef.current = new Date().toISOString();

        setActiveTab(STAGE_IDS.LOST_PROJECT);

        await logActivity(
            user.id,
            'stage_change',
            `${customer.customer_name}: Stage changed`,
            `Stage: ${originStage || 'Empty'} → ${STAGE_IDS.LOST_PROJECT}`,
            customer.id
        );
        fetchLogs();
    };

    const handleSave = async (forceOverwrite = false) => {
        setSaving(true);
        if (saveBomRef.current) {
            try {
                const bomSaved = await saveBomRef.current();
                if (bomSaved === false) throw new Error('The BOM could not be saved.');
            } catch (err) {
                console.error('Error saving BOM during handleSave:', err);
                showAlert(`Your BOM was not saved. Please try again.\n\n${err.message || ''}${err.code ? ` (code ${err.code})` : ''}`, { type: 'error' });
                setSaving(false);
                return false;
            }
        }
        const updates = { ...editData };

        if (updates.system_capacity_kwp !== undefined && updates.system_capacity_kwp !== null && updates.system_capacity_kwp !== '') {
            updates.system_capacity_kwp = String(parseIndianNumber(updates.system_capacity_kwp));
        }
        if (updates.module_wp !== undefined && updates.module_wp !== null && updates.module_wp !== '') {
            updates.module_wp = String(parseIndianNumber(updates.module_wp));
        }
        if (updates.no_of_modules !== undefined && updates.no_of_modules !== null && updates.no_of_modules !== '') {
            updates.no_of_modules = String(parseIndianNumber(updates.no_of_modules));
        }
        if (updates.invoice_value !== undefined && updates.invoice_value !== null && updates.invoice_value !== '') {
            updates.invoice_value = String(parseIndianNumber(updates.invoice_value));
        }
        if (updates.dc_cable !== undefined && updates.dc_cable !== null && updates.dc_cable !== '') {
            updates.dc_cable = String(parseIndianNumber(updates.dc_cable));
        }
        if (updates.ac_cable !== undefined && updates.ac_cable !== null && updates.ac_cable !== '') {
            updates.ac_cable = String(parseIndianNumber(updates.ac_cable));
        }
        if (updates.vendor_quote !== undefined && updates.vendor_quote !== null && updates.vendor_quote !== '') {
            updates.vendor_quote = String(parseIndianNumber(updates.vendor_quote));
        } else if (updates.vendor_quote === '') {
            updates.vendor_quote = null;
        }

        // A colleague changed a field that I have also changed and not saved
        // (spotted when their save was merged in). Ask before overwriting it.
        if (!forceOverwrite && pendingConflictsRef.current.size > 0) {
            const myChanges = getChangedFields(updates, savedDataRef.current);
            const clashes = [...pendingConflictsRef.current].filter(key => myChanges.has(key));
            if (clashes.length > 0) {
                setSaving(false);
                setConcurrentConflict({
                    serverData: { ...savedDataRef.current },
                    localUpdates: updates,
                    localChanges: clashes,
                    remoteChanges: clashes,
                    overlappingFields: clashes,
                    serverUpdatedAt: loadedUpdatedAtRef.current
                });
                return false;
            }
        }

        // Concurrency Conflict Check before writing to database
        if (!forceOverwrite && customer?.id && !String(customer.id).startsWith('demo-') && loadedUpdatedAtRef.current) {
            try {
                const { data: serverRecord, error: checkErr } = await supabase
                    .from('admin')
                    .select('*')
                    .eq('id', customer.id)
                    .single();

                if (!checkErr && serverRecord && serverRecord.updated_at) {
                    const serverTime = new Date(serverRecord.updated_at).getTime();
                    const localTime = new Date(loadedUpdatedAtRef.current).getTime();

                    // If server record was updated since we loaded it (> 1000ms threshold)
                    if (serverTime > localTime + 1000) {
                        const localChangedSet = getChangedFields(updates, savedDataRef.current);
                        const remoteChangedSet = getChangedFields(serverRecord, savedDataRef.current);

                        const localChanges = Array.from(localChangedSet);

                        const overlappingFields = localChanges.filter(
                            k => remoteChangedSet.has(k) && JSON.stringify(serverRecord[k]) !== JSON.stringify(updates[k])
                        );

                        // A conflict only exists when we and the server changed the
                        // SAME field to DIFFERENT values - that is `overlappingFields`,
                        // which was already computed above and then ignored.
                        //
                        // The old test (both sides differ from the baseline) fired
                        // whenever the baseline was stale, because BOTH sides then
                        // differ from it even when they are identical to each other.
                        // That is why the dialog listed fields whose two values were
                        // the same: STAGE "REGISTRATION" vs "REGISTRATION".
                        if (overlappingFields.length > 0) {
                            setSaving(false);
                            setConcurrentConflict({
                                serverData: serverRecord,
                                localUpdates: updates,
                                localChanges: overlappingFields,
                                remoteChanges: overlappingFields,
                                overlappingFields,
                                serverUpdatedAt: serverRecord.updated_at
                            });
                            return false;
                        }
                    }
                }
            } catch (concurrencyErr) {
                console.warn('Concurrency check warning:', concurrencyErr);
            }
        }

        let changeSummary = [];
        Object.keys(updates).forEach(key => {
            if (updates[key] !== savedDataRef.current?.[key] && key !== 'id' && key !== 'updated_at' && typeof updates[key] !== 'object') {
                changeSummary.push(`${key.replace(/_/g, ' ').toUpperCase()}: ${savedDataRef.current?.[key] || 'None'} → ${updates[key] || 'None'}`);
            }
        });

        if (updates.subsidy_history) {
            updates.subsidy_history = updates.subsidy_history.map(({ isNew, ...rest }) => rest);
        }
        if (updates.loan_history) {
            updates.loan_history = updates.loan_history.map(({ isNew, ...rest }) => rest);
        }

        // Compare subsidy_history
        // Compare with the stored record (savedDataRef), not the slim list copy:
        // the list row has no history, so every existing entry was logged as
        // "Added Entry N" on each save.
        const oldSubsidy = savedDataRef.current?.subsidy_history || [];
        const newSubsidy = updates.subsidy_history || [];
        if (JSON.stringify(oldSubsidy) !== JSON.stringify(newSubsidy)) {
            const subChanges = [];
            if (newSubsidy.length === 0 && oldSubsidy.length > 0) {
                subChanges.push("Cleared all subsidy entries");
            } else {
                const maxLen = Math.max(oldSubsidy.length, newSubsidy.length);
                for (let i = 0; i < maxLen; i++) {
                    const oldItem = oldSubsidy[i];
                    const newItem = newSubsidy[i];
                    if (!oldItem && newItem) {
                        subChanges.push(`Added Entry ${i + 1} (${newItem.status}${newItem.date ? ` on ${newItem.date}` : ''}${newItem.remark ? `: ${newItem.remark}` : ''})`);
                    } else if (oldItem && !newItem) {
                        subChanges.push(`Removed Entry ${i + 1} (${oldItem.status})`);
                    } else if (JSON.stringify(oldItem) !== JSON.stringify(newItem)) {
                        const diffs = [];
                        if (oldItem.status !== newItem.status) {
                            diffs.push(`status: "${oldItem.status}" → "${newItem.status}"`);
                        }
                        if (oldItem.date !== newItem.date) {
                            diffs.push(`date: "${oldItem.date || 'None'}" → "${newItem.date || 'None'}"`);
                        }
                        if (oldItem.remark !== newItem.remark) {
                            diffs.push(`remark: "${oldItem.remark || 'None'}" → "${newItem.remark || 'None'}"`);
                        }
                        if (diffs.length > 0) {
                            subChanges.push(`Updated Entry ${i + 1} (${diffs.join(', ')})`);
                        }
                    }
                }
            }
            if (subChanges.length > 0) {
                changeSummary.push(`SUBSIDY STATUS: ${subChanges.join(' | ')}`);
            }
        }

        // Compare loan_history
        const oldLoan = savedDataRef.current?.loan_history || [];
        const newLoan = updates.loan_history || [];
        if (JSON.stringify(oldLoan) !== JSON.stringify(newLoan)) {
            const loanChanges = [];
            if (newLoan.length === 0 && oldLoan.length > 0) {
                loanChanges.push("Cleared all loan entries");
            } else {
                const maxLen = Math.max(oldLoan.length, newLoan.length);
                for (let i = 0; i < maxLen; i++) {
                    const oldItem = oldLoan[i];
                    const newItem = newLoan[i];
                    if (!oldItem && newItem) {
                        loanChanges.push(`Added Entry ${i + 1} (${newItem.status}${newItem.date ? ` on ${newItem.date}` : ''}${newItem.remark ? `: ${newItem.remark}` : ''})`);
                    } else if (oldItem && !newItem) {
                        loanChanges.push(`Removed Entry ${i + 1} (${oldItem.status})`);
                    } else if (JSON.stringify(oldItem) !== JSON.stringify(newItem)) {
                        const diffs = [];
                        if (oldItem.status !== newItem.status) {
                            diffs.push(`status: "${oldItem.status}" → "${newItem.status}"`);
                        }
                        if (oldItem.date !== newItem.date) {
                            diffs.push(`date: "${oldItem.date || 'None'}" → "${newItem.date || 'None'}"`);
                        }
                        if (oldItem.remark !== newItem.remark) {
                            diffs.push(`remark: "${oldItem.remark || 'None'}" → "${newItem.remark || 'None'}"`);
                        }
                        if (diffs.length > 0) {
                            loanChanges.push(`Updated Entry ${i + 1} (${diffs.join(', ')})`);
                        }
                    }
                }
            }
            if (loanChanges.length > 0) {
                changeSummary.push(`LOAN STATUS: ${loanChanges.join(' | ')}`);
            }
        }

        // We do not run safeParse here because regular save should allow partial/invalid data to be saved as drafts.
        // Validation only happens strictly when advancing stages.

        // Compare with the stored stage, not the Dashboard's list copy.
        const previousStage = savedDataRef.current?.stage ?? customer.stage;
        const stageChanged = editData.stage !== previousStage;
        delete updates.id; delete updates.created_at; delete updates.crn; delete updates.updated_at;

        // An admin changing the stage with the regular Save button skips the
        // required-detail checks too. Show what is missing and record the skip.
        let overrideSkipped = [];
        if (stageChanged) {
            overrideSkipped = missingDetailsForMove(previousStage, updates.stage, { ...savedDataRef.current, ...updates });
            if (overrideSkipped.length > 0) {
                const list = `• ${overrideSkipped.join('\n• ')}`;
                if (!isAdmin) {
                    showAlert(`This customer cannot move to ${updates.stage} yet. Missing:\n\n${list}`, { title: 'Details missing', type: 'warning' });
                    setSaving(false);
                    return false;
                }
                const proceed = await showConfirm(
                    `This customer is missing details for the stages being skipped:\n\n${list}\n\nMove to ${updates.stage} anyway? The skip and the missing details will be recorded in the activity log.`,
                    { title: 'Move ahead with details missing?', confirmLabel: 'Move anyway', cancelLabel: 'Cancel', type: 'warning' }
                );
                if (!proceed) {
                    setSaving(false);
                    return false;
                }
            }
        }
        
        try {
            // Send only the fields this editor actually changed. Sending the whole
            // record meant two people on one customer silently overwrote each
            // other: the realtime sync stops as soon as your form is dirty, so
            // your copy goes stale, and saving wrote every stale field back over
            // a colleague's change. Narrowing the payload means edits to
            // different fields no longer collide.
            const changedKeys = getChangedFields(updates, savedDataRef.current);
            const narrowedUpdates = {};
            changedKeys.forEach(key => { narrowedUpdates[key] = updates[key]; });
            // `stage` is set by the advance flow rather than by editing a field,
            // so carry it whenever it differs from what we loaded.
            if (updates.stage !== undefined && updates.stage !== savedDataRef.current?.stage) {
                narrowedUpdates.stage = updates.stage;
            }

            // Nothing actually changed - there is nothing to send. Writing an
            // empty object makes PostgREST reject the request, which surfaced as
            // "The database did not accept the changes" on a save where the user
            // had changed nothing (or only fields that are not real columns).
            if (Object.keys(narrowedUpdates).length === 0) {
                setEditingSection(null);
                setIsFormDirty(false);
                setSaving(false);
                return true;
            }

            lastSelfWriteRef.current = Date.now();
            invalidatePendingReloads();
            // The log used to be written at the same moment as the save, even
            // when the save failed or left fields out, and its "before" values
            // came from the slim list card (hence "None → ..." everywhere).
            // Now: read the stored values first, save, and log only after the
            // database confirms - and only the fields that were actually sent.
            const beforeRow = await readAdminFields(customer.id, Object.keys(narrowedUpdates));
            const updateResult = await writeRecord(customer.id, narrowedUpdates);
            // Dashboard already displayed the database's actual error. A second
            // generic alert here replaced it, leaving only "not saved" visible.
            if (updateResult === false) return false;
            // Re-read what the server actually stored, and use ITS updated_at as
            // the new baseline. Two separate bugs made the conflict dialog fire
            // on a single editor's own second save:
            //
            //  1. The baseline was the CLIENT clock (new Date()), while the DB
            //     trigger sets updated_at from server now(). Any clock skew over
            //     1s made the next save look like somebody else's edit.
            //  2. savedDataRef was patched with what we SENT, but handleUpdateCustomer
            //     coerces numeric strings ('5' -> 5), so the stored row genuinely
            //     differed from our baseline and every numeric field showed up as a
            //     "remote change".
            const { data: savedRow, error: savedRowError } = await supabase
                .from('admin')
                .select('*')
                .eq('id', customer.id)
                .maybeSingle();
            if (savedRowError || !savedRow) {
                throw new Error('The update was sent, but its saved values could not be verified. Keep this window open and refresh the customer before trying again.');
            }

            // Save check: anything we sent that the database does not hold is
            // reported now, and stays on screen as unsaved, instead of looking
            // saved and vanishing later (the lost inverter / panel values).
            const unsaved = findUnsavedFields(narrowedUpdates, savedRow);
            const storedUpdates = { ...narrowedUpdates };
            unsaved.forEach(key => { delete storedUpdates[key]; });
            if (unsaved.length === 0) {
                const historyLines = changeSummary.filter(line => line.startsWith('SUBSIDY STATUS:') || line.startsWith('LOAN STATUS:'));
                if (historyLines.length > 0) {
                    void logActivity(user.id, 'update', `${customer.customer_name}: ${historyLines.join(' | ')}`, '', customer.id);
                }
            }
            if (stageChanged && !unsaved.includes('stage')) {
                void logActivity(
                    user.id,
                    'stage_change',
                    `${customer.customer_name}: Stage changed by admin override`,
                    `Stage: ${previousStage || 'Empty'} → ${editData.stage || 'Empty'}`,
                    customer.id
                );
                if (overrideSkipped.length > 0) {
                    void logActivity(
                        user.id,
                        'update',
                        `${customer.customer_name}: STAGE SKIP by admin - moved ${previousStage} → ${editData.stage} with details missing: ${overrideSkipped.join(', ')}`,
                        '',
                        customer.id
                    );
                }
            }
            void logFieldChanges(
                user?.id,
                customer.id,
                customer.customer_name,
                beforeRow || savedDataRef.current,
                storedUpdates,
                `${activeTab} - Save`
            );

            savedDataRef.current = { ...savedRow };
            loadedUpdatedAtRef.current = savedRow.updated_at || new Date().toISOString();
            setLastUpdatedAt(savedRow.updated_at || null);
            setRemoteUpdateAlert(false);
            setConcurrentConflict(null);
            // Still "edited" only if something did not stick (or the user kept typing).
            setEditData(previous => {
                setIsFormDirty(getChangedFields(previous, savedDataRef.current).size > 0);
                return previous;
            });
            if (unsaved.length > 0) {
                reportUnsavedFields(unsaved);
                void fetchLogs();
                return false;   // keeps the window open on Save & Close
            }
            pendingConflictsRef.current.clear();   // saved (or knowingly overwritten)
            bomDirtyRef.current = false;
            setEditingSection(null);
            if (stageChanged) setActiveTab(editData.stage);
            // The customer update is already confirmed. Refreshing the activity
            // list does not need to delay Save & Close.
            void fetchLogs();
            return true;
        } catch (err) {
            console.error('Save failed:', err);
            showAlert(`Your changes were not saved. Please try again.\n\n${err.message || ''}`, { type: 'error' });
            return false;
        } finally {
            setSaving(false);
        }
    };

    const handleOverwriteConflict = async () => {
        setConcurrentConflict(null);
        return await handleSave(true);
    };

    const handleMergeAndSaveConflict = async () => {
        if (!concurrentConflict?.serverData) return;
        const serverRecord = concurrentConflict.serverData;
        savedDataRef.current = { ...serverRecord };
        setEditData(prev => ({ ...serverRecord, ...prev }));
        loadedUpdatedAtRef.current = serverRecord.updated_at;
        setLastUpdatedAt(serverRecord.updated_at || null);
        setConcurrentConflict(null);
        setTimeout(() => handleSave(true), 50);
    };

    const handleDiscardAndReloadConflict = () => {
        if (!concurrentConflict?.serverData) return;
        const serverRecord = concurrentConflict.serverData;
        savedDataRef.current = { ...serverRecord };
        setEditData({ ...serverRecord });
        loadedUpdatedAtRef.current = serverRecord.updated_at;
        setLastUpdatedAt(serverRecord.updated_at || null);
        setIsFormDirty(false);
        setRemoteUpdateAlert(false);
        pendingConflictsRef.current.clear();
        setConcurrentConflict(null);
        showAlert('Reloaded latest data from server. Your unsaved edits were discarded.', { type: 'info' });
    };

    const handleAddNote = async () => {
        if (!followUpText.trim()) return;
        const updatedNotes = [...(editData.follow_ups || []), { text: followUpText, author: user.name, date: new Date().toISOString() }];
        // Returning early on failure matters most here: this used to clear
        // followUpText regardless, so a refused save destroyed the note the
        // user had just typed.
        if (await handleSectionUpdate(customer.id, { follow_ups: updatedNotes }) === false) return;
        await logActivity(user.id, 'note', `Note Added: ${followUpText}`, '', customer.id);
        setEditData(prev => ({ ...prev, follow_ups: updatedNotes }));
        setFollowUpText('');
        fetchLogs();
    };

    const handleSoftDelete = async () => {
        const deletedAt = new Date().toISOString();
        await logActivity(user.id, 'delete', `Soft-deleted: ${customer.customer_name}`, '', customer.id);
        await onDelete(customer.id, deletedAt);   // pass timestamp for soft-delete
        onClose();
    };


    const SectionHeader = ({ title, id, icon: Icon }) => (
        <div className="flex items-center justify-between mb-3 border-b border-stone-100 pb-1.5 mt-4">
            <h3 className="text-[9px] font-bold text-stone-400 uppercase tracking-widest flex items-center gap-2">
                <Icon size={12} /> {title}
            </h3>
            {isEditable && (
                <button onClick={() => {
                    const isOpening = editingSection !== id;
                    setEditingSection(isOpening ? id : null);
                    if (isOpening) {
                        setTimeout(() => {
                            const el = document.getElementById(`section-${id}`);
                            if (el) {
                                el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                            }
                        }, 150);
                    }
                }} className="text-stone-400 hover:text-amber-600 transition-colors">
                    {editingSection === id ? <X size={14} /> : <Edit3 size={12} />}
                </button>
            )}
        </div>
    );

    const tabProps = {
        activeTab, customer: savedDataRef.current, editData, setEditData: handleEditDataChange, handleChange,
        isEditable, editingSection, setEditingSection, channel_partners, subAgents, isAdmin, 
        isOffice, meta, user, isRegChecklistDirty, handleSaveRegChecklist, 
        isOperationalChecklistDirty, handleSaveOperationalChecklist, documents, 
        uploading, 
        onFileUpload: handleFileUpload, 
        onUpload: handleFileUpload,
        onFileDelete: handleDeleteDoc, 
        onDelete: handleDeleteDoc,
        onDeleteDocument: handleDeleteDoc,
        onFilePreview: handlePreviewDoc, 
        onPreview: handlePreviewDoc,
        onViewDocument: handlePreviewDoc,
        onDownloadDocument: handleDownloadDoc,
        onFileDownload: handleDownloadDoc,
        onDownload: handleDownloadDoc,
        onUpdateRemark: handleUpdateDocRemark, 
        onUpdate: handleSectionUpdate, logActivity, fetchLogs, saving, setSaving, handleAdvanceStage,
        saveBomRef, onDirty: () => { bomDirtyRef.current = true; setIsFormDirty(true); },
        // false until the full record has loaded - the panel list stays
        // read-only until then so it can never be rebuilt from a partial copy.
        fullRecordLoaded, onGenerateAgreement: () => handleGenerateAgreement(false),
        onAddAgreementToDocuments: () => handleGenerateAgreement(true),
        isInstallationDetailsEditable,
        isSfdcEditable: isEditable,
        onSfdcSaved: () => {
            if (isChannelPartnerManager) setIsFormDirty(false);
        }
    };

    return (
        <div className="fixed inset-0 bg-stone-900/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-[28px] shadow-2xl w-full max-w-5xl h-[94vh] overflow-hidden flex flex-col border border-stone-100">

                {/* Realtime Remote Conflict Alert Banner - see SHOW_REMOTE_UPDATE_ALERT */}
                {SHOW_REMOTE_UPDATE_ALERT && remoteUpdateAlert && (
                    <div className="bg-amber-500 text-white px-6 py-2.5 text-xs font-semibold flex items-center justify-between shadow-inner shrink-0 animate-fadeIn">
                        <div className="flex items-center gap-2">
                            <AlertTriangle className="w-4 h-4 text-amber-200 shrink-0" />
                            <span>
                                {remoteUpdateAlert.conflicts?.length > 0
                                    ? `A colleague also changed ${remoteUpdateAlert.conflicts.map(fieldLabel).join(', ')}. Saving will ask which value to keep.`
                                    : `A colleague just updated ${(remoteUpdateAlert.fields || []).slice(0, 4).map(fieldLabel).join(', ')}${(remoteUpdateAlert.fields || []).length > 4 ? '…' : ''}. Their changes are loaded; your unsaved edits are kept.`}
                            </span>
                        </div>
                        <button
                            type="button"
                            onClick={() => {
                                const clashes = [...pendingConflictsRef.current];
                                if (clashes.length === 0) {
                                    setRemoteUpdateAlert(false);
                                    return;
                                }
                                setConcurrentConflict({
                                    serverData: { ...savedDataRef.current },
                                    localUpdates: editData,
                                    localChanges: clashes,
                                    remoteChanges: clashes,
                                    overlappingFields: clashes,
                                    serverUpdatedAt: loadedUpdatedAtRef.current
                                });
                            }}
                            className="px-3 py-1 bg-black/20 hover:bg-black/30 text-white font-bold rounded-lg transition-colors cursor-pointer ml-3"
                        >
                            {remoteUpdateAlert.conflicts?.length > 0 ? 'Review Differences' : 'OK'}
                        </button>
                    </div>
                )}

                {/* Header */}
                <div className="bg-stone-900 px-6 py-5 flex justify-between items-center flex-shrink-0">
                    <div>
                        <div className="flex items-center gap-3">
                            <h2 className="text-xl font-bold text-white">{customer.customer_name}</h2>
                            <RedFlagBadge customerId={customer.id} user={user} size={17} />
                            {isCompleted && (
                                <span className={`flex items-center gap-1 text-[9px] px-2 py-0.5 rounded font-bold uppercase tracking-widest ${isFrozen ? 'bg-stone-700 text-stone-400' : 'bg-amber-500/20 text-amber-400'}`}>
                                    {isFrozen ? <><Lock size={9} /> Frozen</> : <><Unlock size={9} /> Unlocked</>}
                                </span>
                            )}
                        </div>
                        <p className="text-[11px] text-stone-400 font-medium mt-0.5 flex flex-wrap items-center gap-x-4 gap-y-1">
                            <span className="inline-flex items-center gap-1.5"><Calendar size={11} className="flex-shrink-0" />Lead Created: {customer.created_at ? `${formatCustomerTimestamp(customer.created_at)} IST` : '—'}</span>
                            <span className="inline-flex items-center gap-1.5"><Calendar size={11} className="flex-shrink-0" />Updated: {lastUpdatedAt ? `${formatCustomerTimestamp(lastUpdatedAt)} IST` : '—'}</span>
                        </p>
                    </div>
                    <div className="flex items-center gap-2">
                        {isCompleted && onRaiseServiceIssue && <button type="button" onClick={() => onRaiseServiceIssue(savedDataRef.current)}
                            className="inline-flex items-center gap-1.5 rounded-lg border border-amber-400/50 bg-amber-500/15 px-2.5 py-1.5 text-[10px] font-bold text-amber-300 hover:bg-amber-500/25">
                            <Flag size={13} /> Raise issue
                        </button>}
                        <RedFlagToggle customer={customer} user={user} tone="dark" />
                        {/* Admin unlock/lock toggle for completed cards */}
                        {isCompleted && isAdmin && (
                            <button onClick={() => { setAdminUnlocked(prev => !prev); setEditingSection(null); }}
                                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[10px] font-bold transition-all ${adminUnlocked ? 'bg-amber-500 text-white hover:bg-amber-600 shadow-lg shadow-amber-500/30' : 'bg-white/10 text-white/60 hover:bg-white/20 hover:text-white'}`}>
                                {adminUnlocked ? <><Lock size={12} /> Re-lock</> : <><Unlock size={12} /> Unlock to Edit</>}
                            </button>
                        )}
                        {isAdmin && <button onClick={() => setShowDeleteConfirm(true)} className="p-2 text-white/30 hover:text-red-400"><Trash2 size={18} /></button>}
                        <button onClick={async () => {
                            if (!(await resolveUnsaved('Save & Close'))) return;
                            onClose();
                        }} className="p-2 text-white/30 hover:text-white"><X size={24} /></button>
                    </div>
                </div>

                {/* Tabs */}
                <div className="flex bg-stone-900 px-6 gap-6 border-t border-white/5 flex-shrink-0 overflow-x-auto scrollbar-none whitespace-nowrap">
                    {[
                        ...PRIMARY_STAGES.filter(s => {
                            if (s.id === STAGE_IDS.LOAN && editData.payment_type?.trim().toLowerCase() === 'cash') return false;
                            if (s.id === STAGE_IDS.CASH && editData.payment_type?.trim().toLowerCase() === 'loan') return false;
                            if (s.id === STAGE_IDS.COMPLETED || s.id === STAGE_IDS.LOST_PROJECT) return false;
                            return true;
                        }).map(s => ({ id: s.id, label: s.label, icon: s.icon })),
                        { id: 'DOCUMENTS', label: 'Documents', icon: FolderOpen },
                        { id: 'history', label: 'Notes & History', icon: History },
                    ].map(tab => (
                        <button key={tab.id} onClick={async () => {
                            if (tab.id !== activeTab && !(await resolveUnsaved('Save & Continue'))) return;
                            setActiveTab(tab.id); setEditingSection(null);
                        }}
                            className={`flex items-center gap-2 py-3 text-[10px] font-bold uppercase tracking-widest transition-all border-b-2 flex-shrink-0 ${activeTab === tab.id ? 'text-amber-400 border-amber-400' : 'text-stone-500 border-transparent hover:text-stone-300'}`}>
                            <tab.icon size={12} /> {tab.label}
                        </button>
                    ))}
                </div>

                {/* Body */}
                <div className="flex-1 min-h-0 overflow-y-auto p-6 bg-[#FCFBFA]">

                    {/* Frozen banner for completed cards */}
                    {isCompleted && isFrozen && (
                        <div className="flex items-center gap-3 px-4 py-3 rounded-2xl mb-6 border bg-stone-100 border-stone-200">
                            <Lock className="w-4 h-4 text-stone-500 flex-shrink-0" />
                            <div className="flex-1">
                                <p className="text-xs font-bold text-stone-600">This project is completed & frozen</p>
                                <p className="text-[10px] text-stone-400">{isAdmin ? 'Click "Unlock to Edit" in the header to make changes' : 'Only an admin can unlock this record for editing'}</p>
                            </div>
                        </div>
                    )}
                    {isCompleted && !isFrozen && (
                        <div className="flex items-center gap-3 px-4 py-3 rounded-2xl mb-6 border bg-amber-50 border-amber-200">
                            <Unlock className="w-4 h-4 text-amber-600 flex-shrink-0" />
                            <div className="flex-1">
                                <p className="text-xs font-bold text-amber-700">Admin edit mode - Record unlocked</p>
                                <p className="text-[10px] text-amber-500">Click "Re-lock" when done to freeze the record again</p>
                            </div>
                        </div>
                    )}

                    {isStageRestrictedForUser && (
                        <div className="flex items-center gap-3 px-4 py-2.5 rounded-2xl mb-6 border bg-amber-50/70 border-amber-200/80 text-amber-950">
                            <Eye className="w-4 h-4 text-amber-600 flex-shrink-0" />
                            <div className="flex-1">
                                <p className="text-xs font-bold text-amber-900">View-Only Stage</p>
                                <p className="text-[10px] text-amber-700 font-medium">Channel Partner Office and Channel Partner Manager accounts have view-only access to Material Integration and Material Delivery.</p>
                            </div>
                        </div>
                    )}

                    {activeTab !== 'history' && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                            {/* Primary Stage Info */}
                            <div className={`p-4 rounded-2xl border shadow-sm ${isCompleted ? 'bg-emerald-50 border-emerald-200' : 'bg-white border-stone-100'} flex flex-col justify-between`}>
                                <div>
                                    <label className="text-[9px] text-stone-400 font-bold uppercase mb-2 block">Primary Stage</label>
                                    <div className="flex items-center gap-3 min-h-[38px]">
                                        <div className="text-xs text-stone-850 font-bold px-3 py-1.5 bg-stone-50 border border-stone-100 rounded-xl flex items-center gap-1.5">
                                            {PRIMARY_STAGES.find(s => s.id === editData.stage)?.label || editData.stage}
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Stage Remark */}
                            <div className="bg-white p-4 rounded-2xl border border-stone-100 shadow-sm flex flex-col justify-between">
                                <div>
                                    <label className="text-[9px] text-stone-400 font-bold uppercase mb-2 block">Stage Remark (Current Stage)</label>
                                    {!canAddRemark ? (
                                        <div className="text-xs text-stone-500 font-medium italic min-h-[38px] bg-stone-50 p-2 rounded-lg">
                                            {(typeof editData.stages_remarks === 'object' && editData.stages_remarks ? editData.stages_remarks[editData.stage] : '') || 'No remarks for this stage.'}
                                        </div>
                                    ) : (
                                        (() => {
                                            const curRemark = getStageRemarkFromData(editData.stages_remarks, editData.stage);
                                            const origRemark = getStageRemarkFromData(savedDataRef.current?.stages_remarks ?? customer.stages_remarks, editData.stage);
                                            const isRemarkDirty = (curRemark || '').trim() !== (origRemark || '').trim();

                                            return (
                                                <div className="flex gap-2">
                                                    <input
                                                        type="text"
                                                        placeholder="Add remark for current stage..."
                                                        value={curRemark}
                                                        onChange={e => {
                                                            const newVal = e.target.value;
                                                            setEditData(prev => {
                                                                const prevObj = typeof prev.stages_remarks === 'object' && prev.stages_remarks ? prev.stages_remarks : {};
                                                                return {
                                                                    ...prev,
                                                                    stages_remarks: {
                                                                        ...prevObj,
                                                                        [prev.stage]: newVal
                                                                    }
                                                                };
                                                            });
                                                        }}
                                                        onKeyDown={(e) => e.key === 'Enter' && handleSaveStageRemark()}
                                                        className="flex-1 bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-amber-300"
                                                    />
                                                    <button
                                                        onClick={() => handleSaveStageRemark()}
                                                        disabled={!isRemarkDirty}
                                                        className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                                                            !isRemarkDirty
                                                                ? 'bg-emerald-600 text-white cursor-default'
                                                                : 'bg-stone-900 text-white hover:bg-stone-800 cursor-pointer'
                                                        }`}
                                                    >
                                                        {!isRemarkDirty ? 'Saved' : 'Save'}
                                                    </button>
                                                </div>
                                            );
                                        })()
                                    )}
                                </div>
                            </div>
                        </div>
                    )}

                    <CustomerModalTabsRouter {...tabProps} />

                    {/* ── DOCUMENTS ── */}
                    {activeTab === "DOCUMENTS" && (
                        <CustomerDocumentsTab
                            documents={documents}
                            isEditable={isEditable}
                            canDelete={canDeleteDocs}
                            canCrop={canCropDocs}
                            docSearchQuery={docSearchQuery}
                            setDocSearchQuery={setDocSearchQuery}
                            uploading={uploading}
                            handleFileUpload={handleFileUpload}
                            getDocTypeLabel={getDocTypeLabel}
                            handlePreviewDoc={handlePreviewDoc}
                            handleCropDoc={setCroppingDoc}
                            handleDeleteDoc={handleDeleteDoc}
                            handleUpdateDocRemark={handleUpdateDocRemark}
                            handleDownloadAllDocuments={handleDownloadAllDocuments}
                            downloadingAllDocuments={downloadingAllDocuments}
                            canDownloadAllDocuments={canDownloadAllDocuments}
                        />
                    )}

                    {/* ── NOTES & HISTORY ── */}
                    {activeTab === 'history' && (
                        <HistoryTab
                            editData={editData}
                            handleChange={handleChange}
                            isEditable={isEditable}
                            editingSection={editingSection}
                            setEditingSection={setEditingSection}
                            followUpText={followUpText}
                            setFollowUpText={setFollowUpText}
                            handleAddNote={handleAddNote}
                            activityLogs={activityLogs}
                            logsHasMore={logsHasMore}
                            logsLoadingMore={logsLoadingMore}
                            onLoadMoreLogs={loadMoreLogs}
                        />
                    )}

                    {isEditable && activeTab !== STAGE_IDS.LOST_PROJECT && activeTab !== 'DOCUMENTS' && activeTab !== 'history' && customer.stage !== STAGE_IDS.COMPLETED && (
                        <div className="mt-8 pt-4 border-t border-stone-200/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-stone-50/70 p-3.5 rounded-2xl border border-stone-200/60">
                            <div className="flex items-center gap-2.5">
                                <div className="p-1.5 bg-amber-100 text-amber-700 rounded-lg flex-shrink-0">
                                    <PauseCircle size={16} />
                                </div>
                                <div>
                                    <p className="text-xs font-bold text-stone-700">Need to mark as lost project or put on hold?</p>
                                    <p className="text-[11px] text-stone-500 font-medium">Classify this project as lost with origin stage details & audit notes.</p>
                                </div>
                            </div>
                            <button
                                type="button"
                                onClick={handleMoveToLostProject}
                                className="px-3.5 py-2 bg-white hover:bg-stone-100 text-stone-700 rounded-xl text-xs font-bold border border-stone-200 transition-colors shadow-2xs self-start sm:self-auto cursor-pointer"
                            >
                                Move to Lost Project
                            </button>
                        </div>
                    )}
                </div>

                {/* Footer bar - 50/50 split buttons at customer card */}
                {isEditable && activeTab !== STAGE_IDS.LOST_PROJECT && (
                    <div className="p-4 border-t border-stone-100 bg-white flex-shrink-0 flex gap-3">
                        <button
                            /* () => handleSave() - NOT onClick={handleSave}. React
                               passes the click event as the first argument, which
                               made `forceOverwrite` a truthy SyntheticEvent and
                               skipped the entire concurrency check below it, so
                               the conflict dialog could never open from this
                               button and a colleague's edit was silently
                               overwritten with a green "Saved". */
                            onClick={() => handleSave()}
                            disabled={saving}
                            className={`flex-1 py-3.5 rounded-xl font-bold flex items-center justify-center gap-2 transition-all text-xs cursor-pointer shadow-sm disabled:opacity-50 ${
                                isFormDirty
                                    ? 'bg-stone-900 text-white hover:bg-stone-800'
                                    : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                            }`}
                        >
                            {saving ? (
                                'Saving...'
                            ) : isFormDirty ? (
                                <>
                                    <Save size={14} />
                                    <span>Save</span>
                                </>
                            ) : (
                                <>
                                    <Check size={14} className="text-white" />
                                    <span>Saved</span>
                                </>
                            )}
                        </button>

                        {/* Restored: removed in rd48, leaving hasNextStage / nextStageId /
                            nextStageLabel / handleAdvanceStage all in place but unreachable,
                            so no role could advance a customer from the modal. */}
                        {/* Compare with the stored stage. `customer` is the list copy the window
                            was opened with; after "Save & Move" it still had the old stage, so the
                            button vanished on the new stage's tab and appeared on the old one
                            (Loan tab offering "Move to Material Integration"). */}
                        {hasNextStage && activeTab === (savedDataRef.current?.stage || customer.stage) && (
                            <button
                                onClick={() => {
                                    if (nextStageId === STAGE_IDS.COMPLETED) {
                                        setShowCompletedConfirm(true);
                                    } else {
                                        handleAdvanceStage();
                                    }
                                }}
                                disabled={saving}
                                className="flex-1 py-3.5 rounded-xl font-bold flex items-center justify-center gap-2 transition-all text-xs bg-amber-500 hover:bg-amber-600 text-white shadow-md shadow-amber-500/10 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                {saving ? 'Saving & Moving...' : `Save & Move to ${nextStageLabel}`}
                            </button>
                        )}
                    </div>
                )}
            </div>

            {/* Soft-delete confirm */}
            {showValidationModal && (
                <div className="fixed inset-0 z-[80] flex items-center justify-center bg-stone-950/60 p-4 backdrop-blur-sm" onClick={() => setShowValidationModal(false)}>
                    <section className="w-full max-w-md overflow-hidden rounded-[28px] border border-amber-200 bg-white shadow-2xl animate-in zoom-in-95 fade-in duration-200" onClick={event => event.stopPropagation()} role="alertdialog" aria-modal="true" aria-labelledby="requirements-title">
                        <div className="bg-gradient-to-br from-amber-500 via-amber-500 to-orange-500 px-6 py-5 text-white">
                            <div className="flex items-start justify-between gap-4">
                                <div className="flex items-center gap-3">
                                    <div className="rounded-2xl bg-white/20 p-2.5"><AlertTriangle size={21} /></div>
                                    <div>
                                        <p className="text-[10px] font-black uppercase tracking-[0.18em] text-amber-50">Watersun checklist</p>
                                        <h3 id="requirements-title" className="mt-0.5 text-lg font-black">A few details need attention</h3>
                                    </div>
                                </div>
                                <button type="button" onClick={() => setShowValidationModal(false)} className="rounded-lg p-1 text-white/90 hover:bg-white/15 hover:text-white" aria-label="Close requirements popup"><X size={19} /></button>
                            </div>
                        </div>
                        <div className="px-6 py-5">
                            <p className="text-sm font-medium leading-relaxed text-stone-600">Complete the required items below before moving this customer to <span className="font-bold text-stone-800">{nextStageLabel}</span>.</p>
                            <ul className="mt-4 space-y-2.5">
                                {validationIssues.map((issue, idx) => {
                                    const displayMsg = typeof issue === 'string'
                                        ? issue
                                        : (issue?.text ? (issue?.label ? `${issue.label}: ${issue.text}` : issue.text) : JSON.stringify(issue));
                                    return (
                                        <li key={idx} className="flex items-center gap-3 rounded-xl border border-rose-100 bg-rose-50 px-3.5 py-2.5 text-sm font-semibold text-rose-800">
                                            <span className="flex h-5 w-5 flex-none items-center justify-center rounded-full bg-rose-500 text-xs font-black text-white">!</span>
                                            <span>{displayMsg}</span>
                                        </li>
                                    );
                                })}
                            </ul>
                            <div className="mt-5 flex gap-2">
                                <button 
                                    type="button" 
                                    onClick={() => setShowValidationModal(false)} 
                                    className="flex-1 rounded-xl bg-stone-100 hover:bg-stone-200 px-4 py-3 text-xs font-bold text-stone-700 transition-colors cursor-pointer"
                                >
                                    Review
                                </button>
                            </div>
                        </div>
                    </section>
                </div>
            )}

            {/* Soft-delete confirm */}
            {showDeleteConfirm && (
                <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[60] p-4">
                    <div className="bg-white rounded-2xl p-6 w-full max-w-sm">
                        <div className="flex items-center gap-3 mb-4">
                            <div className="p-2 bg-red-100 rounded-full"><AlertTriangle className="w-5 h-5 text-red-600" /></div>
                            <h3 className="font-bold text-stone-800">Move to Trash?</h3>
                        </div>
                        <p className="text-sm text-stone-600 mb-5">
                            <strong>{customer.customer_name}</strong> will be moved to Trash. You can recover it later from the Trash view.
                        </p>
                        <div className="flex gap-3">
                            <button onClick={() => setShowDeleteConfirm(false)} className="flex-1 py-2.5 border border-stone-300 text-stone-700 rounded-xl text-sm font-medium">Cancel</button>
                            <button onClick={handleSoftDelete} className="flex-1 py-2.5 bg-red-600 text-white rounded-xl text-sm font-medium flex items-center justify-center gap-2">
                                <Trash2 className="w-4 h-4" /> Move to Trash
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Move-to-Completed lock confirm */}
            {showCompletedConfirm && (
                <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[60] p-4">
                    <div className="bg-white rounded-2xl p-6 w-full max-w-sm">
                        <div className="flex items-center gap-3 mb-4">
                            <div className="p-2 bg-amber-100 rounded-full"><Lock className="w-5 h-5 text-amber-600" /></div>
                            <h3 className="font-bold text-stone-800">Mark as Completed?</h3>
                        </div>
                        <p className="text-sm text-stone-600 mb-5">
                            Moving <strong>{customer.customer_name}</strong> to Completed will lock this record. Only an admin will be able to unlock it for further edits. Do you want to proceed?
                        </p>
                        <div className="flex gap-3">
                            <button onClick={() => setShowCompletedConfirm(false)} className="flex-1 py-2.5 border border-stone-300 text-stone-700 rounded-xl text-sm font-medium">Cancel</button>
                            <button
                                onClick={() => {
                                    setShowCompletedConfirm(false);
                                    handleAdvanceStage();
                                }}
                                className="flex-1 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-sm font-medium flex items-center justify-center gap-2"
                            >
                                <Lock className="w-4 h-4" /> Proceed & Lock
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* PM Surya Ghar Agreement Popup Modal */}
            {showAgreementPopup && (
                <AgreementPreview
                    data={agreementData}
                    onChange={setAgreementData}
                    onClose={() => { setShowAgreementPopup(false); setAgreementAutoAdd(false); }}
                    existingDocument={documents.some(doc => doc?.doc_type === 'discom_agreement')}
                    autoAdd={agreementAutoAdd}
                    onAddToDocuments={async (file) => {
                        const replacing = documents.some(doc => doc?.doc_type === 'discom_agreement');
                        const uploaded = await handleFileUpload({ target: { files: [file], value: '' } }, 'discom_agreement');
                        if (uploaded) {
                            setShowAgreementPopup(false);
                            setAgreementAutoAdd(false);
                            showAlert(
                                replacing
                                    ? 'The DISCOM agreement was regenerated and replaced in Documents.'
                                    : 'The DISCOM agreement was generated and added to Documents.',
                                { title: 'Document saved', type: 'success' }
                            );
                        }
                    }}
                />
            )}

            {/* File Preview Modal */}
            {croppingDoc && <CropPhotoModal doc={croppingDoc} onClose={() => setCroppingDoc(null)} onSave={file => handleFileUpload({ target: { files: [file], value: '' } }, croppingDoc.doc_type, croppingDoc.id, true)} />}
            {filePreview.doc && (
                <FilePreviewModal
                    file={filePreview.doc}
                    fileUrl={filePreview.url}
                    onClose={() => setFilePreview({ doc: null, url: null })}
                    onDownload={() => handleDownloadDoc(filePreview.doc)}
                    onUpdateRemark={handleUpdateDocRemark}
                    onCrop={canCropDocs && isEditable ? () => { setCroppingDoc(filePreview.doc); setFilePreview({ doc: null, url: null }); } : undefined}
                />
            )}

            {/* Concurrency Conflict Resolution Modal */}
            <ConflictResolutionModal
                isOpen={Boolean(concurrentConflict)}
                conflict={concurrentConflict}
                onOverwrite={handleOverwriteConflict}
                onMergeAndSave={handleMergeAndSaveConflict}
                onDiscardAndReload={handleDiscardAndReloadConflict}
                onClose={() => setConcurrentConflict(null)}
            />
        </div>
    );
}
