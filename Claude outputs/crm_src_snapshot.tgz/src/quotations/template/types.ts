export interface AssetImages {
  watersunLogoUrl?: string; // Screenshot 1: Watersun Logo
  screenshot2MiddleBannerUrl?: string; // Screenshot 2: Full Page 1 Middle Block (GEDA + MNRE + Modi Banner)
  gedaLogoUrl?: string;
  mnreLogoUrl?: string;
  suryaGharBannerUrl?: string;
  tataSolaroofLogoUrl?: string; // Screenshot 3: Tata Power Solaroof Logo
}

export interface BrandQuoteOption {
  brandName: string; // e.g., "Waaree Solar", "Tata Power Solar", "Adani Solar"
  baseValue: number; // e.g., 189000
  discount: number; // e.g., 0
  netPayableAmount: number; // calculated: baseValue - discount
  subsidy: number; // e.g., 78000
  netPriceAfterSubsidy: number; // calculated: netPayableAmount - subsidy
}

export interface QuotationData {
  // Image Assets
  assets?: AssetImages;

  // Company & Header
  company: {
    name: string;
    tagline: string;
    gstNo: string;
    cinNo: string;
    email: string;
    logoUrl?: string; // custom uploaded logo
  };

  // Page 1
  page1: {
    customerName: string;
    customerPhone: string;
    quotationNo: string;
    date: string;
    capacityKw: string; // e.g., "3.48 kw"
    yoursTrulyName: string;
    yoursTrulyPhone: string;
    introParagraph1?: string;
    introParagraph2?: string;
  };

  // Page 2
  page2: {
    solarPanelMake: string; // "Waree 580"
    solarPanelQty: number | string; // "6"
    inverterOption: string; // "Option 1", "Option 2", "Option 3", "Option 4", or "Custom"
    inverterBrand: string; // "Solaryan"
    gebGedaCharge: 'Including' | 'Excluding'; // user prompt: "feda, inclusive or exclusive"
    gebCharge?: number | string; // amount, or 'Included'
    gedaCharge?: number | string; // amount, or 'Included'
    projectType: 'Residential' | 'Commercial'; // user prompt: "residential or commericail"

    // Project Size column in Table 2
    projectSize?: string; // e.g., "3.48 kW"

    // 3 Brand / Company Options with their values & totals
    brandOptions: [BrandQuoteOption, BrandQuoteOption, BrandQuoteOption];

    // Financials (legacy fallback support)
    baseValue: number; // ₹1,89,000.00
    discount: number; // ₹0.00
    netPayableAmount: number; // calculated: baseValue - discount
    subsidy: number; // ₹78,000.00
    netPriceAfterSubsidy: number; // calculated: netPayableAmount - subsidy

    // Notes
    notes: string[];
  };

  // Page 3
  page3: {
    termsAndConditions: { sr: number; parameter: string; remarks: string }[];
    warranties: { sr: number; parameter: string; remarks: string }[];
    bomItems: {
      sr: number;
      description: string;
      unit: string;
      qty: string;
      size: string;
      make: string;
    }[];
    otherChargesText: string;
    bankDetails: {
      accountName: string;
      accountNumber: string;
      bankName: string;
      branchName: string;
      ifscCode: string;
    };
  };

  // Footer Info
  footer: {
    authorizedPartner: string;
    corporateOffice: string;
    branchOffice: string;
  };
}

export type InverterPreset = {
  id: string;
  label: string;
  brand: string;
  specs: string;
};
